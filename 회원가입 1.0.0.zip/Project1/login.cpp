#pragma once
#include <iostream>
#include "string.cpp";
#include "list.cpp";
#include "map.cpp";

using namespace std;

class User {

private:
	//String uid;
	String password;
	String name;

public:
	String id;

public:
	String getID()
	{
		return id;
	}

public:
	User()
	{
	}
	~User()
	{
	}

	// NULL ����
	User(const int) {
		id = String(NULL);
	}

	bool SetId() {

	}

	void operator=(User user) {
		id = user.id;
	}
};


class UserList {

private:
	Map<const char*, User> users;

public:
	bool CompareID(String id) {
		return users.ContainString(id.characters);
	}

    void CreateUser(char* id, User user) {
		cout << id << endl;
		users[id] = user;
		cout << "users key: " << users.keys.elementAt(users.count - 1) << endl;
		cout << "users key hash: " << users.GetKeyHash(id) << endl;
		cout << "users count: " << users.count << endl;
	} 
};

class LoginManager {

public:
	UserList userList;
	User currentUser;


private:
	bool IsID_Duplicate(String id) {
		return userList.CompareID(id);
	}


public:
	LoginManager()
	{

	}
	~LoginManager()
	{

	}

	User* Login() {
		return nullptr;
	}
	void SignUp() {
		String input;
		User user;

		cout << "���̵� �Է�: ";
		cin >> input;
		bool idDuplicate = userList.CompareID(input);

		if (idDuplicate)
		{
			cout << "���̵� �ߺ���" << endl;
			SignUp();
		}
		cout << "���̵� �ߺ� �ȵ�" << endl;
		userList.CreateUser(input.characters,  user);
		SignUp();

		cout << "�н����� �Է�: ";
		cin >> input;
	}
	void LogOut() {

	}
	void Delete() {

	}
};