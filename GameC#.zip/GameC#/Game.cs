﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using GameC_.Class;
using GameC_.Helper;
using Helper;


namespace MainGame
{
    enum GameState
    {
        None,
        Play,
        Clear,
        Over,
    }
    class History
    {
        public Vector2Int playerPos;

        public List<Vector2Int> boxPos = new List<Vector2Int>();
    }
    internal class MyGame : ConsoleBase
    {
        Vector2Int playerPos;
        int width;
        int height;

        int moveCount = 0;

        List<Stage> stageList = new List<Stage>();
        int stageIndex = 0;
        Stage currentStage = null;

        GameState state = GameState.None;
        Stack<History> histories= new Stack<History>();

        List<Vector2Int> boxPos = new List<Vector2Int>();
        List<Vector2Int> spotsPos = new List<Vector2Int>();
        public MyGame()
        {
            MapEditor.CreateMap("stage_3.csv");

            Console.OutputEncoding = System.Text.Encoding.Unicode;  // 유니코드 출력 설정

            Console.SetWindowSize(100, 50);
            Console.SetBufferSize(100, 50);

            base.Init(50, 35);
        }

        ConsoleKeyInfo? curKey;
        public bool UpdateInput()
        {
            if (Console.KeyAvailable)
            {   
                // 키 표시 안함
                curKey = Console.ReadKey(true);
                if (curKey == null) return false;
            }
            else
            {
                curKey = null;
            }

            return Console.KeyAvailable;
        }

        public void NextStageInput()
        {
            if (curKey == null) return;
            if (stageIndex >= stageList.Count - 1)
            {
                return;
            }

            if (state == GameState.Clear)
            {
                if (curKey.Value.Key == ConsoleKey.N)
                {
                    StageInit(stageList[++stageIndex]);
                }
            }
        }

        void StageInit(Stage stage)
        {
            state = GameState.Play;

            currentStage = stage;
            currentStage.Init(out boxPos, out spotsPos, out playerPos);
            moveCount= 0;
            histories.Clear();

            height = currentStage.map.GetLength(1);
            width = currentStage.map.GetLength(0);

            ClearBuffer();
        }

        public void PlayerControl()
        {
            if (curKey == null) return;
            if (state == GameState.Clear) return;

            if (curKey.Value.Key == ConsoleKey.Z)
            {
                if (histories.Count <= 0) return;

                var a = histories.Pop();

                playerPos = a.playerPos;
                boxPos.Clear();
                a.boxPos.ForEach((e) => boxPos.Add(new Vector2Int(e.x, e.y)));
                return;
            }

            var h = new History();
            h.playerPos = playerPos;
            boxPos.ForEach((e) => h.boxPos.Add(new Vector2Int(e.x, e.y)));
            histories.Push(h);

            var hPos = playerPos;
            var dir = new Vector2Int().zero;

            if (curKey.Value.Key == ConsoleKey.LeftArrow)
                dir = dir.left;
            else if (curKey.Value.Key == ConsoleKey.RightArrow)
                dir = dir.right;
            else if (curKey.Value.Key == ConsoleKey.UpArrow)
                dir = dir.up;
            else if (curKey.Value.Key == ConsoleKey.DownArrow)
                dir = dir.down;

            playerPos += dir;

            if (currentStage.map[playerPos.y, playerPos.x] == '■') playerPos = hPos;
            else
            {
                boxPos.ForEach((e) => {
                    if (e.Equal(playerPos)) {
                        var nP = e + dir;
                        if (currentStage.map[nP.y, nP.x] == '■') {
                            playerPos = hPos;
                            return;
                        }
                        for (int i = 0; i < boxPos.Count; i++)
                        {
                            if (boxPos[i].Equal(nP))
                            {
                                playerPos = hPos;
                                return;
                            }
                        }
                        e.Add(dir);
                    }
                });
            }

            if (!playerPos.Equal(hPos)) moveCount++;
            else histories.Pop();
        }
        public bool SpotsUpdate()
        {
            int existCount = 0;
            spotsPos.ForEach((e) => {
                for(int i = 0; i < boxPos.Count; i++)
                    if (e.Equal(boxPos[i])) existCount++;
            });

            if (existCount >= spotsPos.Count)
            {
                state = GameState.Clear;
                return true;
            }
            else return false;
        }

        public override Task Awate()
        {
            return Task.CompletedTask;
        }
        public override void Start()
        {
            stageList.Add(Stage.FromDatabase(FileManager.Read("stage_1.csv")));
            stageList.Add(Stage.FromDatabase(FileManager.Read("stage_2.csv")));
            stageList.Add(Stage.FromDatabase(FileManager.Read("stage_3.csv")));
            StageInit(stageList.First<Stage>());
        }
        public override void Update()
        {
            UpdateInput();

            if (state == GameState.Play)
            {
                PlayerControl();
                SpotsUpdate();

                for (int y = 0; y < width; y++)
                    for (int x = 0; x < height; x++)
                        SetBuffer(x, y, currentStage.map[y, x].ToString());

                spotsPos.ForEach((e) => SetBuffer(e.x, e.y, "☆"));

                SetBuffer(playerPos.x, playerPos.y, "♠");
                boxPos.ForEach((e) => SetBuffer(e.x, e.y, "▨"));

                SetBuffer(2, height + 2, "이동횟수 " + moveCount.ToString());
            }
            else if(state == GameState.Clear)
            {
                spotsPos.ForEach((e) => SetBuffer(e.x, e.y, "★"));

                SetBuffer(2, height + 2, "스테이지 클리어");

                 if (stageIndex >= stageList.Count - 1)
                    SetBuffer(2, height + 4, "마지막 스테이지 클리어");
                 else SetBuffer(2, height + 4, "다음스테이지로 이동 N");

                NextStageInput();
            }
        }
    }
}
