﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameC_.Helper
{
    internal class FileManager
    {
        public static void Save(string fileName, string data)
        {
            string filePath = fileName;
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs, Encoding.UTF8);

            sw.Write(data);
            sw.Close();
            fs.Close();
        }

        public static string Read(string fileName)
        {
            string lines = File.ReadAllText(fileName);
            return lines;
        }
    }
}
