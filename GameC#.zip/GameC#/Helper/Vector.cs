﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    internal class Vector2Int
    {
        public int x;
        public int y;

        public Vector2Int zero {
            get { return new Vector2Int(0, 0); }
        }
        public Vector2Int up {
            get { return new Vector2Int(0, -1); }
        }
        public Vector2Int down {
            get { return new Vector2Int(0, +1); }
        }
        public Vector2Int left {
            get { return new Vector2Int(-1, 0); }
        }
        public Vector2Int right {
            get { return new Vector2Int(+1, 0); }
        }

        public static bool operator ==(Vector2Int obj1, Vector2Int obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return true;
            else return false;
        }
        public static bool operator !=(Vector2Int obj1, Vector2Int obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return false;
            else return true;
        }
        public static Vector2Int operator +(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x + b.x, a.y + b.y);
        }
        // 복사 생성자
        public Vector2Int(Vector2Int other)
        {
            this.x = other.x;
            this.y = other.y;
        }


        public void Add(Vector2Int add)
        {
            x += add.x;
            y += add.y;
        }
        public bool Equal(Vector2Int target)
        {
            if (target.x == x && target.y == y) return true;
            else return false;
        }

    


        public Vector2Int() {
            x = 0; y = 0;
        }

        public Vector2Int(int _x, int _y) {
            x = _x; y = _y;
        }
    }
}
