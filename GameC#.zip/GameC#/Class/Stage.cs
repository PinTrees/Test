﻿using Helper;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace GameC_.Class
{
    internal class Stage
    {
        public char[,] map;

        public Stage(char[,] _map)
        {
            map = _map;
        }
        public static Stage FromDatabase(string datas)
        {
            string[] lines = datas.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);

            int cols = lines[0].Split(',').Length;
            int rows = lines.Length;
            char[,] characters = new char[rows, cols];

            for (int i = 0; i < rows; i++)
            {
                string[] values = lines[i].Split(',');
                for (int j = 0; j < cols; j++)
                {
                    if (values[j] == string.Empty) break;
                    characters[i, j] = Convert.ToChar(values[j]);
                }
            }
            return new Stage(characters);
        }
        public void Init(out List<Vector2Int> boxList, out List<Vector2Int> spotsList, out Vector2Int playerPos)
        {
            boxList = new List<Vector2Int>();
            spotsList = new List<Vector2Int>();
            playerPos = new Vector2Int().zero;

            var empty = 'ㅤ';
            for (int x = 0; x < map.GetLength(0); x++)
                for (int y = 0; y < map.GetLength(1); y++)
                {
                    var currTile = map[x, y];
                    if (currTile == '♠')
                    {
                        playerPos = new Vector2Int(y, x);
                        map[x, y] = empty;
                    }
                    if (currTile == '▨')
                    {
                        boxList.Add(new Vector2Int(y, x));
                        map[x, y] = empty;
                    }
                    else if (currTile == '☆')
                    {
                        spotsList.Add(new Vector2Int(y, x));
                        map[x, y] = empty;
                    }
                    else if (currTile == '□' || currTile == 'ㅡ')
                    {
                        map[x, y] = empty;
                    }
                }
        }

        public string ToCSV()
        {
            string str = string.Empty;
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    str += map[i, j];
                    if (j < map.GetLength(1) - 1)
                    {
                        str += ",";
                    }
                }
                str += Environment.NewLine;
            }
            return str;
        }
    }
}
