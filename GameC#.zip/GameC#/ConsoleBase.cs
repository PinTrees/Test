﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainGame
{
    public enum GAMEEXITE
    {
        EXITE,
        SS,
    }

    /***
     * 이 클래스는 게임 매니저의 로직을 관리하기 위한 래핑 클래스입니다.
     * 
     */
    internal abstract class ConsoleBase
    {
        protected char[,] buffer = null;
        protected string buildBuffer = null;

        private int width = 0;
        private int height = 0;

        int currentTime = 0;

        public ConsoleBase() {}
        public ConsoleBase(int width, int height)
        {
            Init(width, height);
        }


        virtual public void Init(int width, int height)
        {
            currentTime = Environment.TickCount;
            Console.CursorVisible = false;


            this.width = width;
            this.height = height;

            buffer = new char[width, height];

            ClearBuffer();
        }
        virtual public void Dispose()
        {

        }


        virtual public void ClearBuffer()
        {
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                    buffer[x, y] = ' ';
        }


        ConsoleKeyInfo? curKey;
        public bool UpdateInput()
        {
            if (Console.KeyAvailable)
            {
                curKey = Console.ReadKey();
                if (curKey == null) return false;
            }
            else
            {
                curKey = null;
            }

            return Console.KeyAvailable;
        }


        /***
         * 이 함수는 초기화 전 비동기 초기화를 진행합니다.
         * 
         * 자식 클래스에서 재정의 할 수 있습니다.
         */
        public abstract Task Awate();


        /***
         * 이 함수는 초기화 후 바로 호출됩니다.
         * 
         * 자식 클래스에서 재정의 할 수 있습니다.
         */
        public abstract void Start();


        /***
         * 이 함수는 런타임동안 반복적으로 실행됩니다.
         * 
         * 자식 클래스에서 재정의 할 수 있습니다.
         */
        public abstract void Update();


        virtual public GAMEEXITE GameLogic()
        {
            Update();

            if(Environment.TickCount - currentTime > 100 )
            {
                currentTime = Environment.TickCount;
                Render();
            }

            return GAMEEXITE.SS;
        }



        virtual public void StartGame()
        {
            Task.Run(() => { Awate(); });
            Start();

            while (true)
            {
                if (GameLogic() == GAMEEXITE.EXITE)
                    break;
            }

            Dispose();
        }




        public bool IsSafeBuffer(int x, int y)
        {
            if (x < 0 || x >= width) return false;
            if (y < 0 || y >= height) return false;
            return true;
        }

        virtual public void SetBuffer(int x, int y, string str)
        {
            int size = str.Length;
            for (int i = 0; i < size; i++)
            {
                if (IsSafeBuffer(x + i, y))
                    buffer[x + i, y] = str[i];
            }
        }


        void BuildBuffer()
        {
            int bufferSize = width * height;

            buildBuffer = "";

            for (int y = 0; y < height; y++)
            {
                var buildLineBuffer = "";
                char[] b = new char[width];
                for (int x = 0; x < width; x++)
                {
                    b[x] = buffer[x, y];
                    buildLineBuffer = new string(b);
                }
                buildLineBuffer += "\r\n";
                buildBuffer += buildLineBuffer;
            }
        }



        public void Render()
        {
            BuildBuffer();

            //Console.Clear();
            Console.SetCursorPosition(0, 0);
            Console.WriteLine(buildBuffer);
            return;
        }
    }
}
