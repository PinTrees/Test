﻿using MainGame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MainGame;
using System.Collections;
using System.Threading;

namespace GameC_
{
    public class CustomForEach : IEnumerator, IEnumerable
    {
        int[] arr = new int[100];
        int position = -1;
        public object Current
        {
            get { return arr[position]; }
        }
        public bool MoveNext()
        {
            position++;
            return (position < arr.Length);
        }
        public void Reset()
        {
            position = -1;
        }
        public IEnumerator GetEnumerator()
        {
            yield return new WaitForSeconds(1);
            yield return(IEnumerator)this;
        }
        public int this[int ix]
        {
            get { return arr[ix]; }
            set { }
        }
        public IEnumerable<int> GetNumber()
        {
            int i = 0;
           while(i < arr.Length)
            {
                yield return arr[i++];
            }
        }
        public CustomForEach()
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = i;
            }
        }
    }

    internal class Program
    {
        static LogLike game = null;
        static ConsoleBase game2 = null;
        static void Main(string[] args)
        {
            /*Console.SetWindowSize(50, 50);
            Console.SetBufferSize(50, 50);
            Console.Clear();

            game2 = new MyGame();
            game2.StartGame();
            Console.ReadLine();*/



            int[] arr = { 0, 1, 2, 3, 4, 5, 6 };
            arr.ForEach(i => {
                Console.WriteLine(i);
            });
        }
    }
}
