﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public static class EX
{
    public static void ForEach<K, T>(this Dictionary<K, T> a, Action<K, T> fptr)
    {
        for (int i = 0; i < a.Count; i++)
            fptr(a.Keys.ElementAt(i), a.Values.ElementAt(i));
    }
    public static void ForEach<T>(this T[] a, Action<T> fptr)
    {
        for (int i = 0; i < a.Length; i++) fptr(a[i]);
    }





    public static void Sort<T>(this T[] a, Func<T, T, int> fptr)
    {
        Array.Sort(a, (T b, T c) => {
            return fptr(b, c);
        });
    }
    public static int ToInt(this string str)
    {
        int iiii = 0;
        int.TryParse(str, out iiii);
        return iiii;
    }
    public static float ToFloat(this string str)
    {
        str = str.Replace('f', ' ');
        str.Trim();


        float iiii = 0.0f;
        float.TryParse(str, out iiii);
        return iiii;
    }




}