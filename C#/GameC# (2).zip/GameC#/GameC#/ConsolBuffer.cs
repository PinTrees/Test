﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainGame
{
    internal class ConsoleBuffer
    {
        protected char[,] buffer = null;
        protected char[] writerBuffer = null;
       
        protected string[] buildBuffer = null;
        protected string buildBufferOne = null;

        private int width = 0;
        private int height = 0;


        public ConsoleBuffer(int width, int height)
        {
            this.width = width;
            this.height = height;

            buffer = new char[width, height];
            writerBuffer = new char[width * height];
            buildBuffer = new string[height];
        }   

        public void InitBuffer()
        {
            Console.CursorVisible = false;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    buffer[x, y] = '#';
                }
            }
        }



        public bool IsSafeBuffer(int x, int y)
        {
            if(x < 0 || x >= width ) return false;
            if (y < 0 || y >= height) return false;
            return true;
        }


        public void SetBuffer(int x, int y, string str)
        {
            int size = str.Length;
            for(int i = 0; i < size; i++)
            {
                if(IsSafeBuffer(x + i, y))
                    buffer[x + i, y] = str[i];
            }
        }


        void ClearAllBuffer()
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    //writerBuffer[x + (y * width)] = ' ';
                }
            }
        }


        void BuildBuffer()
        {
            int bufferSize = width * height;
            //for (int i = 0; i < bufferSize; i++) writerBuffer[i] = ' ';

            buildBufferOne = "";

            for (int y = 0; y < height; y++)
            {
                char[] b = new char[width];
                for(int x = 0; x < width; x++)
                {
                    writerBuffer[x + (y * width)] = buffer[x, y];
                    b[x] = buffer[x, y];
                    buildBuffer[y] = new string(b);
                }
                buildBuffer[y] += "\r\n";
                buildBufferOne += buildBuffer[y];
            }
        }

        public void Render()
        {
            BuildBuffer();
            Darw();
        }


        void Darw()
        {
            Console.SetCursorPosition(0, 0);
            Console.Write(buildBufferOne);
            return;

            /*for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(buffer[x, y]);
                }
                Console.WriteLine();
            }*/
        }

    }
}
