﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MainGame
{
    internal class MyGame : ConsoleBase
    {
        Point playerPos;

        public MyGame()
        {
            //Console.SetWindowSize(100, 50);
            //var width = Console.BufferWidth;
            //var height = Console.BufferHeight;

            base.Init(50, 25);
        }

        ConsoleKeyInfo? curKey;
        public bool UpdateInput()
        {
            if (Console.KeyAvailable)
            {   
                curKey = Console.ReadKey();
                if (curKey == null) return false;
            }
            else
            {
                curKey = null;
            }

            return Console.KeyAvailable;
        }


        public void PlayerControl()
        {
            if (curKey == null) return;
          
            if (curKey.Value.Key == ConsoleKey.LeftArrow) playerPos.X -= 2;
            else if (curKey.Value.Key == ConsoleKey.RightArrow) playerPos.X += 2;
            else if (curKey.Value.Key == ConsoleKey.UpArrow) playerPos.Y = (playerPos.Y <= 0) ? 0 : playerPos.Y - 1;
            else if (curKey.Value.Key == ConsoleKey.DownArrow) playerPos.Y++;
        }



        public override Task Awate()
        {
            return Task.CompletedTask;
        }
        public override void Start()
        {
        }
        public override void Update()
        {
            UpdateInput();

            PlayerControl();

            SetBuffer(0, 0, new string('#', 50));
            for (int i = 1; i < 24; i++)
                SetBuffer(0, i, "#" + new string(' ', 48) + "#");
            SetBuffer(0, 24, new string('#', 50));

            SetBuffer(playerPos.X, playerPos.Y, "Player");

            SetBuffer(5, 10, "★");
            SetBuffer(8, 20, "★");
        }
    }
}
