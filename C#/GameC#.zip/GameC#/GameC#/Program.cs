﻿using MainGame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MainGame;


namespace GameC_
{
    internal class Program
    {
        static LogLike game = null;
        static ConsoleBase game2 = null;
        static void Main(string[] args)
        {
            /*game = new LogLike();
            game.GameLogic();
            Console.ReadLine();*/

            game2 = new MyGame();
            game2.StartGame();
            Console.ReadLine();
        }
    }
}
