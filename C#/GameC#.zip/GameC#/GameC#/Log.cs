﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MainGame
{
    internal class LogLike
    {
        ConsoleBuffer buffer = null;

        public LogLike()
        {
            //buffer = new ConsoleBuffer(Console.WindowWidth, Console.WindowHeight);
            buffer = new ConsoleBuffer(50, 25);
            buffer.InitBuffer();
        }


        ConsoleKeyInfo? curKey;
        public bool UpdateInput()
        {
            if (Console.KeyAvailable)
            {   
                curKey = Console.ReadKey();
                if (curKey == null) return false;
            }
            else
            {
                curKey = null;
            }

            return Console.KeyAvailable;
        }



        public void PlayerControl()
        {
            if (curKey == null) return;
          
            if (curKey.Value.Key == ConsoleKey.LeftArrow) playerPos.X -= 2;
            else if (curKey.Value.Key == ConsoleKey.RightArrow) playerPos.X += 2;
            else if (curKey.Value.Key == ConsoleKey.UpArrow) playerPos.Y = (playerPos.Y <= 0) ? 0 : playerPos.Y - 1;
            else if (curKey.Value.Key == ConsoleKey.DownArrow) playerPos.Y++;
        }


        Point playerPos;
        public void GameLogic()
        {
            while (true)
            {
                UpdateInput();

                PlayerControl();

                buffer.SetBuffer(0, 0, "###############################################################");
                for (int i = 1; i < 24; i++)
                    buffer.SetBuffer(1, i, new string(' ', 48));
                buffer.SetBuffer(0, 0, "#############################################################");

                buffer.SetBuffer(playerPos.X, playerPos.Y, "Player");

                buffer.SetBuffer(5, 10, "★");
                buffer.SetBuffer(8, 20, "★");


                buffer.Render();
            }
        }
    }
}
