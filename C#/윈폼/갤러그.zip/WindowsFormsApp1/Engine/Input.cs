﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.Lib
{
    /// <summary>
    /// 사용자 입력정보를 관리하는 클래스입니다.
    /// Unity 스타일로 구성하였습니다.
    /// </summary>
    public class Input
    {
        // 입력된 키 정보
        static Dictionary<Keys, bool> InputKeys = new Dictionary<Keys, bool>();
        
        public static void Init()
        {
            //Task.Run(() => { Start(); });
        }


        /// <summary>
        /// 이 함수는 현재 키가 눌렸는지에 대한 정보를 반환합니다.
        /// </summary>
        /// <param name="keys"></param>
        /// <returns></returns>
        public static bool GetKeyDown(Keys keys)
        {
            var pressed = false;

            if(InputKeys.ContainsKey(keys))
            {
                pressed = InputKeys[keys];
            }

            return pressed;
        }


        /// <summary>
        /// 이 함수는 최초 실행시 폼에 등록해야 하는 감지 클래스 입니다.
        /// 키의 입력 인풋을 감지합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void UpdateKeyDown(object sender, KeyEventArgs e)
        {
            InputKeys[e.KeyData] = true;
        }


        /// <summary>
        /// 이 함수는 최초 실행시 폼에 등록해야 하는 감지 클래스 입니다.
        /// 키의 입력 아웃을 감지합니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void UpdateKeyUp(object sender, KeyEventArgs e)
        {
            InputKeys[e.KeyData] = false;
        }
    }
}
