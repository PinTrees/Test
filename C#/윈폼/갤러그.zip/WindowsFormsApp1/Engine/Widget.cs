﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Lib;

// 개발중
// 클래스 설계가 완성되지 않았습니다.
// 목표 - 위젯을 분리하여 기존으 컨트롤을 최상위 Widget 함수로 래핑
// Controll 을 직접 상속 및 각 오버라이드 함수 구현 - OnPaint()

// 위젯 스테이트 관리 클래스 구현
// 각 위젯의 스타일 데이터 클래스 구현
namespace WindowsFormsApp1.Source
{
    public class Widget : Control
    {
    }

    public class TextStyle
    {
        public float fontSize;
    }

    /// <summary>
    /// 이 프로젝트에서는 해당 위젯만 변경하여 사용합니다.
    /// </summary>
    public class Text : Label
    {
        TextStyle style;
        public Transform transform;
        public Text(string text, TextStyle _style=null, Color? color=null, float fontSize=24)
        {
            Font = new Font(Font.FontFamily, fontSize, FontStyle.Bold);
            transform = new Transform(this);
            transform.Position = new Vector2(0, 0);
            transform.LocalSize = new Vector2(200, 32);

            ForeColor = color ?? Color.White;
            BackColor = Color.Black;
            Text = text;    
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(0, BackColor)))
            {
                e.Graphics.DrawString(Text, Font, brush, ClientRectangle);
            }
            base.OnPaint(e);
        }
    }
    
    public class SizedBox : Widget
    {

    }

    // StatusBar
    public class AppBar : Widget
    {
        public Text title;

        public AppBar(string _title="")
        {
            title = new Text(_title);
        }
    }





    // 개발 테스트 중인 코드입니다.
    public class Scaffold : Widget
    {
        public AppBar AppBar { get; set; }
        public Widget Body { get; set; }

        public Scaffold() { }
        public void Init(AppBar appbar=null, Widget body=null)
        {
            AppBar = appbar ?? new AppBar();
            Body = body ?? new SizedBox();   
        }
    }
}



