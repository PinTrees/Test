﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Engine
{
    /// <summary>
    /// 이 함수는 기존 랜덤을 래핑한 클래스입니다.
    /// Unity 스타일로 변경되었습니다.
    /// </summary>
    public class RandomT
    {
        private static Random t = new Random(); 
        public static int Range(int start, int limit)
        {
            return t.Next(start, limit);
        }
    }
}
