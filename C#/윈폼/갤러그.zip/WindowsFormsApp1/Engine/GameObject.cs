﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Lib;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 이 함수는 2D 엔진에서 사용되는 게임오브젝트 상속클래스 입니다.
    /// 반복자 및 최초 실행자가 구현되어 있습니다.
    /// 유니티 스타일로 구현하였습니다.
    /// </summary>
    public class GameObject : PictureBox
    {
        // Control 의 Tag 와 별개의 게임오브젝트 구분 값 입니다.
        public string tag = "";
        
        // 현재 게임오브젝트의 위지 클래스 입니다.
        public Transform transform;


        public GameObject(string _tag=null) {
            tag = _tag ?? "";
            transform = new Transform(this);

            Start();
        }

        /// <summary>
        /// 이 함수는 재정의 할수 있는 게임오브젝트의 최초 실행자 입니다.
        /// 생성자 바로 직후 호출됩니다.
        /// </summary>
        public virtual void Start()
        {

        }


        /// <summary>
        /// 이 함수는 런타임중 게임오브젝트를 생성할 경우 호출하는 함수입니다.
        /// 런타임시 업데이트 및 게임오브젝트를 엔진에 등록합니다.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static T Instantiate<T>(T data)
        {
            try
            {
                Hierarchy.I.AddGameObject(data as GameObject);
                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return data;
            }
        }


        /// <summary>
        /// 이 함수는 런타임중 게임오브젝트를 제거하는 함수 입니다.
        /// 컨트롤 및 엔진에 등록된 로직을 제거합니다.
        /// </summary>
        /// <param name="data"></param>
        public static void Destroy(GameObject data)
        {
            try
            {
                Hierarchy.I.RemoveGameObject(data);
                data.Disposed();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());    
            }
        }


        // 제거예정 코드 
        public void SetImage(Image img)
        {
            Image = img;
            BackColor = Color.Transparent;
            SizeMode = PictureBoxSizeMode.StretchImage;
        }



        /// <summary>
        /// 이 함수는 두 물체가 충돌했을경우 엔진에서 호출해 주는 함수입니다.
        /// 상속 클래스에서 재정의하여 사용할 수 있습니다.
        /// </summary>
        /// <param name="target">충돌된 상대 물체입니다.</param>
        public virtual void OnTriggerEnter(GameObject target)
        {

        }


        /// <summary>
        /// 이 함수는 재정의 가능한 반복 호출 함수입니다.
        /// </summary>
        public virtual void Update()
        {

        }



        /// <summary>
        /// 그리기 재정의
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Color.Transparent);
            // 이미지의 회전 중심점을 설정합니다.
            e.Graphics.TranslateTransform(Size.Width / 2, Size.Height / 2);
            // Graphics 내장 함수를 이용하여 오브젝트를 각도로 회전시킵니다. 
            e.Graphics.RotateTransform((float)transform.Rotation);
            // 이미지의 중심점을 재구성합니다.
            e.Graphics.TranslateTransform(-Size.Width / 2, -Size.Height / 2);
            // 이미지를 출력합니다.
            if (Image != null)
            {
                // 기존의 사이즈모드를 적용합니다.
                Rectangle destinationRect = new Rectangle(0, 0, Size.Width, Size.Height);
                // 적용된 스타일로 비트맵을 렌더링합니다.
                e.Graphics.DrawImage(Image, destinationRect, new Rectangle(Point.Empty, Image.Size), GraphicsUnit.Pixel);
            }
            //base.OnPaint(e);
        }


        /// <summary>
        /// 이 함수는 게임오브젝트가 제거될때 엔진에서 호출해주는 함수입니다.
        /// 재정의 가능
        /// </summary>
        public virtual void Disposed()
        {

        }
    }
}
