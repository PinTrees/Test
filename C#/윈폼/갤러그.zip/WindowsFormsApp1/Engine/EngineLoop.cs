﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Source
{
    public class EngineFrame
    {

    }

    /// <summary>
    /// 교수님이 작성하신 엔진 루프를 간소화 하여 사용
    /// </summary>
    public class EngineLoop : EngineFrame
    {
        protected int m_InStartGameTick = 0;
        protected int m_CurrentTick = 0;
        protected int m_DeltaTick = 0;

        public int CurrentTick { get => m_CurrentTick; }
        public int DeltaTick { get => m_DeltaTick; }


        public event Action UpdateAction;
        public event Action RenderAction;

        int DelayTickCount = 0;

        // 이 함수는 엔진에 등록된 업데이트 함수를 정해진 프레임마다 반복적으로 호출합니다.
        public async void Start(int? p_delay=null)
        {
            DelayTickCount = p_delay ?? 24;
            m_InStartGameTick = Environment.TickCount;

            while (true)
            {
                await Task.Delay(DelayTickCount);
                m_DeltaTick = Environment.TickCount - m_CurrentTick;
                m_CurrentTick += m_DeltaTick;

                if (UpdateAction != null) UpdateAction();
                if (RenderAction != null) RenderAction();
            }
        }

        public void Pause()
        {

        }
    }
}
