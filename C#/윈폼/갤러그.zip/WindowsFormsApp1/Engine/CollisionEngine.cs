﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 이 클래스는 엔진의 충돌 관리 로직 클래스 입니다.
    /// </summary>
    public class CollisionEngine : EngineLogic
    {
        List<GameObject> objectList = new List<GameObject>();   
        public CollisionEngine() { }

        public CollisionEngine Init()
        {
            // 충돌을 관리할 오브젝트 목록을 연결합니다.
            objectList = Hierarchy.I.objects;
            return this;
        }


        // 엔진에서 호출해 주는 함수입니다.
        // 매 프레임마다 호출됩니다.
        public override void MainFrameUpdate()
        {
            // 충동 처리시 충돌 로직과 게임오브젝트의 제거에 의한 리스트 변경 및 각 로직들과 매우 강하게 연결되어 있으므로
            // 각 목록의 완벽한 관리가 불가능하다고 판단되어 try catch 간단한 오류처리로 변경
            try
            {
                // 보유한 모든 오브젝트목록을 검사합니다.
                // 충돌이 필요한 객체들만 검사하도록 변경이 필요합니다.
                foreach (var obj1 in objectList)
                {
                    foreach (var obj2 in objectList)
                    {
                        // 해당 오브젝트가 충돌되었는지 검사합니다.
                        bool isColliding = Vector2.Collision(obj1.transform.Position, obj1.transform.LocalSize,
                                              obj2.transform.Position, obj2.transform.LocalSize);

                        // 충돌되었을 경우 각 객체의 충돌됨 함수를 호출합니다.
                        if (isColliding)
                        {
                            obj1.OnTriggerEnter(obj2);
                            obj2.OnTriggerEnter(obj1);
                        }
                    } 
                }
            }
            catch (Exception e)
            { 
            }
        }
    }
}
