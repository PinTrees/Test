﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;

namespace WindowsFormsApp1.Lib
{
 
    /// <summary>
    /// 컨트롤의 위치 및 크기를 제어하는 클래스 입니다.
    /// 유니티 스타일로 구현하였습니다.
    /// </summary>
    public class Transform
    {
        // 제어하는 컨트롤 정보입니다.
        Control control;
        // 컨트롤의 위지정보 입니다.
        Vector2 position;
        // 컨트롤의 크기정보 입니다.
        Vector2 localSize;

        // 컨트롤의 회전 정보입니다.
        double angle = 0;

        public double Rotation { get => angle; }
        public Vector2 LocalSize { get => localSize;
            set => SetLocalSize(value);
        }
        public Vector2 Position { get => position;
            set => SetPosition(value);
        }


        /// <summary>
        /// 트랜스폼 생성자 입니다.
        /// 인자값으로 생성시 초기화하도록 변경
        /// 생성시 위치 및 크기는 0, 1로 초기화
        /// </summary>
        /// <param name="ctr">제어할 컨트롤</param>
        public Transform(Control ctr) {
            control = ctr;
            Position = Vector2.Zero;
            LocalSize = new Vector2(1, 1);
        }


        /// <summary>
        /// 이 함수는 컨트롤의 크기를 변경합니다.
        /// </summary>
        /// <param name="size"></param>
        public void SetLocalSize(Vector2 size) {
            localSize = size;
            control.Size = localSize.ToSize();
        }


        /// <summary>
        /// 이 함수는 오브젝트를 해당 좌표를 바라보는 각도로 회전시킵니다.
        /// </summary>
        /// <param name="target"></param>
        public void LookAtRotation(Vector2 target)
        {
            // 목표 위치와 현재 위치의 차이를 계산합니다.
            double deltaX = target.x - position.x;
            double deltaY = target.y - position.y;

            // 아크탄젠트 함수를 사용하여 두 점 사이의 각도를 계산합니다.
            // radian: 목표 위치와 현재 위치 사이의 아크탄젠트 값을 계산한 라디안 값
            double radian = Math.Atan2(deltaY, deltaX);

            // 라디안 값을 각도로 변환합니다. (라디안 * 180 / π)
            // 갤러그 이미지 각도 조절/ 360으로 설정되었습니다.
            angle = radian * 360 / Math.PI;
        }


        /// <summary>
        /// 이 함수는 컨트롤의 위치를 변경합니다.
        /// </summary>
        /// <param name="pos"></param>
        public void SetPosition(Vector2 pos)
        {
            position = pos;
            control.Location = pos.ToPoint();
        }


        /// <summary>
        /// 이 함수는 현재 트랜스폼의 좌표을 입력받은 좌표 내로 제한합니다.
        /// </summary>
        /// <param name="clamp">제한할</param>
        public void ClampPosition(Vector2 min, Vector2 max)
        {
            if (position.x < min.x) position.x = min.x;
            if(position.y < min.y) position.y = min.y;

            if(position.x + localSize.x > max.x) position.x = max.x - localSize.x;
            if (position.y + localSize.y > max.y) position.y = max.y - localSize.y;

            control.Location = position.ToPoint();
        }

    }
}
