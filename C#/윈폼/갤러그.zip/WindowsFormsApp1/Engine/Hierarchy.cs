﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 이 클래스는 엔진의 최상위 구성클래스 입니다.
    /// 엔진에 등록되는 모든 정보를 관리합니다.
    /// 싱글톤 형태로 구현되었으나 구조 변경이 필요합니다.
    /// 
    /// 게임상에 존재하는 모든 게임오브젝트를 관리합니다.
    /// 엔진에 등록된 모든 모듈을 관리합니다.
    /// 루프, 충돌
    /// </summary>
    public class Hierarchy : Singleton<Hierarchy>
    {
        // 실행되는 폼 정보입니다.
        Form form;

        // 기초 루프 엔진입니다.
        public EngineLoop loopEngine;

        // 엔진 모듈 목록입니다.
        public List<EngineLogic> logicEngine = new List<EngineLogic>();

        // 게임내 존재하는 모든 오브젝트 목록입니다.
        public List<GameObject> objects = new List<GameObject>();

        public override void Init()
        {
            base.Init();
        }


        /// <summary>
        /// 이 함수는 초기화자 입니다.
        /// 폼 초기화 후 즉시 호출해 주세요.
        /// </summary>
        /// <param name="form"></param>
        public void Initailize(Form form=null)
        {
            this.form = form;
            loopEngine = new EngineLoop();
            loopEngine.Start();

        }


        /// <summary>
        /// 이 함수는 로직 생성 함수 입니다.
        /// 폼생성 후 즉시 호출해 필요한 엔진 모듈을 추가하세요.
        /// </summary>
        /// <param name="logic"></param>
        public void CreateLogic(EngineLogic logic)
        {
            logicEngine.Add(logic);
            loopEngine.UpdateAction += logic.MainFrameUpdate;
        }



        /// <summary>
        /// 이 함수는 계층 구조에서 컨트롤을 추가합니다.
        /// 이 프로젝트에서만 사용될 임시 함수 입니다.
        /// UI 관련 오브젝트들의 클래스 상속구조 재구성 필요
        /// </summary>
        /// <param name="data"></param>
        public void AddControlObject(Control data)
        {
            // 컨트롤에 추가합니다.
            form.Controls.Add(data);
            form.Controls.SetChildIndex(data, 0);
        }


        /// <summary>
        /// 이 함수는 계층 구조에서 게임오브젝트를 추가합니다.
        /// 이 함수는 엔진에서 사용하는 함수입니다.
        /// </summary>
        /// <param name="data"></param>
        public void AddGameObject(GameObject data)
        {
            // 컨트롤에 추가 및 엔진에 등록합니다.
            form.Controls.Add(data);
            form.Controls.SetChildIndex(data, 0);
            objects.Add(data);
            loopEngine.UpdateAction += data.Update;
        }


        /// <summary>
        /// 이 함수는 계층 구조에서 게임오브젝트를 제거합니다.
        /// 이 함수는 엔진에서 사용하는 함수입니다.
        /// </summary>
        /// <param name="data"></param>
        public void RemoveGameObject(GameObject data)
        {
            // 컨트롤 해지 및 엔진에서 제거합니다.
            data.Dispose();
            objects.Remove(data);
            loopEngine.UpdateAction -= data.Update;
        }
    }
}
