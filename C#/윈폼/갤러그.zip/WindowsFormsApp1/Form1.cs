﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Class;
using WindowsFormsApp1.Lib;
using WindowsFormsApp1.Properties;
using WindowsFormsApp1.Source;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1() 
        {
            InitializeComponent();
            ResizeRedraw = true;
            DoubleBuffered = true;
            
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);

            Input.Init();
            this.KeyDown += Input.UpdateKeyDown;
            this.KeyUp += Input.UpdateKeyUp;

            Hierarchy.I.Initailize(form: this);
            Hierarchy.I.CreateLogic(new GallagLogic().Init());
            Hierarchy.I.CreateLogic(new CollisionEngine().Init());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Activate();
            this.Focus();
        }

        private void SelectImageMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Focus();
        }

    }
}
