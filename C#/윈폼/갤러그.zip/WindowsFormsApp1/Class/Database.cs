﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1.Class
{
    /// <summary>
    /// 간단한 게임 데이터 관리 클래스 입니다.
    /// </summary>
    public class Database
    {
        public static Dictionary<string, StageData> stageDataMap = new Dictionary<string, StageData>();
        public static Dictionary<string, MonsterGroupData> monsterGroupDataMap = new Dictionary<string, MonsterGroupData>();
        public static Dictionary<char, MonsterData> monsterDataMap = new Dictionary<char, MonsterData>();

        // 파일처리 로 변경이 필요한 코드입니다.
        public static void InitializeMonsterGroupData()
        {
            // 파일처리 로 변경이 필요한 코드입니다.
            var m0 = new MonsterGroupData();
            m0.children = new string[] { "022101220", "100101001", "102101201", "011101110" };
            m0.startCurve = new Vector2[] {
                new Vector2(150, 0),
                new Vector2(125, 100),
                new Vector2(100, 200),

                new Vector2(-100, 300),
                new Vector2(0, 400),
                new Vector2(150, 450),
                new Vector2(200, 450),
                new Vector2(150, 200),
                new Vector2(150, 150),
            };


            var m1 = new MonsterGroupData();
            m1.children = new string[] { "022101220", "100101001", "102101201", "011101110" };
            m1.startCurve = new Vector2[] {
                new Vector2(150, 0),
                new Vector2(175, 75),
                new Vector2(175, 150),
                new Vector2(200, 200),

                new Vector2(500, 300),
                new Vector2(400, 400),
                new Vector2(150, 450),
                new Vector2(200, 450),
                new Vector2(150, 200),
                new Vector2(150, 150),
            };




            var m2 = new MonsterGroupData();
            m2.children = new string[] { "023101320", "103303301", "002303200", "013101310" };
            m2.startCurve = new Vector2[] {
                new Vector2(170, 0),
                new Vector2(170, 100),
                new Vector2(170, 200),
                new Vector2(170, 300),
                new Vector2(200, 400),
                new Vector2(200, 450),
                new Vector2(300, 450),
                new Vector2(300, 200),
                new Vector2(300, 150),
            };





            var m3 = new MonsterGroupData();
            m3.children = new string[] { "123303321", "014404410", "044404440", "022202220" };
            m3.startCurve = new Vector2[] {
                new Vector2(150, 0),
                new Vector2(175, 75),
                new Vector2(175, 150),
                new Vector2(200, 200),

                new Vector2(500, 300),
                new Vector2(400, 400),
                new Vector2(150, 450),
                new Vector2(200, 450),
                new Vector2(150, 200),
                new Vector2(150, 150),
            };



            monsterGroupDataMap["0"] = m0;
            monsterGroupDataMap["1"] = m1;
            monsterGroupDataMap["2"] = m2;
            monsterGroupDataMap["3"] = m3;
        }
        // 파일처리 로 변경이 필요한 코드입니다.
        public static void InitializeMonsterData()
        {
            var m1 = new MonsterData(image: Resources._3, hp: 1, score: 100);
            var m2 = new MonsterData(image: Resources._7, hp: 2, score: 200);
            var m3 = new MonsterData(image: Resources._8, hp: 2, score: 250);
            var m4 = new MonsterData(image: Resources._9, hp: 3, score: 300);

            monsterDataMap['1'] = m1;
            monsterDataMap['2'] = m2;
            monsterDataMap['3'] = m3;
            monsterDataMap['4'] = m4;
        }
        // 파일처리 로 변경이 필요한 코드입니다.
        public static void InitailizeStageData()
        {
            var s1 = new StageData();
            s1.groupList = new string[] { "1", "0" };

            var s2 = new StageData();
            s2.groupList = new string[] { "1", "2", "0" };

            var s3 = new StageData();
            s3.groupList = new string[] { "1", "2", "3" };

            stageDataMap["0"] = s1;
            stageDataMap["1"] = s2;
            stageDataMap["2"] = s3;
        }



        /// <summary>
        /// 이 함수는 데이터베이스에서 몬스터 웨이브 정보를 가져옵니다.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static MonsterGroupData GetMonsterGroupData(string code)
        {
            return monsterGroupDataMap[code] ?? new MonsterGroupData();
        }



        /// <summary>
        /// 이 함수는 몬스터 정보를 가져옵니다.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static MonsterData GetMonsterData(char code)
        {
            return monsterDataMap[code] ?? new MonsterData();
        }


        /// <summary>
        /// 이 함수는 스테이지 정보를 가져옵니다.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static StageData GetStageData(string code)
        {
            return stageDataMap[code] ?? new StageData();
        }
    }
}
