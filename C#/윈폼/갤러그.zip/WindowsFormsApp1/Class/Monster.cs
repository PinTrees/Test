﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Engine;
using WindowsFormsApp1.Properties;
using WindowsFormsApp1.Source;

namespace WindowsFormsApp1.Class
{
    public class MonsterGroupData
    {
        public string[] children;
        public Vector2[] startCurve;
    }

    public class MonsterData
    {
        public Image image;
        public int HP;
        public int score;

        public MonsterData(Image image=null, int? hp=null, int? score=null)
        {
            this.HP = hp ?? 1;
            this.image = image ?? Resources._3;
            this.score = score ?? 100;
        }
    }




    /// <summary>
    /// 몬스터를 제어하기 위한 클래스 입니다.
    /// </summary>
    public class Monster : GameObject
    {
        // 몬스터의 데이터 클래스입니다.
        MonsterData data;

        // 현재 몬스터의 관리클래스 입니다.
        MonsterGroup parent;
        // 몬스터의 2차원 배열의 좌표
        Vector2Int posIndex;

        // 몬스터의 Idle 상태 이동 좌표
        List<Vector2> stayPos = new List<Vector2>();
        // 몬스터의 생성시 이동 좌표 - 베지어 곡선 좌표값
        List<Vector2> startCurves = new List<Vector2>();
        // 몬스터 탈출시 이동 좌표
        List<Vector2> outCurves = new List<Vector2>();

        // 몬스터의 스테이터스 정의
        int HP = 1;
        float MoveSpeed = 1.5f;
        float StaySpeed = 1f;

       
        // 몬스터의 상태를 구분할 변수입니다.
        int state = 0;

        // 몬스터가 Idle 상태에서 화면밖으로 나갈 때 까지의 시간입니다.
        // 해당 값에 일정 소수값을 곱하여 사용합니다.
        int outTime = 0;

        // 초기화자 입니다.
        public void Init(MonsterGroup parent, Vector2Int index, MonsterData data)
        {
            // 데이터 연결
            this.data = data;
            this.parent = parent;
            posIndex = index;

            // 몬스터가 생성되고 자신의 위치까지 이동하는 경로를 정의합니다.
            startCurves = parent.groupData.startCurve.ToList();
            var lastPos = new Vector2(8 + posIndex.x * 40, 38 + posIndex.y * 32);
            startCurves.Add(lastPos);

            // 몬스터가 제자리에서 이동하는 Idle 포지션을 정의합니다.
            stayPos.Add(new Vector2(lastPos.x - 50, lastPos.y));
            stayPos.Add(new Vector2(lastPos.x + 50, lastPos.y));

            var gap = 300; 
            var c = RandomT.Range(100, 400);

            // 몬스터가 Idle 상태에서 화면 밖으로 이동하는 경로를 정의합니다.
            // 외부 데이터로 변경해야 합니다.
            outCurves.Add(new Vector2(lastPos.x, lastPos.y - 25));
            outCurves.Add(new Vector2(lastPos.x + 50, lastPos.y - 50));
            outCurves.Add(new Vector2(lastPos.x + 50, 100));
            outCurves.Add(new Vector2(c, 200));
            outCurves.Add(new Vector2(c, 250));
            outCurves.Add(new Vector2(c - gap, 300));
            outCurves.Add(new Vector2(c - gap, 400));
            outCurves.Add(new Vector2(c + gap, 500));
            outCurves.Add(new Vector2(c + gap, 600));
            outCurves.Add(new Vector2(c - gap, 600));
            outCurves.Add(new Vector2(c - gap, 700));
            outCurves.Add(new Vector2(c, 800));
            outCurves.Add(new Vector2(c, 1000));


            // 몬스터 생성시 초기 좌표를 설정합니다.
            transform.Position = startCurves.First();
            transform.LocalSize = new Vector2(28, 28);
            
            outTime = RandomT.Range(1, 50);
            
            HP = data.HP;
            SetImage(data.image);
        }


        /// <summary>
        /// 이 함수는 몬스터의 HP를 감소시킵니다.
        /// </summary>
        /// <param name="d">HP 감소량</param>
        public void Dammaged(int d)
        {
            HP -= d;
            if(HP <= 0)
            {
                parent.monsters.Remove(this);
                GameObject.Destroy(this);
                UIManager.I.AddScore(data.score);
            }
        }


        // 엔진 충돌 호출함수 오버라이드
        public override void OnTriggerEnter(GameObject target)
        {
            // 충돌된 게임오브젝트가 플레이어일 경우
            if(target is Player)
            {
                // 자기 자신 제거
                Dammaged(999);
                // 플레이어 데미지 추가
                (target as Player).Dammaged(1);
            }
        }



        /// <summary>
        /// 이 함수는 몬스터가 Idle 상태에서 탈출 상태로 변경시 총알을 발사하는 로직입니다.
        /// </summary>
        public async void CreateBullet()
        {
            int count = 0;

            // 몬스터가 살아있을 경우 총알을 2발 발사합니다.
            while (count < 2 && HP > 0)
            {
                count++;
                await Task.Delay(300);

                // 몬스터 총알 오브젝트를 생성합니다.
                var m = GameObject.Instantiate<MBullet>(new MBullet());
                m.transform.Position = transform.Position + new Vector2(16, 20);
            }
        }



        // 몬스터의 이동을 보간처리합니다. 0 ~ 1 사이값
        // 해당값은 디폴트 보간 값이며 이동속도를 곱하여 사용하게 됩니다.
        float a = 0.01f;
        float currentAmount = 0;        // 몬스터 생성 ~ 자신의 위치로 이동시 사용 
        float currentStayAmount = 0;    // 자신의 위치 ~ 좌우로 이동시 사용  
        float currentOutAmount = 0;     // 자신의 위치 ~ 탈출경로로 이동시 사용
        public override void Update()
        {
            // 몬스터가 생성중일 경우 
            // 화면의 상단에서 자신의 위치로 이동중일 경우 실행됩니다.
            if(currentAmount <= 1)
            {
                currentAmount += a;

                // 몬스터의 마지막 위치를 계산합니다.
                // Idle 상태에서 좌우로 이동함으로 마지막 위치는 실시간으로 변경됩니다.
                var targetPos = Vector2.Lerp(stayPos[0], stayPos[1], parent.StayAmount * StaySpeed);
                startCurves[startCurves.Count - 1] = targetPos;

                // 베지어 함수를 사용하여 경로상의 위치를 계산합니다.
                var pos = Vector2.Curves(startCurves, currentAmount * MoveSpeed);
                transform.LookAtRotation(pos);
                transform.Position = pos;
                return;
            }

            // 몬스터가 자신의 위치에서 좌우로 이동할 때 호출됩니다.
            else if(currentStayAmount <= 1)
            { 
                currentStayAmount += a * outTime * 0.05f;
                // Idle 상태의 좌우이동 경로의 좌표를 설정합니다.
                // 몬스터웨이브 부모의 공통된 값을 사용하여 모든 하위 몬스터 오브젝트가 함께 좌우로 이동시킵니다.
                transform.Position = Vector2.Lerp(stayPos[0], stayPos[1], parent.StayAmount * StaySpeed);
            }

            // 몬스터가 자신의 위치에서 화면 밖으로 이동할 때 호출됩니다.
            else if(currentOutAmount <= 1)
            {
                if (currentOutAmount == 0)
                {
                    // 탈출경로의 첫번쨰 좌표를 현재좌표로 설정합니다.
                    outCurves.Insert(0, transform.Position);
                    // 몬스터 탈출시 총알을 발사합니다.
                    CreateBullet();
                }

                currentOutAmount += a;
                // 몬스터의 탈출 경로를 베지어 곡선 함수로 계산합니다.
                var pos = Vector2.Curves(outCurves, currentOutAmount);
                transform.LookAtRotation(pos);
                transform.Position = pos;
            }

            // 몬스터가 화면 밖으로 완전히 사라졌을 때 호출됩니다.
            if(currentOutAmount > 1)
            {
                // 객체 제거
                parent.monsters.Remove(this);
                GameObject.Destroy(this);
            }
        }
    }
}
