﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 이 클래스는 간단한 파티클 오브젝트 입니다.
    /// </summary>
    public class Particle : GameObject
    {
        public int Tick = 25;
        List<Image> images = new List<Image>();

        public override void Start()
        {
            // 추후 인자값을 통한 파티클 값 설정방식 제공
            SetImage(Resources._6);
            transform.LocalSize = new Vector2(10, 10);

            ParticleSystem();
        }

        public void Init()
        {
        }


        // 간소 구현이므로 재사용 클래스 설계시 변경되어야 합니다.
        public async void ParticleSystem()
        {
            // 파티클 오브젝트의 크기 및 위지 조정
            await Task.Delay(Tick);
            transform.LocalSize += new Vector2(10, 10);
            transform.Position -= new Vector2(10, 10) * 0.5f;

            await Task.Delay(Tick);
            transform.LocalSize += new Vector2(15, 15);
            transform.Position -= new Vector2(15, 15) * 0.5f;

            await Task.Delay(Tick);
            transform.LocalSize += new Vector2(20, 20);
            transform.Position -= new Vector2(20, 20) * 0.5f;

            await Task.Delay(Tick);

            // 오브젝트 제거
            GameObject.Destroy(this);
        }
    }
}
