﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector;
using WindowsFormsApp1.Source;

namespace WindowsFormsApp1.Class
{
    /// <summary>
    /// 몬스터 군체의 움직임을 구현하기 위한 클래스입니다.
    /// </summary>
    public class MonsterGroup : GameObject
    {
        // 몬스터 생성 딜레이 입니다.
        public int SponeTick = 250;
        // 몬스터 Idle 모션 틱입니다.
        public float StayTick = 0.01f;

        // 몬스터 웨이브 정보입니다.
        public MonsterGroupData groupData;
        // 생성되어있는 몬스터 목록입니다.
        public List<Monster> monsters = new List<Monster>();


        public MonsterGroup(MonsterGroupData data)
        {
            groupData = data;
            CreateMonster();
        }


        /// <summary>
        /// 이 함수는 몬스터 웨이브가 종료되었는지를 반환합니다.
        /// </summary>
        /// <returns>웨이브가 종료되었을 경우 true 아닐경우 false 입니다.</returns>
        public bool IsClear()
        {
            if (DelayOver > 1f && monsters.Count <= 0) return true;
            else return false;
        }
         

        /// <summary>
        /// 이 함수는 웨이브에 포함된 몬스터 목록을 소환합니다.
        /// </summary>
        public async void CreateMonster()
        {
            // 데이터 정보 [ "11111", "1111", "1111", "1111" ]
            int y = 0;
            foreach (var str in groupData.children)
            {
                int x = 0;
                y++;
                foreach (var c in str.ToCharArray())
                {
                    x++;
                    // 빈칸
                    if (c == '0') continue;

                    // 몬스터를 생성합니다.
                    var ms = GameObject.Instantiate<Monster>(new Monster());
                    ms.Init(this, new Vector2Int(x, y), Database.GetMonsterData(c));
                    monsters.Add(ms);

                    await Task.Delay(SponeTick);
                }
            }
        }

        public float DelayOver = 0;
        public float StayAmount = 0;

        // 반복자 재정의
        public override void Update()
        {
            // 이 값은 웨이브 클리어를 계산할 때 즉시 계산될 경우 빈 목록을 클리어로 확인하여 일정 시간 후 부터 검사하도록 제한하는 용도로 사용됩니다.
            // 변경이 필요한 코드 입니다.
            DelayOver += Math.Abs(StayTick);

            // 이 함수는 군체의 하위 목록 전체를 움직이기 위한 값입니다.
            StayAmount += StayTick;

            // 좌우 또는 상하로 움직이므로 값은 증가하고 다시 감소하는 형태여야 합니다.
            if (StayAmount > 1) StayTick = StayTick * -1;
            else if (StayAmount < 0) StayTick = StayTick * -1;
        }
    }
}
