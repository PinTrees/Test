﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Class;
using WindowsFormsApp1.Lib;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1.Source
{

    public class MapDataInfo
    {
        public static readonly Vector2 MapSize = new Vector2(400, 550);
    }



    /// <summary>
    /// 이 클래스는 플레이어 게임오브젝트를
    /// </summary>
    public class Player : GameObject
    {
        // 프로퍼티로 변경
        public int HP = 3;
        public int MoveSpeed = 10;
        public int BulletCreateTick = 250;

        public bool IsDie { get => HP <= 0; }
        List<Bullet> bullets = new List<Bullet>();

        // 초기화자 재정의
        public override void Start()
        {
            // 위치와 크기를 설정합니다.
            transform.Position = new Vector2(150, 500);
            transform.LocalSize = new Vector2(32, 32);
            SetImage(Resources._1);

            // 총알 발사로직을 실행합니다.
            BulletTask();

            UIManager.I.SetHpText(hp: HP);
        }


        /// <summary>
        /// 이 함수는 해당 게임오브젝트가 제거될떄 호출되는 함수입니다.
        /// </summary>
        public override void Disposed()
        {
            // 플레이어를 사망상태로 정의합니다.
            // 게임오브젝트와 연결된 Task 함수를 종료하기 위해 사용됩니다.

            // 비동기 반복 함수를 외부에서 강제종료하는 다른 방법으로 변경할 필요가 있습니다.
            HP = 0;
        }


        /// <summary>
        /// 이 함수는 플레이어의 Hp를 감소시킵니다.
        /// </summary>
        /// <param name="hp"></param>
        public void Dammaged(int hp)
        {
            HP -= hp;
            UIManager.I.SetHpText(hp: HP);
        }

        /// <summary>
        /// 이 함수는 일정시간마다 총알을 발사합니다.
        /// </summary>
        public async void BulletTask()
        {
            // 플레이어가 제거되었을 경우 로직을 종료합니다.
            while(!IsDie)
            {
                await Task.Delay(BulletCreateTick);

                var bullet = GameObject.Instantiate<Bullet>(new Bullet());
                bullet.transform.Position = transform.Position + new Vector2(14, -20);
                bullets.Add(bullet);
            }
        }


        // 반복함수 재정의
        public override void Update()
        {
            // 키입력을 감지합니다.
            var dir = Vector2.Zero;
            if (Input.GetKeyDown(Keys.W) || Input.GetKeyDown(Keys.Up)) dir += Vector2.Up;
            if (Input.GetKeyDown(Keys.A) || Input.GetKeyDown(Keys.Left)) dir += Vector2.Left;
            if (Input.GetKeyDown(Keys.S) || Input.GetKeyDown(Keys.Down)) dir += Vector2.Down;
            if (Input.GetKeyDown(Keys.D) || Input.GetKeyDown(Keys.Right)) dir += Vector2.Right;

            if (dir != Vector2.Zero)
            {
                // 플레이어를 이동시킵니다.
                transform.Position = transform.Position + dir * MoveSpeed;
                // 이동범위를 제한합니다.
                transform.ClampPosition(Vector2.Zero, MapDataInfo.MapSize);
            }
        }
    }
}
