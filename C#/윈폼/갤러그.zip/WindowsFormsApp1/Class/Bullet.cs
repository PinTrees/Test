﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector;
using WindowsFormsApp1.Properties;
using WindowsFormsApp1.Source;

namespace WindowsFormsApp1.Class
{
    /// <summary>
    /// 몬스터의 총알 클래스 입니다.
    /// </summary>
    public class MBullet : GameObject
    {
        // 총알의 방향 정의
        public readonly Vector2 Direction = Vector2.Down;
        // 총알의 이동속도 정의
        public readonly int MoveSpeed = 15;


        // Start 오버라이드
        public override void Start()
        {
            transform.LocalSize = new Vector2(2, 18);
            SetImage(Resources._5);
        }


        // 엔진 호출 충돌함수 오버라이드
        public override void OnTriggerEnter(GameObject target)
        {
            // 충돌된 다른 게임오브젝트가 플레이어일 경우
            if (target is Player) 
            {
                // 총알을 제거합니다.
                GameObject.Destroy(this);

                // 타겟의 데미지를 호출
                (target as Player).Dammaged(1);

                // 폭발 이펙트 생성
                var p = GameObject.Instantiate<Particle>(new Particle());
                p.transform.Position = Vector2.Lerp(target.transform.Position, this.transform.Position, 0.75f);
            }
        }


        // Update 오버라이드
        public override void Update()
        {
            // 현재 오브젝트의 위치를 정의된 방향으로 매 프레임마다 이동시킵니다.
            transform.Position = transform.Position + Direction * MoveSpeed;

            if(transform.Position.y > 1000) GameObject.Destroy(this);
        }
    }





    /// <summary>
    /// 플레이어의 총알 클래스 입니다.
    /// </summary>
    public class Bullet : GameObject
    {
        // 총알의 방향 정의
        public readonly Vector2 Direction = Vector2.Up;
        // 총알의 이동속도 정의
        public readonly int MoveSpeed = 20;


        // Start 오버라이드
        public override void Start()
        {
            transform.LocalSize = new Vector2(8, 18);
            SetImage(Resources._2);
        }


        // 엔진 호출 충돌함수 오버라이드
        public override void OnTriggerEnter(GameObject target)
        {
            // 충돌된 다른 게임오브젝트가 몬스터일 경우
            if(target is Monster)
            {
                // 총알을 제거합니다.
                GameObject.Destroy(this);
                
                // 타겟의 데미지를 호출
                (target as Monster).Dammaged(1);

                // 폭발 이펙트 생성
                var p = GameObject.Instantiate<Particle>(new Particle());
                p.transform.Position = Vector2.Lerp(target.transform.Position, this.transform.Position, 0.75f);
            }
        }


        // Update 오버라이드
        public override void Update()
        {
            // 현재 오브젝트의 위치를 정의된 방향으로 매 프레임마다 이동시킵니다.
            transform.Position = transform.Position + Direction * MoveSpeed;

            if (transform.Position.y < -50) GameObject.Destroy(this);
        }
    }
}
