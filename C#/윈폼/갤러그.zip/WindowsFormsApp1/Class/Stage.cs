﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1.Source;

namespace WindowsFormsApp1.Class
{
    // 스테이지 데이터 클래스
    public class StageData
    {
        public string[] groupList;
        
        public StageData() { }  
    }


    /// <summary>
    /// 이 클래스는 스테이지를 관리합니다.
    /// </summary>
    public class Stage : GameObject
    {
        // 스테이지 정보
        StageData data;

        // 스테이지의 현재 소환된 몬스터 그룹
        MonsterGroup currentWave;

        // 몇 번째 몬스터 웨이브인지를 기록
        int monsterGroupIndex = 0;

        // 외부에서 스테이지를 강제종료할 경우 사용되는 변수입니다.
        bool stopStage = false;


        public Stage(StageData _data) : base()
        {
            this.data = _data;
            StartStage();
        }


        /// <summary>
        /// 이 함수는 스테이지가 클리어되었는지를 반환합니다.
        /// </summary>
        /// <returns></returns>
        public bool IsClear()
        {
            if(data.groupList.Length == monsterGroupIndex)
            {
                return currentWave.IsClear();
            }
            else return false;
        }


        /// <summary>
        /// 이 함수는 스테이지를 종료합니다.
        /// </summary>
        public void StopStage()
        {
            stopStage = true;
        }


        /// <summary>
        /// 이 함수는 스테이지 로직을 시작합니다.
        /// </summary>
        public async void StartStage() 
        {
            // 스테이지 시작 메세지 출력
            await UIManager.I.ShowStageText();

            // 몬스터 웨이브 생성
            var waveData = Database.GetMonsterGroupData(data.groupList[monsterGroupIndex++]);
            currentWave = GameObject.Instantiate<MonsterGroup>(new MonsterGroup(waveData));

            while (true)
            {
                await Task.Delay(100);

                // 외부에서 강제로 스테이지를 종료할 경우 스테이지 종료
                // 현재 몬스터 웨이브가 마지막 웨이브일 경우 스테이지 종료
                if( stopStage ||
                   (currentWave.IsClear() && data.groupList.Length == monsterGroupIndex)) 
                {
                    // 현재 스테이지 및 웨이브 삭제
                    GameObject.Destroy(currentWave);  
                    GameObject.Destroy(this);
                    return;
                }


                // 현재 몬스터 웨이브가 클리어되었는지 확인
                if(currentWave.IsClear())
                {
                    // 신규 몬스터 웨이브 생성
                    GameObject.Destroy(currentWave);
                    waveData = Database.GetMonsterGroupData(data.groupList[monsterGroupIndex++]);
                    currentWave = GameObject.Instantiate<MonsterGroup>(new MonsterGroup(waveData));
                } 
            }
        }


        public override void Update()
        {

        }
    }
}
