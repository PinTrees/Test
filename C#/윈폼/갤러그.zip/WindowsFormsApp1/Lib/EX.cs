﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector;

/** 확장메서드 작성 */
public static class EX
{
    /** 사용되지 않음 */
    public static void ForEach<K, T>(this Dictionary<K, T> a, Action<K, T> fptr)
    {
        for (int i = 0; i < a.Count; i++)
            fptr(a.Keys.ElementAt(i), a.Values.ElementAt(i));
    }

    /** 배열에 대한 반복자 확장메서드 입니다. */
    public static void ForEach<T>(this T[] a, Action<T> fptr)
    {
        for (int i = 0; i < a.Length; i++) fptr(a[i]);
    }






    public static int ToRoundInt(this float a)
    {
        return (int)a;
    }
    public static int Abs(this int a)
    {
        return Math.Abs(a);
    }

    public static Point ToPoint(this Vector2Int pos)
    {
        return new Point(pos.x, pos.y);
    }


    /** 문자열 더하기 반복 확장메서드 입니다. */
    public static string Repeat(this string a, int count)
    {
        if(count > 1000) {
            throw new Exception();
        }

        string str = "";
        for(int i = 0; i < count; i++) str += a;

        return str;
    }



    /** 이 프로젝트에서는 사용되지 않습니다. */
    public static int ToInt(this string str)
    {
        int @int = 0;
        int.TryParse(str, out @int);
        return @int;
    }
    public static float ToFloat(this string str)
    {
        str = str.Replace('f', ' ');
        str.Trim();

        float iiii = 0.0f;
        float.TryParse(str, out iiii);
        return iiii;
    }
}