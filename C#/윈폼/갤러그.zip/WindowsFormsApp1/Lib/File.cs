﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vector
{
    public class FileIO
    {
        public int x;
        public int y;


        public static bool IsImageFile(string path)
        {
            if(path == null) return false;
            if(path == "") return false;
            if (!path.Contains('.')) return false;

            path = path.Trim();

            string[] imageFileData = { "jpg", "jpeg", "png", "gif" };
            return imageFileData.Contains(path.Split('.').Last<string>().ToLower());
        }
    }
}
