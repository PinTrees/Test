﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Vector
{
    /// <summary>
    /// 정수 벡터 타입의 클래스를 class 에서 Value 타입 구조체로 변경하였습니다.
    /// </summary>
    public struct Vector2Int
    {
        public int x;
        public int y;


        // 기초 구현값이 readonly 로 변경되었습니다.
        static readonly Vector2Int zero = new Vector2Int(0, 0);
        static readonly Vector2Int left = new Vector2Int(-1, 0);
        static readonly Vector2Int right = new Vector2Int(1, 0);
        static readonly Vector2Int up = new Vector2Int(0, -1);
        static readonly Vector2Int down = new Vector2Int(0, 1);


        /*** 정적 프로퍼티 입니다. */
        public static Vector2Int Zero { get => zero; }
        public static Vector2Int Up { get => up; }
        public static Vector2Int Down { get => down; }
        public static Vector2Int Right { get => right; }
        public static Vector2Int Left { get => left; }


        /** 이 함수는 비교하는 두 정수벡터가 같은경우 true를 반환합니다. */
        public static bool operator ==(Vector2Int obj1, Vector2Int obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return true;
            else return false;
        }

        /** 이 함수는 비교하는 두 정수벡터가 다른경우 true를 반환합니다. */
        public static bool operator !=(Vector2Int obj1, Vector2Int obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return false;
            else return true;
        }

        /** 이 함수는 두 정수벡터를 더한 값을 반환합니다. */
        public static Vector2Int operator +(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x + b.x, a.y + b.y);
        }
        /** 이 함수는 정수벡터를 정수만큼 곱한 값을 반환합니다. */
        public static Vector2Int operator *(Vector2Int a, int b)
        {
            return new Vector2Int(a.x * b, a.y * b);
        }

        /** 이 함수는 받아온 정수벡터를 자신의 값에 추가합니다. */
        public void Offset(Vector2Int add)
        {
            x += add.x;
            y += add.y;
        }

        /** 이 함수는 비교하는 두 정수벡터가 같을경우 true를 반환합니다. */
        public bool Equal(Vector2Int target)
        {
            if (target.x == x && target.y == y) return true;
            else return false;
        }

        public Vector2Int(int _x, int _y) {
            x = _x; y = _y;
        }
        public Vector2Int(Vector2Int other)
        {
            this.x = other.x;
            this.y = other.y;
        }
    }



    /// <summary>
    /// 벡터 타입의 클래스를 calss 에서 Value 타입 구조체로 변경하였습니다.
    /// 기조 구현 정적 프로퍼티에 대한 구조가 변경되었습니다.
    /// </summary>
    public struct Vector2
    {
        public float x;
        public float y;


        // 기초 구현값이 readonly 로 변경되었습니다.
        static readonly Vector2 zero = new Vector2(0, 0);
        static readonly Vector2 left = new Vector2(-1, 0);
        static readonly Vector2 right = new Vector2(1, 0);
        static readonly Vector2 up = new Vector2(0, -1);
        static readonly Vector2 down = new Vector2(0, 1);


        /*** 정적 프로퍼티 입니다. */
        public static Vector2 Zero { get => zero; }
        public static Vector2 Up { get => up; }
        public static Vector2 Down { get => down; }
        public static Vector2 Right { get => right; }
        public static Vector2 Left { get => left; }


        /// <summary>
        /// 베지어 곡선 일반화 함수 입니다.
        /// p는 2 미만일 수 없습니다.
        /// 첫번채 요소는 시작좌표를 나타냅니다.
        /// 마지막 요소는 도착좌표를 나타냅니다.
        /// </summary>
        /// <param name="p">시작과 경유 목표좌표 목록입니다.</param>
        /// <param name="amount"></param>
        /// <returns></returns>
        public static Vector2 Curves(List<Vector2> p, float amount)
        {
            // 오류 처리 입니다.
            if(amount > 1) return p.Last();
            if(p == null) return zero;
            if (p.Count <= 2) return p.First();


            // 결과 목록이 1개만 남을 때 까지 반복합니다.
            while(p.Count > 1)
            {
                // 보간 결과 목록입니다.
                List<Vector2> t_resultList = new List<Vector2>();

                for (int i = 0; i < p.Count - 1; i++)
                {
                    // 현재 지점과 다음 지점의 선형보간을 통한 위치값 계산
                    Vector2 result = Vector2.Lerp(p[i], p[i + 1], amount);
                    // 계산된 위치 값을 결과값리스트에 대입
                    t_resultList.Add(result);
                }

                // 결과 목록에 대입합니다.
                p = t_resultList;
            }
            
            // 결과 목록이 1개 이므로 해당 값을 반환합니다.
            return p.First();
        }


        /// <summary>
        /// 베지어 곡선 보간 함수입니다
        /// 3 점에 대한 곡선 보간 함수입니다.
        /// </summary>
        /// <param name="a">시작 좌표입니다.</param>
        /// <param name="b">중간 좌표입니다.</param>
        /// <param name="c">도착 좌표입니다.</param>
        /// <param name="amount"></param>
        /// <returns>보간 좌표입니다.</returns>
        public static Vector2 Curve(Vector2 a, Vector2 b, Vector2 c, float amount)
        {
            Vector2 t1 = Vector2.Lerp(a, b, amount);
            Vector2 t2 = Vector2.Lerp(b, c, amount);
            return Vector2.Lerp(t1, t2, amount);
        }


        /// <summary>
        /// 2차원 벡터의 선형보간 함수입니다.
        /// </summary>
        /// <param name="a">시작 좌표 입니다.</param>
        /// <param name="b">목표 좌표 입니다.</param>
        /// <param name="amount">선형 보간 비율입니다.</param>
        /// <returns>보간된 좌표입니다.</returns>
        public static Vector2 Lerp(Vector2 a, Vector2 b, float amount)
        {
            Vector2 res = a;
            res.x = a.x + (b.x - a.x) * amount;
            res.y = a.y + (b.y - a.y) * amount;

            return res;
        }



        /// <summary>
        /// 이 함수는 특정 좌표상에 두 물체에 대한 충돌 체크 함수입니다.
        /// </summary>
        /// <param name="position1">첫번째 목표좌표 입니다.</param>
        /// <param name="size1">첫번째 목표크기 입니다.</param>
        /// <param name="position2">두번째 목표좌표 입니다.</param>
        /// <param name="size2">두번째 목표 크기 입니다.</param>
        /// <returns>충돌 여부 입니다.</returns>
        public static bool Collision(Vector2 position1, Vector2 size1, Vector2 position2, Vector2 size2)
        {
            float left1 = position1.x;
            float right1 = position1.x + size1.x;
            float top1 = position1.y;
            float bottom1 = position1.y + size1.y;

            float left2 = position2.x;
            float right2 = position2.x + size2.x;
            float top2 = position2.y;
            float bottom2 = position2.y + size2.y;

            return !(left1 > right2 || right1 < left2 || top1 > bottom2 || bottom1 < top2);
        }




        /** 이 함수는 비교하는 두 정수벡터가 같은경우 true를 반환합니다. */
        public static bool operator ==(Vector2 obj1, Vector2 obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return true;
            else return false;
        }

        /** 이 함수는 비교하는 두 정수벡터가 다른경우 true를 반환합니다. */
        public static bool operator !=(Vector2 obj1, Vector2 obj2)
        {
            if (obj1.x == obj2.x && obj1.y == obj2.y) return false;
            else return true;
        }

        /** 이 함수는 두 정수벡터를 더한 값을 반환합니다. */
        public static Vector2 operator +(Vector2 a, Vector2 b)
        {
            return new Vector2(a.x + b.x, a.y + b.y);
        }
        public static Vector2 operator -(Vector2 a, Vector2 b)
        {
            return new Vector2(a.x - b.x, a.y - b.y);
        }


        /** 이 함수는 정수벡터를 정수만큼 곱한 값을 반환합니다. */
        public static Vector2 operator *(Vector2 a, int b)
        {
            return new Vector2(a.x * b, a.y * b);
        }

        public static Vector2 operator *(Vector2 a, float b)
        {
            return new Vector2(a.x * b, a.y * b);
        }

        /** 이 함수는 받아온 정수벡터를 자신의 값에 추가합니다. */
        public void Offset(Vector2 add)
        {
            x += add.x;
            y += add.y;
        }

        /** 이 함수는 비교하는 두 정수벡터가 같을경우 true를 반환합니다. */
        public bool Equal(Vector2 target)
        {
            if (target.x == x && target.y == y) return true;
            else return false;
        }


        /// <summary>
        /// Vector2를 Point 로 변환합니다.
        /// </summary>
        /// <returns></returns>
        public Point ToPoint() { 
            return new Point(x.ToRoundInt(), y.ToRoundInt());
        }


        /// <summary>
        /// vector2를 Size 로 변환합니다.
        /// </summary>
        /// <returns></returns>
        public Size ToSize()
        {
            return new Size(x.ToRoundInt(), y.ToRoundInt());
        }



        public Vector2(float _x, float _y)
        {
            x = _x; y = _y;
        }
        public Vector2(Vector2 other)
        {
            this.x = other.x;
            this.y = other.y;
        }
    }
}
