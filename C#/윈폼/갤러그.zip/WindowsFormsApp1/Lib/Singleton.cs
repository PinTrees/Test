﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Singleton<T> where T : class, new()
    {
        static T m_Instance = null;
        public static T I
        {
            get
            {
                if (m_Instance == null)
                {
                    m_Instance = new T();

                    Singleton<T> inst = m_Instance as Singleton<T>;
                    inst.Init();
                }

                return m_Instance;
            }
        }

        public virtual void Init()
        {
        }

        public virtual void Release()
        {
        }
    }
}
