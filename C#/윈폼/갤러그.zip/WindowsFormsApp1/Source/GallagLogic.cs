﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vector;
using WindowsFormsApp1.Class;
using WindowsFormsApp1.Lib;
using static System.Windows.Forms.AxHost;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 이 함수는 임시 엔진구성 클래스 입니다. 다음 프로젝트에서 제거 또는 변경될 예정입니다.
    /// </summary>
    public abstract class EngineLogic
    {
        /// <summary>
        /// 이 함수는 엔진의 매 프레임마다 호출되는 반복 함수 입니다.
        /// 반복 로직을 이곳에 작성하세요.
        /// </summary>
        public abstract void MainFrameUpdate();

        public virtual void LateUpdate() {}
    }


    /// <summary>
    /// 갤러그 로직 관리 클래스 입니다.
    /// </summary>
    public class GallagLogic : EngineLogic
    {
        Player player;

        Stage currentStage = null;
        int stageIndex = 0;

        int state = 0;

        public GallagLogic Init()
        {
            // 초기화
            UIManager.I.Initialize();
            Database.InitailizeStageData();
            Database.InitializeMonsterData();
            Database.InitializeMonsterGroupData();

            // 플레이어 생성
            player = GameObject.Instantiate<Player>(new Player());

            return this;
        }


        /// <summary>
        /// 이 함수는 게임을 재시작합니다.
        /// </summary>
        public void Restart()
        {
            state = 0;
            stageIndex = 0;
            UIManager.I.Clear();
            player = GameObject.Instantiate<Player>(new Player());
        }


        /// <summary>
        /// 이 함수는 스테이지를 시작하고 종료될 때 까지 대기합니다.
        /// </summary>
        public async void StageLoad()
        {
            var data = Database.GetStageData(stageIndex++.ToString());
            currentStage = GameObject.Instantiate<Stage>(new Stage(data));
        }


        // 엔진에서 일정 주기마다 반복 호출됩니다.
        public override void MainFrameUpdate()
        {
            // 게임이 클리어 상태일 경우
            if(state == 1)
            {
                // 키 입력을 감지합니다.
                if (Input.GetKeyDown(Keys.R))
                {
                    // 재시작
                    Restart();
                }
                return;
            }

            // 게임오버 상태일 경우
            if (player == null)
            {
                // 키 입력 감지
                if (Input.GetKeyDown(Keys.R))
                {
                    // 재시작
                    Restart();
                }

                return;
            }

            // 플레이어가 사망했을 경우
            else if (player.IsDie)
            {
                // 사망 로직 싫행
                UIManager.I.ShowRestartUI();
                GameObject.Destroy(player);
                player = null;

                currentStage.StopStage();
                currentStage = null;

                return;
            }
            else
            {
                // 현재 스테이지가 존재할 경우
                if (currentStage != null)
                {
                    // 클리어 상태를 확인합니다.
                    if (currentStage.IsClear())
                    {
                        // 마지막 스테이지일 경우
                        if(stageIndex >= 3)
                        {
                            // 게임 클리어 로직 실행 
                            currentStage.StopStage();
                            UIManager.I.ShowClearUI();
                            GameObject.Destroy(player);
                            player = null;
                            state = 1;
                            return;
                        }
                        // 마지막 스테이지가 아닐경우
                        else
                        {
                            // 스테이지를 초기화 합니다.
                            currentStage.StopStage();
                            currentStage = null;
                        }
                    }
                }
                // 스테이지가 초기화 되었을 경우
                else
                {
                    // 스테이지를 소환합니다.
                    StageLoad();
                }
            }
        }
    }
}
