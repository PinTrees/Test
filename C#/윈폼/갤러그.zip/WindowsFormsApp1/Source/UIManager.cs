﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector;

namespace WindowsFormsApp1.Source
{
    /// <summary>
    /// 간단하게 모든 UI를 이곳에처 처리하는 형태로 구현
    /// </summary>
    public class UIManager : Singleton<UIManager>
    {
        // 스코어 정보는 다른 위치에서 보유하고 있어야 합니다.
        int score = 0;
        // 스테이지 인덱스 정보도 다른 매니저가 보유해야 합니다.
        int stageIndex = 0;

        // 스코어 UI
        Text scoreText = null;
        // 스테이지 UI 
        Text stageText = null;
        // 재시작 UI
        Text restartText = null;
        // 플레이어 HP UI
        Text hpText = null;

        public UIManager() { }

        // 초기화자
        public void Initialize()
        {
            // UI 를 생성하고 초기화 후 엔진에 등록합니다.
            // Widget 클래스 설계 후 변경됩니다.
            // Hierarchy.I.AddControlObject(scoreText);
            // UI는 게임오브젝트를 상속받지 못하므로 엔진에 직접등록해야 합니다.
            
            scoreText = new Text("000000");
            Hierarchy.I.AddControlObject(scoreText);

            stageText = new Text("", color: Color.Blue);
            stageText.transform.Position = new Vector2(100, 250);
            stageText.transform.LocalSize = new Vector2(250, 36);
            Hierarchy.I.AddControlObject(stageText);

            restartText = new Text("", color: Color.White, fontSize: 18);
            restartText.transform.LocalSize = new Vector2(250, 36);
            restartText.transform.Position = new Vector2(80, 300);
            Hierarchy.I.AddControlObject(restartText);

            hpText = new Text("", color: Color.Cyan, fontSize: 16);
            hpText.transform.Position = new Vector2(0, 540);
            Hierarchy.I.AddControlObject(hpText);
        }


        // UI를 초기화합니다.
        public void Clear()
        {
            score = 0;
            scoreText.Text = score.ToString();
            ClearStageText();
            ClearRestartUI();
        }


        // HP 를 표시합니다.
        public void SetHpText(int hp)
        {
            hpText.Text = $"HP : {hp}";
        }


        // 스코어를 표시합니다.
        public void AddScore(int _score)
        {
            score += _score;
            scoreText.Text = score.ToString();
        }


        // 스테이지 UI를 초기화합니다.
        public void ClearStageText()
        {
            stageText.Text = "";
            stageIndex = 0;
        }


        // 스테이지 UI를 표시합니다.
        public async Task ShowStageText()
        {
            stageText.Text = $"Stage {(stageIndex++ + 1)}";
            await Task.Delay(1000);
            stageText.Text = "";
        }


        // 재시작 UI를 표시합니다.
        public void ShowRestartUI()
        {
            restartText.Text = "Restart to Pressed R";
        }


        // 재시작 UI를 초기화합니다.
        public void ClearRestartUI()
        {
            restartText.Text = "";
        }


        // 클리어 UI를 표시합니다.
        public void ShowClearUI()
        {
            stageText.Text = $"Game Clear";
            restartText.Text = "Restart to Pressed R";
        }
    }
}
