#include "WaitGameState.h"
#include "GameContext.h"


void WaitGameState::StartGame(GameContext* context) {
	if (context->GetCurrentState()->state == Wait) {
		context->SetState(context->GetPlayGameState());
		SetTimer(context->GetHwnd(), 1, 1000, NULL);
		context->CreateCircle();
	}	
}


void WaitGameState::WaitFor(GameContext* context) {
}


void WaitGameState::OnClick(GameContext* context) {
}

void WaitGameState::CreateCircle(GameContext* context) {
}