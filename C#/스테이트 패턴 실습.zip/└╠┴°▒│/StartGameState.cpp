#include "StartGameState.h"
#include "GameContext.h"


void StartGameState::StartGame(GameContext* context) {
	if (context->GetCurrentState()->state == Wait) {
		context->SetState(context->GetPlayGameState());
	}
	else if (context->GetCurrentState()->state == Play) {
	}
}


void StartGameState::WaitFor(GameContext* context) {
}

void StartGameState::OnClick(GameContext* context) {
}

void StartGameState::CreateCircle(GameContext* context) {
}