#pragma once
#include "GameState.h"
#include "Global.h"

class Vector2Int;

class PlayGameState : public GameState {
public:
	int currentCircleCount = 0;
	int scCount = 0;
	Vector2Int* currentCirclePos;

	PlayGameState();

	void StartGame(GameContext* context) override;
	void OnClick(GameContext* context) override;
	void CreateCircle(GameContext* context) override;
	void WaitFor(GameContext* context) override;
};