#pragma once
#include "GameState.h"
#include "Global.h"

class WaitGameState : public GameState {
public:
	WaitGameState() {
		state = GAMESTATE::Wait;
	}

	void StartGame(GameContext* context) override;
	void WaitFor(GameContext* context) override;
	void OnClick(GameContext* context) override;
	void CreateCircle(GameContext* context) override;
};