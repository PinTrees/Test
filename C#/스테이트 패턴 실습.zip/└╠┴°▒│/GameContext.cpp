#include "GameContext.h"
#include "Vector2.h"
#include <iostream>

void GameContext::Build(Buffur* buf) {
	Vector2Int* pos = playGameState->currentCirclePos;
	buf->Paint([&](HDC hdc) {
		char szText[] = "���� ��";
		char num_char[] = "���� ��";

		TextOut(hdc, 100, 100, szText, lstrlen(szText));
		TextOut(hdc, 100, 200, szText, lstrlen(szText));
		Ellipse(hdc, pos->x, pos->y, pos->x + 50, pos->y + 50);
	});

}