#pragma once
#include "GameState.h"
#include "Global.h"

class StartGameState : public GameState {
public:
	StartGameState() {
		state = GAMESTATE::Start;
	}


	void StartGame(GameContext* context) override;
	void OnClick(GameContext* context) override;
	void CreateCircle(GameContext* context) override;
	void WaitFor(GameContext* context) override;
};

