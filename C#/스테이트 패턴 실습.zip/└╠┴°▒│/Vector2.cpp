#include "Vector2.h"

//Vector2* Vector2::Zero = new Vector2(0, 0);