#pragma once

class MenuID {

};