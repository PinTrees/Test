#pragma once
#include <windows.h>
#include <windowsx.h>

class Vector2 {
public:
	Vector2(LPARAM lParam) {
		x = GET_X_LPARAM(lParam);
		y = GET_Y_LPARAM(lParam);
	}
	Vector2(float x, float y) {
		this->x = x;
		this->y = y;
	}
	Vector2() {}
	~Vector2() {}

	//static Vector2* Zero;

	float x;
	float y;
};




class Vector2Int {
public:
	Vector2Int(LPARAM lParam) {
		x = GET_X_LPARAM(lParam);
		y = GET_Y_LPARAM(lParam);
	}
	Vector2Int(int x, int y) {
		this->x = x;
		this->y = y;
	}
	Vector2Int() {}
	~Vector2Int() {}

	//static Vector2* Zero;

	int x;
	int y;

	int Distance(Vector2Int* target) {
		int xxx = x; int yyy = y;
		if (xxx < 0) xxx * -1;
		if (yyy < 0) yyy * -1;

		int xxxx = target->x; int yyyy = target->y;
		if (xxxx < 0) xxxx * -1;
		if (yyyy < 0) yyyy * -1;

		int xx = xxx - xxxx;
		int yy = yyyy - yyyy;


		if (xx < 0) xx * -1;
		if (yy < 0) yy * -1;

		if (xx > yy) return xx;
		else return yy;
	}
};


