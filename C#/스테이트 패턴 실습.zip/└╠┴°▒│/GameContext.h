#pragma once
#include "GameState.h"
#include "PlayGameState.h"
#include "WaitGameState.h"
#include "StartGameState.h"
#include <windows.h>

class GameContext {
private:
	HWND hWnd; 

	PlayGameState* playGameState;
	WaitGameState* waitGameState;
	StartGameState* startGameState;

	GameState* currentState;

public:
	GameContext(HWND hWnd) {
		playGameState = new PlayGameState();
		waitGameState = new WaitGameState();
		startGameState = new StartGameState();
		currentState = (GameState*)waitGameState;
		this->hWnd = hWnd;
	}

	PlayGameState* GetPlayGameState() {
		return playGameState;
	}
	WaitGameState* GetWaitGameState() {
		return waitGameState;
	}
	StartGameState* GetStartGameState() {
		return startGameState;
	}

	GameState* GetCurrentState() {
		return currentState;
	}

	HWND GetHwnd() {
		return hWnd;
	}


	void SetState(GameState* state) {
		currentState = state;
	}

	void OnClick() {
		currentState->OnClick(this);
	}

	void StartGame() {
		currentState->StartGame(this);
	}

	void CreateCircle() {
		currentState->CreateCircle(this);
		InvalidateRect(hWnd, NULL, FALSE);
	}

	void Build(Buffur* buf);
};
