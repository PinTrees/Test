#include "Buffur.h"

void Buffur::Init() {
}

void Buffur::Paint(std::function<void(HDC)> fptr) {
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC memdc = CreateCompatibleDC(hdc);
	RECT rect;
	GetClientRect(hWnd, &rect); 
	
	memBitmap = CreateCompatibleBitmap(memdc, rect.right, rect.bottom);
	HBITMAP oldBitmap = (HBITMAP)SelectObject(memdc, memBitmap);
	FillRect(memdc, &rect, (HBRUSH)GetStockObject(WHITE_BRUSH));


	/// ����Ʈ ó�� �ܺ� ���ٽ� 
	fptr(memdc);


	BitBlt(hdc, 0, 0, rect.right, rect.bottom, memdc, 0, 0, SRCCOPY);
	SelectObject(memdc, oldBitmap);
	DeleteObject(memBitmap);
	DeleteDC(memdc);
	EndPaint(hWnd, &ps);
}