#include "WindowFrame.h"


WindowFrame* WindowFrame::instance = nullptr;
GameContext* WindowFrame::context = nullptr;
Buffur* WindowFrame::buffur = nullptr;

WindowFrame* WindowFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new WindowFrame();
	
	instance->g_hInst = hInstance;
	instance->currentDraw = nullptr;
	instance->mousePosList = new List<List<Mouse*>*>(); 
	instance->drawObjList = new List<DrawObject*>();

	return instance;
}
WindowFrame* WindowFrame::Instance() {
	return instance;
}
void WindowFrame::Dispose() {
	if (instance != nullptr) { delete instance; instance = nullptr; }
}



void WindowFrame::Init() {
}

void WindowFrame::Build() { 
	LPCTSTR lpszClass = TEXT("First"); 
	WNDCLASS WndClass; 

	WndClass.cbClsExtra = 0; 
	WndClass.cbWndExtra = 0; 
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = g_hInst;
	WndClass.lpfnWndProc = WndProc; 
	WndClass.lpszClassName = lpszClass; 
	WndClass.lpszMenuName = lpszClass;
	//WndClass.lpszMenuName = NULL; 
	WndClass.style = CS_HREDRAW | CS_VREDRAW; 
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		NULL, (HMENU)NULL, g_hInst, NULL);
	ShowWindow(hWnd, SW_SHOW);

	buffur = new Buffur(hWnd);
	context = new GameContext(hWnd);
}

void WindowFrame::Run(MSG* Message) {
	TranslateMessage(Message);
	DispatchMessage(Message);
}

HMENU hMenu, hSubMenu;
LRESULT CALLBACK WindowFrame::WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc = NULL;
	switch (iMessage) {
	case WM_CREATE:
	{
		Mouse::isDown = false; 

		CreateWindow(TEXT("button"), TEXT("Start Game"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			20, 20, 100, 25, hWnd, (HMENU)0, instance->g_hInst, NULL); 
		break;
	}

	case WM_TIMER: {
		if (lParam == 0) {
			context->CreateCircle();
		}
	}
	case WM_LBUTTONDOWN:
	{
		Mouse::isDown = true;
		Mouse::SetInput(lParam);
		context->OnClick();
		break;
	}
	case WM_LBUTTONUP:
	{
		instance->currentDraw = nullptr;
		Mouse::isDown = false;
	}
	/*case WM_MOUSEMOVE:
	{
		break;
	}*/
	case WM_KEYDOWN:
		break;
	case WM_PAINT:
		context->Build(buffur);
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case 0:
			context->StartGame();
			break;
		}
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
