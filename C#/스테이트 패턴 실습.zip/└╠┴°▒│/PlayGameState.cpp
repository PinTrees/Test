#include "PlayGameState.h"
#include "GameContext.h"
#include "Vector2.h"
#include "Mouse.h"

PlayGameState::PlayGameState() {
	state = GAMESTATE::Play;
	currentCirclePos = new Vector2Int(0, 0);
}



void PlayGameState::StartGame(GameContext* context) {
	if (context->GetCurrentState()->state == GAMESTATE::Play) {
		currentCircleCount = 0;
		scCount = 0;
	}
	context->SetState(context->GetPlayGameState());
}



void PlayGameState::OnClick(GameContext* context) {
	if (context->GetCurrentState()->state == GAMESTATE::Play) {
		if (currentCirclePos->Distance(new Vector2Int(Mouse::x, Mouse::y)) < 50) {
			scCount++;
		}
	}
}



void PlayGameState::CreateCircle(GameContext* context) {
	if (context->GetCurrentState()->state == GAMESTATE::Play) {
		if (currentCircleCount < 10) {
			currentCirclePos = new Vector2Int(rand() % 1200, rand() % 800);
			currentCircleCount++;
		}
		else {
			currentCircleCount = 0;
			currentCirclePos = new Vector2Int(0, 0);
			KillTimer(context->GetHwnd(), 1);
			context->SetState(context->GetWaitGameState());
			MessageBox(NULL, "Hello, World!", "���� ��", MB_OK | MB_ICONINFORMATION);
		}
	}
}



void PlayGameState::WaitFor(GameContext* context) {
}