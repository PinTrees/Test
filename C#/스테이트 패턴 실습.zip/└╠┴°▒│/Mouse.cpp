#include "Mouse.h"

bool Mouse::isDown = false;
float Mouse::x = 0;
float Mouse::y = 0;