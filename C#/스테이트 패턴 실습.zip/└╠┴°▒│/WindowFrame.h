#pragma once
#include <windows.h>
#include <windowsx.h>
#include "list.h"
#include "Mouse.h"
#include "Buffur.h"
#include "DrawObject.h"
#include "GameContext.h"

class WindowFrame {
private:
	static WindowFrame* instance;
	HWND hWnd;
	HINSTANCE g_hInst;

	static GameContext* context;
	static Buffur* buffur;

	List<List<Mouse*>*>* mousePosList; 

	List<DrawObject*>* drawObjList;
	DrawObject* currentDraw;

	int curState = 0;

	WindowFrame() {}
	~WindowFrame() {}

public:
	static WindowFrame* Create(HINSTANCE hInstance);
	static WindowFrame* Instance();
	static void Dispose();

	void Init();
	void Build();
	void Run(MSG* Message);

	static LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
};