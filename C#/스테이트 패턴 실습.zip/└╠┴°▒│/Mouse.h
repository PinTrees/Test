#pragma once
#include <windows.h>
#include <windowsx.h>


/// ���콺 �Է¿� ���� ��ǲŬ���� �Դϴ�.
class Mouse {
public:
	static bool isDown;
	static float x;
	static float y;

	Mouse(float _x, float _y) {
		x = _x;
		y = _y;
	}


	static void SetInput(float x, float y) {
		Mouse::x = x; Mouse::y = y;
	}
	static void SetInput(LPARAM lParam) {
		x = GET_X_LPARAM(lParam);
		y = GET_Y_LPARAM(lParam);
	}
};