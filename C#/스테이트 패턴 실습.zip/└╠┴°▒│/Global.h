#pragma once

enum GAMESTATE {
	Play,
	Wait,
	Start,
	End,
	None,
};
