#pragma once
#include <windows.h>
#include "Buffur.h"
#include "Global.h"

class GameContext;

class GameState {

public:
	// �����ʿ�
	GAMESTATE state; 

	GameState() {
		state = GAMESTATE::None;
	}
	virtual void StartGame(GameContext* context) = 0; 
	virtual void ExiteGame(GameContext* context) {};
	virtual void OnClick(GameContext* context) = 0;
	virtual void CreateCircle(GameContext* context) = 0;
	virtual void WaitFor(GameContext* context) = 0;
};
