﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        int width = 0;
        int height = 0;
        List<Label> labelList = new List<Label>();   
        public Form1()
        {
            InitializeComponent();

            width = Size.Width;
            height = Size.Height;

            CreateLabel();
            timer1.Start();
            timer2.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        Random rand = new Random();
        private void CreateLabel()
        {
            for (int i = 0; i < 2; i++)
            {
                var x = rand.Next(0, width);
                var y = rand.Next(0, height / 5);
                var str = Data.strDataList.Random();

                var label = new Label();
                label.AutoSize = true;
                label.Location = new System.Drawing.Point(x, y);
                label.Name = "label" + i.ToString();
                label.Size = new System.Drawing.Size(41, 12);
                label.Text = str;
                labelList.Add(label);
                Controls.Add(label);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Label> removed = new List<Label>();
            bool firstOnly = false;

            labelList.ForEach((label) => { 
                if (label.Text.Equals(inputText.Text) && !firstOnly) {
                    firstOnly = true;
                    removed.Add(label);
                }
            });

            removed.ForEachT((data) => labelList.RemoveReturn(data).Dispose()).Clear();
            inputText.Text = "";
        }

        private void inputText_KeyDown(object sender, KeyEventArgs e)
        {
            timer1_Tick(null, null);

            if (e.KeyCode == Keys.Enter)
            {
                button1_Click(null, null);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateLabel();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            List<Label> removed = new List<Label>();

            labelList.ForEach((label) => {
                Point point = label.Location;
                point.Y += 5;
                label.Location = point;

                if(point.Y > height - (height * 0.3f)) removed.Add(label);
            });

            removed.ForEachT((data) => labelList.RemoveReturn(data).Dispose()).Clear();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            CreateLabel();
        }
    }
}
