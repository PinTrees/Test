﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace WindowsFormsApp1
{
    internal static class EX
    {
        static Random rand = new Random();

        /// 이 함수는 데이터 배열 목록의 무작위 요소 하나를 반환합니다.
        public static T Random<T>(this T[] dataList)
        {
            return dataList.ElementAt(rand.Next(0, dataList.Length - 1));
        }


        public static T RemoveReturn<T>(this List<T> list, T data)
        {
            list.Remove(data);
            return data;
        }

        public static List<T> ForEachT<T>(this List<T> list, Action<T> fun)
        {
            list.ForEach(x => fun(x));
            return list;
        }


        /// 이 함수는 데이터 리스트 목록의 무작위 요소 하나를 반환합니다.
        public static T Random<T>(this List<T> dataList)
        {
            return dataList.ElementAt(rand.Next(0, dataList.Count - 1));
        }

        /// 이 함수는 데이터 Dictionary 목록의 무작위 값 요소 하나를 반환합니다.
        public static T Random<K,T>(this Dictionary<K,T> dataList)
        {
            return dataList.Values.ElementAt(rand.Next(0, dataList.Values.Count - 1));
        }
    }
}
