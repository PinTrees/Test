﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Data
    {
        public static string[] strDataList =
        {
            "코딩",
            "데이터",
            "도구",
            "그룹",
            "항목",
            "상자",
            "컨트롤",
            "빌드",
            "디버그",
            "테스트",
            "분석",
            "도구",
            "확장",
            "창",
            "도움말",
            "검색",
            "파일",
            "편집",
            "보기",
            "프로젝트",
            "시작",
            "일반",
            "솔루션",
            "탐색기",
            "로그인",
        };
    }
}
