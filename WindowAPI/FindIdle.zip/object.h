#pragma once

class Rect {
	int topLeft;
	int btmLeft;

};

class Box {
public:
	int size = 0;
	int x = 0;
	int y = 0;

	bool isDisbale = false;

	int r;
	int g;
	int b;

	Box() {

	}

	Box(int) {

	}

	bool isCollision(int x, int y) {
		return true;
	}
};