#include <windows.h>
#include "object.h"
#include "list.h"
#include "player.h"

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
LPSTR lpszClass="FindIdle";
HWND hWndMain;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance, LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;
	
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow); 
	hWndMain = hWnd; 

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}

	return Message.wParam;
}

Box** objects;				// ������Ʈ
Player* player;				// �÷��̾�

int score = 0;				// ����
int gameCount = 30;			// Ÿ�̸�
int width = 0;				// â ���� ũ��
int height = 0;				// â ���� ũ��
HBITMAP hBit = NULL;

HDC SelectObjectHDC(HDC hdc, HGDIOBJ dd) {
	SelectObject(hdc, dd);
	return hdc;
}

void DrawBitmap(HDC hdc, HBITMAP hBit)
{
	HBITMAP OldBitmap;
	BITMAP bit;

	HDC MemDC = CreateCompatibleDC(hdc);
	OldBitmap = (HBITMAP)SelectObject(MemDC, hBit);

	GetObject(hBit, sizeof(BITMAP), &bit);
	BitBlt(hdc, 0, 0, bit.bmWidth, bit.bmHeight, MemDC, 0, 0, SRCCOPY);

	DeleteDC(SelectObjectHDC(MemDC, OldBitmap));
}

void OnRefesh()
{
	RECT crt;
	GetClientRect(hWndMain, &crt);
	HDC hdc = GetDC(hWndMain);
	if (hBit == NULL) hBit = CreateCompatibleBitmap(hdc, crt.right, crt.bottom);
	HDC hMemDC = CreateCompatibleDC(hdc);
	HBITMAP OldBit = (HBITMAP)SelectObject(hMemDC, hBit);

	FillRect(hMemDC, &crt, GetSysColorBrush(COLOR_WINDOW));

	TCHAR str[128];
	TCHAR gameTimerStr[128];
	wsprintf(str, TEXT("���� ������ %d�� �Դϴ�."), score);
	wsprintf(gameTimerStr, TEXT("���� �ð� %d��"), gameCount);
	TextOut(hMemDC, 10, 40, str, lstrlen(str));
	TextOut(hMemDC, 10, 5, gameTimerStr, lstrlen(gameTimerStr));

	player->DrawCall(hMemDC);
	for (int i = 0; i < 10; i++) objects[i]->DrawCall(hMemDC);

	DeleteDC(SelectObjectHDC(hMemDC, OldBit));
	ReleaseDC(hWndMain, hdc);  

	InvalidateRect(hWndMain, NULL, FALSE);
}


void CreateObject()
{
	for (int i = 0; i < 10; i++) {
		Box* box = new Box();
		objects[i] = box->SetObjectFromData(i % 2, width - 60, height - 60);
	}
}
void ResponeObject()
{
	for (int i = 0; i < 10; i++) {
		objects[i]->SetObjectFromData(i % 2, width - 60, height - 60);
	}
}


// �浹 ���� �Լ�
bool CollisionCheck() {
	bool flag = false;
	for (int i = 0; i < 10; i++) {
		if (objects[i]->isDisbale) continue;

		RECT* rect3 = new RECT();
		if (IntersectRect(rect3, player->GetRect(), objects[i]->GetRect())) {
			// �������� �������� �ʰ�, ��Ȯ�� ���а� ������� ���� �ʿ�
			if (objects[i]->r == 255) score--;
			else if (objects[i]->b == 255) score++;

			flag = objects[i]->isDisbale = true;
		}
	}
	return flag;
}

void Init() {
	HDC hdc = GetDC(hWndMain);
	RECT rectT;
	GetClientRect(hWndMain, &rectT);

	if (hBit == NULL) hBit = CreateCompatibleBitmap(hdc, rectT.right, rectT.bottom);
	HDC hMemDC = CreateCompatibleDC(hdc);

	HBITMAP OldBit = (HBITMAP)SelectObject(hMemDC, hBit);

	FillRect(hMemDC, &rectT, GetSysColorBrush(COLOR_WINDOW));

	SelectObject(hMemDC, OldBit);
	DeleteDC(hMemDC);
	ReleaseDC(hWndMain, hdc);

	InvalidateRect(hWndMain, NULL, FALSE);

	width = rectT.right - rectT.left;
	height = rectT.bottom - rectT.top;

	player = new Player();
	player->SetPositin(0, 50);
	objects = new Box * [10];
	CreateObject();
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	BOOL bPress;
	RECT winSize;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd; 
		Init();
		SetTimer(hWnd, 1, 30, NULL);
		SetTimer(hWnd, 2, 1000, NULL);
		SetTimer(hWnd, 3, 2000, NULL);
		return 0;
		 
	case WM_ACTIVATEAPP:
		if (wParam) {
			SetTimer(hWnd, 1, 30, NULL);
		}
		else { 
			KillTimer(hWnd, 1);
		}
		return 0;

	case WM_TIMER:
		OnRefesh();

		switch (wParam)
		{
		case 1:
			bPress = FALSE;
			if (GetKeyState(VK_LEFT) & 0x8000 && player->x > 0 ) {
				player->x -= 20;
				bPress = TRUE;
			}
			if (GetKeyState(VK_RIGHT) & 0x8000 && player->x < width - 40) {
				player->x += 20;
				bPress = TRUE;
			}
			if (GetKeyState(VK_UP ) & 0x8000 && player->y > 0) {
				player->y -= 20;
				bPress = TRUE;
			}
			if (GetKeyState(VK_DOWN) & 0x8000 && player->y < height - 40) {
				player->y += 20;
				bPress = TRUE;
			}

			if (bPress) {
				RECT rt;
				SetRect(&rt, player->x - 100, player->y - 100, player->x + 100, player->y + 100);
				if (CollisionCheck()) {
					//InvalidateRect(hWnd, NULL, TRUE);
				}
			}
			break;
		case 2:
			gameCount--;
			break;
		case 3:
			ResponeObject();
			break;
		default:
			break;
		}
		if (gameCount <= 0) {
			KillTimer(hWnd, 1);
			KillTimer(hWnd, 2);
			KillTimer(hWnd, 3);
			KillTimer(hWnd, 4);
		}

		return 0;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		if (hBit) DrawBitmap(hdc, hBit);
		EndPaint(hWnd, &ps); 
		return 0;

	case WM_DESTROY:
		if (hBit) DeleteObject(hBit); 
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
