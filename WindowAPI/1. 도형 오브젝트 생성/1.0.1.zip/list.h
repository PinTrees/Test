﻿#pragma once
#include <iostream>

using namespace std;

// 나중에 단일연결 리스트로 변경

template<typename T> struct Node
{
	Node* next = nullptr;
	Node* prev = nullptr;
	T value;

	Node(T _value)
	{
		value = _value;
	}
	Node(T _value, Node* _next, Node* _prev)
	{
		value = _value;
		next = _next;
		prev = _prev;
	}
};

template<typename T>
class List
{
public:
	Node<T>* first;
	Node<T>* last;
	int count;

public:
	List() : first(NULL), last(NULL), count(0)
	{
	}
	~List()
	{
		clear();
	}

public:
	int add(T item)
	{
		Node<T>* newNode = new Node<T>(item);
		if (count == 0)
		{
			first = newNode;
			last = newNode;
			newNode->next = NULL;
			newNode->prev = NULL;
		}
		else
		{
			newNode->next = NULL;
			newNode->prev = last;
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}

	int remove(T item)
	{
		Node<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}
	int remove(int index)
	{
		int i = 0;
		Node<T>* pThis = first; 
		while (pThis)
		{
			if (i == index) 
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;

			i++;
		}
		return count;
	}

	T elementAt(int index) {
		Node<T>* node = nullptr;
		if (first == NULL) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != NULL) node = node->next;
			else return nullptr;
		}
		return node->value;
	}


	void clear()
	{
		Node<T>* pThis = first;
		while (pThis)
		{
			Node<T>* pDelete = pThis;

			if (pThis->prev)
				pThis->prev->next = pThis->next;
			if (pThis->next)
				pThis->next->prev = pThis->prev;

			pThis = pThis->next;

			delete pDelete;
			--count;
		}
		first = NULL;
		last = NULL;
	}

	int getSize()
	{
		return count;
	}
	void printAll()
	{
		if (count > 0)
		{
			Node<T>* pThis = first;
			while (pThis)
			{
				//cout << pThis->value << endl;
				pThis = pThis->next;
			}
		}
	}
};
//template<typename T>




// Map �� entry ������ ���� ����Ʈ �����Լ� ���� ��
template<typename T> class Iterable
{
public:
	Node<T>* first; // ù��° ���
	Node<T>* last;  // ������ ���
	int count;

public:
	// ���� ������ ȣ��� �Բ� �ʱ�ȭ
	Iterable() : first(nullptr), last(nullptr), count(0)
	{
	}
	~Iterable()
	{
		clear();
	}

	// ����Ʈ Ŭ����
	void clear()
	{
		// ���� ��尡 nullptr �϶� ���� ��ȸ�ϸ� ����
		Node<T>* pThis = first;
		while (pThis)
		{
			Node<T>* pDelete = pThis;

			// != nullptr
			// 1-2-3    /   2-3-4   /   3-4-5
			// 1-2-4    /   X-X-X   /   2-4-5
			if (pThis->prev)
			{
				pThis->prev->next = pThis->next;
			}
			if (pThis->next)
			{
				pThis->next->prev = pThis->prev;
			}

			pThis = pThis->next;

			//cout << "delete list node: " << pDelete << endl;
			delete pDelete;
			--count;
		}
		first = nullptr;
		last = nullptr;
	}

	// ������ �ű� ��� �߰�
	int add(T item)
	{
		// �ű� ��� ����
		if (count == 0)
		{
			Node<T>* newNode = new Node<T>(item, nullptr, nullptr);
			first = newNode;
			last = newNode;
		}
		else
		{
			Node<T>* newNode = new Node<T>(item, nullptr, last);
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}

	T elementAt(int index) {
		Node<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	T elementAtIn(int index) {
		Node<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return first->value;
		}
		return node->value;
	}


	int remove(T item)
	{
		Node<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}
	void printAll()
	{
		if (count > 0)
		{
			Node<T>* pThis = first;
			while (pThis)
			{
				//cout << pThis->value << endl;
				pThis = pThis->next;
			}
		}
	}
};