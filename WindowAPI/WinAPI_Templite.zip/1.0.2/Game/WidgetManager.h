#pragma once
#include "list.h"
#include "Widget.h"
#include "intMap.h"

#define MAINMENU 1000

class WidgetManager {
private:
	WidgetManager() {}
	~WidgetManager() {}
	WidgetManager(const WidgetManager& ref) {}
	WidgetManager& operator=(const WidgetManager& ref) {}


	List<Widget*> eventWidgets;
	Widget* root;

	List<Widget*> sortLayer;

public:
	IntMap<Widget*> widgetT;

	static WidgetManager* Instance() {
		static WidgetManager s;
		return &s;
	}

	/**
	* Widget root Builder
	* 
	* sorting layer
	*/
	void Build(HDC hdc) {
		widgetT.values.ForEach([&](Widget* data) {
			if(data != nullptr)
				data->Build(hdc);
		}); 
		//root->Build();
	}
};