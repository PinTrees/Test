#pragma once
#include <windows.h>
#include <iostream>

#ifdef GLOBAL_H_
#define GLOBAL_H_

HBITMAP hBit;
HWND hEdit_Input;
WNDPROC OldEditProc;
static float objectSpeed = 0;

#endif




