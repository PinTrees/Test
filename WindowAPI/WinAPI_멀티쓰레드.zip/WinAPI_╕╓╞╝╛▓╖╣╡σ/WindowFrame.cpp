#include "WindowFrame.h"


WindowFrame* WindowFrame::instance = nullptr;
HANDLE* WindowFrame::ev = new HANDLE[4];
int WindowFrame::height = 0;
int WindowFrame::width = 0;

WindowFrame* WindowFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new WindowFrame();
	
	instance->g_hInst = hInstance;
	instance->buttonList = new List<HWND>();
	instance->circlesList = new List<Circle*>();
	return instance;
}
WindowFrame* WindowFrame::Instance() {
	return instance;
}
void WindowFrame::Dispose() {
	if (instance != nullptr) { delete instance; instance = nullptr; }
}


void WindowFrame::Init() {
}

void WindowFrame::Build() { 
	LPCTSTR lpszClass = TEXT("First"); 
	WNDCLASS WndClass; 

	WndClass.cbClsExtra = 0; 
	WndClass.cbWndExtra = 0; 
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = g_hInst;
	WndClass.lpfnWndProc = WndProc; 
	WndClass.lpszClassName = lpszClass; 
	WndClass.lpszMenuName = lpszClass;
	//WndClass.lpszMenuName = NULL; 
	WndClass.style = CS_HREDRAW | CS_VREDRAW; 
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		NULL, (HMENU)NULL, g_hInst, NULL);
	ShowWindow(hWnd, SW_SHOW);

	buffur = new Buffur(hWnd);
}

void WindowFrame::Run(MSG* Message) {
	TranslateMessage(Message);
	DispatchMessage(Message);
}


#define ID_R1 101
#define ID_R2 102
#define ID_R3 103
#define ID_R4 104

HMENU hMenu, hSubMenu;
LRESULT CALLBACK WindowFrame::WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_CREATE:
	{
		hMenu = CreateMenu();
		SetMenu(hWnd, hMenu);
		Mouse::isDown = false;

		GetClientRect(hWnd, &instance->rect);
		instance->height = instance->rect.bottom;
		instance->width = instance->rect.right;

		float w = instance->width * 0.5;	
		float h = instance->height * 0.5;

		instance->buttonList->Add(CreateWindow("button", "��ư 1", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			w - 120, h - 40, 100, 25, hWnd, (HMENU)ID_R1, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 2", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			w * 2 - 120, h - 40, 100, 25, hWnd, (HMENU)ID_R2, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 3", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			w - 120, h * 2 - 40, 100, 25, hWnd, (HMENU)ID_R3, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 4", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		 (w * 2 - 120), (h * 2 - 40), 100, 25, hWnd, (HMENU)ID_R4, instance->g_hInst, NULL)); 


		ev[0] = CreateEvent(NULL, FALSE, FALSE, NULL);
		ev[1] = CreateEvent(NULL, FALSE, FALSE, NULL);
		ev[2] = CreateEvent(NULL, FALSE, FALSE, NULL);
		ev[3] = CreateEvent(NULL, FALSE, FALSE, NULL);

		CloseHandle(CreateThread(NULL, 0, CirclePaintThread, (LPVOID)0, 0, NULL));
		CloseHandle(CreateThread(NULL, 0, CirclePaintThread, (LPVOID)1, 0, NULL));
		CloseHandle(CreateThread(NULL, 0, CirclePaintThread, (LPVOID)2, 0, NULL));
		CloseHandle(CreateThread(NULL, 0, CirclePaintThread, (LPVOID)3, 0, NULL));
		SetEvent(ev[0]); 

		break;
	}
	case WM_COMMAND: 
		if (HIWORD(wParam) == BN_CLICKED) {
			switch (LOWORD(wParam)) {
			case ID_R1:
				SetEvent(ev[0]);
			case ID_R2:
				SetEvent(ev[1]);
			case ID_R3:
				SetEvent(ev[2]);
			case ID_R4:
				SetEvent(ev[3]);
			}
			InvalidateRect(instance->hWnd, NULL, FALSE);
		}
		break;
	case WM_PAINT:
		instance->buffur->Paint([&] (HDC memDC) {
			Rectangle(memDC, 0, 0, instance->width * 0.5, instance->height * 0.5);
			Rectangle(memDC, instance->width * 0.5, 0, instance->width, instance->height * 0.5);
			Rectangle(memDC, 0, instance->height * 0.5, instance->width * 0.5, instance->height);
			Rectangle(memDC, instance->width * 0.5, instance->height * 0.5, instance->width, instance->height);

			instance->circlesList->ForEach([&] (Circle* data) {
				HPEN hNewPen = CreatePen(PS_SOLID, 3, RGB(255, 0, 0));
				HPEN hOldPen = (HPEN)SelectObject(memDC, hNewPen); 

				HBRUSH hNewBrush = CreateSolidBrush(RGB(255, 0, 0));
				HBRUSH hOldBrush = (HBRUSH)SelectObject(memDC, hNewBrush);
			
				Ellipse(memDC, data->x - data->h, data->y - data->h, data->x + data->h, data->y + data->h);

				SelectObject(memDC, hOldPen);
				DeleteObject(hNewPen);

				SelectObject(memDC, hOldBrush);
				DeleteObject(hNewBrush);
			});
		});
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
