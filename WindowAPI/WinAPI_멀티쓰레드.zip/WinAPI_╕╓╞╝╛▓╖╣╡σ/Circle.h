#pragma once


class Circle {
public:
	int x;
	int y;
	int size;
	float h;

	int r;
	int g;
	int b;

	Circle(int x, int y, int size) {
		this->x = x;
		this->y = y;
		this->size = size;
		this->h = size * 0.5f;
	}
};