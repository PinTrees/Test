#pragma once
#include "Vector2.h"

class DragDrawST {

public:
	virtual void DragStart(Vector2 pos) = 0;
	virtual void Draging(Vector2 pos) = 0;
	virtual void DragEnd(Vector2 pos) = 0;
};



class BoxDraw : public DragDrawST {

public:
	virtual void DragStart(Vector2 pos) override {
		
	}
	virtual void Draging(Vector2 pos) override {

	}
	virtual void DragEnd(Vector2 pos) override {

	}
};


class CircleDraw : public DragDrawST {

public:
	virtual void DragStart(Vector2 pos) override {

	}
	virtual void Draging(Vector2 pos) override {

	}
	virtual void DragEnd(Vector2 pos) override {

	}
};