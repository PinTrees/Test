#pragma once
#include <windows.h>
#include <functional>
#include "list.h"
#include "Mouse.h"

class Buffur {
private:
	HWND hWnd;
	HBITMAP memBitmap;

public:
	Buffur(HWND hWnd) {
		this->hWnd = hWnd;
	}
	~Buffur() {}

	void Init();
	void Paint(std::function<void(HDC)> fptr);
};