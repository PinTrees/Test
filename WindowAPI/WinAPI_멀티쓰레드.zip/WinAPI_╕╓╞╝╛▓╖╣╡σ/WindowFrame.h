#pragma once
#include <windows.h>
#include <windowsx.h>
#include "list.h"
#include "Mouse.h"
#include "Buffur.h"
#include "DrawObject.h"
#include "Circle.h"

class WindowFrame {
private:
	static WindowFrame* instance;
	static HANDLE* ev;

	static int height;
	static int width;

	HWND hWnd;
	HINSTANCE g_hInst;

	RECT rect;
	

	List<HWND>* buttonList;
	List<Circle*>* circlesList;

	Buffur* buffur;

	WindowFrame() {}
	~WindowFrame() {}

public:
	static WindowFrame* Create(HINSTANCE hInstance);
	static WindowFrame* Instance();
	static void Dispose();

	void Init();
	void Build();
	void Run(MSG* Message);

	static LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);


	static RECT GetCurrentRect(int index) {
		RECT a = RECT();
		if (index == 0) { a.left = 0; a.right = width * 0.5f; a.top = 0; a.bottom = height * 0.5f; }
		else if (index == 1) { a.left = width * 0.5f; a.right = width; a.top = 0; a.bottom = height * 0.5f; }
		else if (index == 2) { a.left = 0; a.right = width * 0.5f; a.top = height * 0.5f; a.bottom = height; }
		else if (index == 3) { a.left = width * 0.5f; a.right = width; a.top = height * 0.5f; a.bottom = height; }
		return a;
	}

	static DWORD WINAPI CirclePaintThread(LPVOID arg)
	{
		srand(GetTickCount64());

		int index = (int)arg;
		while (1) {
			DWORD retval = WaitForSingleObject(ev[index], INFINITY); 

			RECT rt = GetCurrentRect(index);
			for (int i = 0; i < 15; i++) {
				if (index == 3) {
					int x = (rand() % rt.left) + rt.left + 10;
					int y = (rand() % rt.top) + rt.top + 10;
					int size = rand() % 50 + 25;
					Circle* circle = new Circle(x, y, size);
					instance->circlesList->Add(circle);
				}
				else if (index == 2) {
					int x = (rand() % rt.right) + 10;
					int y = (rand() % rt.top) + rt.top + 10;
					int size = rand() % 50 + 25;
					Circle* circle = new Circle(x, y, size);
					instance->circlesList->Add(circle);
				}
				else if (index == 1) {
					int x = (rand() % rt.left) + 10;
					int y = (rand() % rt.bottom) + 10;
					int size = rand() % 50 + 25;
					Circle* circle = new Circle(x, y, size);
					instance->circlesList->Add(circle);
				}
				else if (index == 0) {
					int x = (rand() % rt.right) + 10;
					int y = (rand() % rt.bottom) + 10;
					int size = rand() % 50 + 25;
					Circle* circle = new Circle(x, y, size);
					instance->circlesList->Add(circle);
				}

				InvalidateRect(instance->hWnd, NULL, FALSE);
				Sleep(100);
			}

			if (index == 3) SetEvent(ev[0]);
			else SetEvent(ev[index + 1]);
		}
		return 0;
	}
};