﻿#pragma once
#include <iostream>
#include <cstdarg>
#include <functional>

using namespace std;

/**
* 리스트 템플릿
* 
* 가변인자 생성자 초기화 추가
* 람다식을 통한 ForEach 반복 제어함수 추가
* 이터레이터를 통한 외부 반복 제어기능 추가
* 
* 단일연결 리스트로 변경 예정
*/
template<typename T> struct CNode
{
	CNode* next = nullptr;
	CNode* prev = nullptr;
	T value;

	CNode(T _value)
	{
		value = _value;
	}
	CNode(T _value, CNode* _next, CNode* _prev)
	{
		value = _value;
		next = _next;
		prev = _prev;
	}
};

template<typename T>
class List
{
public:
	CNode<T>* first;
	CNode<T>* last;
	int count;

public:
	List() : first(NULL), last(NULL), count(0) { }

	/**
	* 리스트 생성자
	* 
	* parameta: listSize, data: [ 0, 1, 2 ]
	* 가변인자로 받아온 파라미터로 리스트 생성 (역순 배열)
	* 
	* ex:
	* List<String>* list = new List<String>(3, "AA", "BB", "CC");
	*/
	List(int count, T...)
	{
		first = NULL;
		last = NULL;
		count = 0;

		// 가변인자 포인터
		va_list args;

		// 가변인자 시작 포인터 위치 설정;
		// va_start: (pointer, last arg)
		va_start(args, count); 

		for (int i = 0; i != count; ++i) {
			// 지금 현재 가리키고 있는 포인터를 읽어옴과 동시에 T사이즈 만큼 포인터 이동 
			// va_arg: (in out pointer, memory size)
			Add(va_arg(args, T));	
		}

		// va_list close;
		va_end(args);
		count = count;
	}
	~List()
	{
		clear();
	}



public:

	/**
	* 리스트 아이템 추가
	* 
	* 리스트 노드의 마지막으로 추가됨
	*/
	int Add(T item)
	{
		CNode<T>* newNode = new CNode<T>(item);
		if (count == 0)
		{
			first = newNode;
			last = newNode;
			newNode->next = NULL;
			newNode->prev = NULL;
		}
		else
		{
			newNode->next = NULL;
			newNode->prev = last;
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}


	/**
	* 리스트 아이템 제거
	* 
	* parameta: deleteItem;
	* 삭제받은 값과 같은 아이템을 리스트 목록에서 제거
	* 
	* return: 남은 리스트 목록 개수 반환
	*/
	int Remove(T item)
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}


	/**
	* 리스트 순회
	* 
	* 람다식을 통한 리스트 반복
	* std::function: 람다식 내부 캡쳐목록을 사용하기 위해 함수포인터가 아닌 function 객체로 구현
	* 
	* 반환타입 없음
	*/
	void ForEach(std::function<void(T)> fptr) {
		CNode<T>* pThis = first;
		while (pThis)
		{
			(fptr)(pThis->value);
			pThis = pThis->next;
		}
	}

	/**
	* 리스트 이터레이터
	* 
	* 리스트 외부 반복자
	*/
	class Iterator
	{
	private:
		CNode<T>* node;
	public:
		Iterator(CNode<T>* node) : node(node) {}

		bool operator!=(const Iterator& other) const {
			return node != other.node;
		}

		T& operator*() {
			return node->value;
		}

		Iterator& operator++() {
			node = node->next;
			return *this;
		}
	};

	Iterator begin() const {
		return Iterator(first);
	}

	Iterator end() const {
		return Iterator(NULL);
	}


	/**
	* 목록중 랜덤한 요소 반환
	*/
	T GetRandom() {
		return elementAt(rand() % count - 1);
	}


	/**
	* 목록의 특정 인덱스값에 접근
	*/
	T elementAt(int index) {
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	/**
	* 목록의 특정 인덱스 값에 접근
	* 인덱스 오류 처리 구현 안됨
	*/
	T operator[] (int index) {
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	/**
	* 리스트 목록 제거
	* 
	* 저장된 모든 목록을 제거
	*/
	void clear()
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			CNode<T>* pDelete = pThis;

			if (pThis->prev)
				pThis->prev->next = pThis->next;
			if (pThis->next)
				pThis->next->prev = pThis->prev;

			pThis = pThis->next;

			delete pDelete;
			--count;
		}
		first = NULL;
		last = NULL;
	}


	/**
	* 현재 목록 개수를 반환
	*/
	int Count() {
		return count;
	}
};
//template<typename T>




/**
* 맵 내부 Key 및 Value 값의 목록을 분리저장하기위한 리스트
* 맵 내부 Key, Value 목록에 대한 개별 삽입 삭제가 불가능하도록 설계된 리스트 구조
* 
* List구조에서 Vector구조로 변경 예정
*/
template<typename T> class Iterable
{
public:
	CNode<T>* first; // 첫번째 노드
	CNode<T>* last;  // 마지막 노드
	int count;

public:
	// 기초 생성자 호출과 함꼐 초기화
	Iterable() : first(nullptr), last(nullptr), count(0) {}
	~Iterable()	{
		clear();
	}

	/**
	* 목록 제거
	* 저장된 모든 목록을 제거합니다.
	*/
	void clear()
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			CNode<T>* pDelete = pThis;

			if (pThis->prev)
			{
				pThis->prev->next = pThis->next;
			}
			if (pThis->next)
			{
				pThis->next->prev = pThis->prev;
			}

			pThis = pThis->next;

			delete pDelete;
			--count;
		}
		first = nullptr;
		last = nullptr;
	}


	/**
	* 변경필요
	*/
	int add(T item)
	{
		if (count == 0)
		{
			CNode<T>* newNode = new CNode<T>(item, nullptr, nullptr);
			first = newNode;
			last = newNode;
		}
		else
		{
			CNode<T>* newNode = new CNode<T>(item, nullptr, last);
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}


	/**
	* 반복자 추가
	*/
	void ForEach(std::function<void(T)> fptr) {
		CNode<T>* pThis = first;
		while (pThis)
		{
			(fptr)(pThis->value);
			pThis = pThis->next;
		}
	}
	
	/**
	* 외부 반복자 추가
	*/
	class Iterator
	{
	private:
		CNode<T>* node;
	public:
		Iterator(CNode<T>* node) : node(node) {}

		bool operator!=(const Iterator& other) const {
			return node != other.node;
		}

		T& operator*() {
			return node->value;
		}

		Iterator& operator++() {
			node = node->next;
			return *this;
		}
	};
	Iterator begin() const {
		return Iterator(first);
	}
	Iterator end() const {
		return Iterator(NULL);
	}


	/**
	* 삭제 예정
	* 특정 요소값 접근
	*/
	T elementAt(int index) {
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	/**
	* 삭제 예정
	* 특정 요소값 접근
	*/
	T operator[] (int index) {
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	/**
	* 요소 제거
	*/
	int Remove(T item)
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}
};