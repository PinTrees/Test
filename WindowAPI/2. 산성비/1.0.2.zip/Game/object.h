#pragma once
#include "System.h"
#include "tstring.h"

class IDraw {
public:
	virtual void DrawCall(HDC) = 0;
};

class SObject : public IDraw {
public:
	float x;
	float y;
	float speed;
	bool isDisbale = false;
	TString* string;

	SObject() {
		x = 0; y = 0; 
		speed = 0; 
		string = nullptr;
		isDisbale = false;
	}
	SObject(int maxX, int maxY, TCHAR* data) {
		isDisbale = false;
		SetRandomPositinAndSize(maxX, maxY);
		string = new TString(data);
		speed = (rand() % 3 + 1) * 0.15f;
	}

	void SetRandomPositinAndSize(int maxX, int maxY) {
		x = rand() % maxX;
		y = rand() % maxY;
	}

	void DrawCall(HDC hdc) override {
		if (isDisbale) return; 
		TextOut(hdc, x, y, string->characters, lstrlen(string->characters));
	}

	bool SetActive(bool active) {
		if (!active) { 
			isDisbale = true;
		}
		return isDisbale;
	}

	void Move() {
		y += (speed + System::Instance().GetSpeed()) < 0 ? 0 : (speed + System::Instance().GetSpeed());
	}
};