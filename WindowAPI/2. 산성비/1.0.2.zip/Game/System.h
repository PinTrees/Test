#pragma once
#include <windows.h>
#include "Singleton.h"

class System {
private:
    System(const System& ref) {}
    System& operator=(const System& ref) {}
    System() {}
    ~System() {}

    RECT contextRect;
    int width   = 0;
    int height  = 0;

    float objectSpeed = 0.0f;

public:
    static System& Instance() {
        static System s;
        return s;
    }

    /**
    * â ũ�⸦ �����մϴ�.
    */
    void SetContextRect(RECT rect) {
        contextRect = rect;
        width = rect.right - rect.left;
        height = rect.bottom - rect.top;
    }

    /**
    * ���ڿ� ���ǵ�
    */
    float GetSpeed() { return objectSpeed; }
    void  ClearSpeed() { objectSpeed = 0; }
    void  IncrementSpeed() { objectSpeed += 0.35f; }
    void  DecrementSpeed() { objectSpeed -= 0.35f; if (objectSpeed < 0) objectSpeed = 0; }

    /**
    * ����� â�� �ʺ� ��ȯ�մϴ�.
    */
    int GetContextWidth() {
        return width;
    }

    /**
    * ����� â�� ���̸� ��ȯ�մϴ�.
    */
    int GetContextHeight() {
        return height;
    }
};