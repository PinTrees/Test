#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("SendUserMes");

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		500, 100, 256, 300,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

HWND button1, button2;
DWORD msg;
int speed = 0;

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	HWND hWndSori;

	TCHAR speedStr[128];
	

	switch (iMessage) {
	case WM_CREATE:
		msg = RegisterWindowMessage(TEXT("SPEEDSETTING"));

		CreateWindow("button", "�ӵ� ����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			12, 50, 100, 25, hWnd, (HMENU)0x1001, g_hInst, NULL);
		CreateWindow("button", "�ӵ� ����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			12, 80, 100, 25, hWnd, (HMENU)0x1002, g_hInst, NULL);
		CreateWindow("button", "�ʱ�ȭ", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			12, 110, 100, 25, hWnd, (HMENU)0x1003, g_hInst, NULL);

		break;
	case WM_COMMAND:
		hWndSori = FindWindow(NULL, TEXT("FindIdle"));
		if (hWndSori == NULL) {
			MessageBox(hWnd, TEXT("UserMes ���α׷��� ����Ǿ� ���� �ʽ��ϴ�"), TEXT("�̷�����"), MB_OK);
			break;
		}
		switch (LOWORD(wParam))
		{
		case 0x1001:
			if (speed > 1) speed--;
			SendMessage(hWndSori, msg, 1, 0);
			break;
		case 0x1002:
			speed++;
			SendMessage(hWndSori, msg, 0, 0);
			break;
		case 0x1003:
			speed = 0;
			SendMessage(hWndSori, msg, 2, 0);
			break;
		}

		InvalidateRect(hWndMain, NULL, FALSE);
		return 0;
	case WM_PAINT:
		hdc=BeginPaint(hWnd, &ps);

		wsprintf(speedStr, TEXT("����ӵ� %d"), speed);

		TextOut(hdc, 12, 12, "�꼺�� �ý��� ���", lstrlen("�꼺�� �ý��� ���"));
		TextOut(hdc, 12, 150, speedStr, lstrlen(speedStr));
		EndPaint(hWnd, &ps);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

