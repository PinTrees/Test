#pragma once
#include <windows.h>

static float speedSetting = 0;

