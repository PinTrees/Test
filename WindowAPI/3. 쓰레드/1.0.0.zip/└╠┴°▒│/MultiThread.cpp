#include <windows.h>
#include<ctime>
#include <chrono>
#include <iostream>
#include <ctime>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("MultiThread");

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

int size = 100;

DWORD WINAPI ThreadFuncE(LPVOID prc)
{
	HDC hdc;
	HBRUSH hBrush, hOldBrush;
	//RECT rc=*(LPRECT)prc;
	hdc = GetDC(hWndMain);

	srand(time(NULL));

	int r = rand() % 256 + 0;
	int g = rand() % 256 + 0;
	int b = rand() % 256 + 0;

	for (int i = 0; i < 10; i++) {
		int x = rand() % 1280;
		int y = rand() % 600;

		Sleep(100);
		hBrush = CreateSolidBrush(RGB(r, g, b));
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		Ellipse(hdc, x, y, x + size, y + size);
		SelectObject(hdc, hOldBrush); 
		DeleteObject(hBrush);
	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

DWORD WINAPI ThreadFunc(LPVOID prc)
{
	HDC hdc;
	HBRUSH hBrush, hOldBrush;
	//RECT rc=*(LPRECT)prc;
	hdc=GetDC(hWndMain);

	//time_t now = time(nullptr);
	//time_t mnow = now * 1000;
	srand(time(NULL));

	int r = rand() % 256 + 0;
	int g = rand() % 256 + 0;
	int b = rand() % 256 + 0;

	for (int i = 0; i < 10; i++) {
		int x = rand() % 1280;
		int y = rand() % 600;


		Sleep(100);	
		hBrush = CreateSolidBrush(RGB(r,g,b));
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		Rectangle(hdc, x, y, x + size, y + size);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);
	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	DWORD ThreadID;

	switch (iMessage) {
	case WM_CREATE:
		srand((unsigned int)time(NULL));
		hWndMain=hWnd;
		 
		CreateWindow("button", "��", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
			10, 10, 90, 25, hWnd, (HMENU)0, g_hInst, NULL); 
		CreateWindow("button", "����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
			120, 10, 90, 25, hWnd, (HMENU)1, g_hInst, NULL); 
		return TRUE;
	case WM_COMMAND:
		if (wParam == 0)
			CloseHandle(CreateThread(NULL, 0, ThreadFuncE, NULL, 0, &ThreadID));
		else if(wParam == 1)
			CloseHandle(CreateThread(NULL, 0, ThreadFunc, NULL, 0, &ThreadID));
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
