#pragma once

class Mouse {
public:
	static bool isDown;

	float x = 0;
	float y = 0;

	Mouse(float _x, float _y) {
		x = _x;
		y = _y;
	}
};

class MouseInput {

};