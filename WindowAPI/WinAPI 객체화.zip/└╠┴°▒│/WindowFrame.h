#pragma once
#include <windows.h>
#include <windowsx.h>
#include "list.h"
#include "Mouse.h"

class WindowFrame {
private:
	static WindowFrame* instance;
	HWND hWnd;
	HINSTANCE g_hInst;

	List<List<Mouse*>*>* mousePosList; 

	WindowFrame() {}
	~WindowFrame() {}

public:
	static WindowFrame* Create(HINSTANCE hInstance);
	static WindowFrame* Instance();
	static void Dispose();

	void Init();
	void Build();
	void Run(MSG* Message);

	void Paint();
	
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
};