#include "Mouse.h"

bool Mouse::isDown = false;