#include "MainFrame.h"


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	MainFrame::Create(hInstance)->Init();
	int resurlt = MainFrame::Instance()->Run();
	MainFrame::Dispose();
	return (int)resurlt;
}
