#include "MainFrame.h"

MainFrame* MainFrame::instance = nullptr;

MainFrame* MainFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new MainFrame();
	WindowFrame::Create(hInstance);
	return instance;
}
MainFrame* MainFrame::Instance() {
	return instance;
}

void MainFrame::Dispose() {
	WindowFrame::Dispose();
	if (instance != nullptr) { delete instance; instance = nullptr; }
}


void MainFrame::Init() {
	WindowFrame::Instance()->Build();
}

int MainFrame::Run() {
	MSG Message; 
	while (GetMessage(&Message, NULL, 0, 0)) {
		WindowFrame::Instance()->Run(&Message);
	}
	return (int)Message.wParam;
}