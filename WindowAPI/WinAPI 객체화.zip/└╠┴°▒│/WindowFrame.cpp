#include "WindowFrame.h"


WindowFrame* WindowFrame::instance = nullptr;

WindowFrame* WindowFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new WindowFrame();
	
	instance->g_hInst = hInstance;
	instance->mousePosList = new List<List<Mouse*>*>(); 

	return instance;
}
WindowFrame* WindowFrame::Instance() {
	return instance;
}
void WindowFrame::Dispose() {
	if (instance != nullptr) { delete instance; instance = nullptr; }
}



void WindowFrame::Init() {
}
void WindowFrame::Build() { 
	LPCTSTR lpszClass = TEXT("First"); 
	WNDCLASS WndClass; 

	WndClass.cbClsExtra = 0; 
	WndClass.cbWndExtra = 0; 
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = g_hInst;
	WndClass.lpfnWndProc = WndProc; 
	WndClass.lpszClassName = lpszClass; 
	WndClass.lpszMenuName = NULL; 
	WndClass.style = CS_HREDRAW | CS_VREDRAW; 
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		NULL, (HMENU)NULL, g_hInst, NULL);
	ShowWindow(hWnd, SW_SHOW);
}

void WindowFrame::Run(MSG* Message) {
	TranslateMessage(Message);
	DispatchMessage(Message);
}

/**
* �� �Լ��� ȭ�鿡 ���콺 ��ǥ�� �������� ����մϴ�.
*/
void WindowFrame::Paint() {
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC memdc = CreateCompatibleDC(hdc);
	RECT rect;
	GetClientRect(hWnd, &rect);

	HBITMAP memBitmap = CreateCompatibleBitmap(memdc, rect.right, rect.bottom);
	HBITMAP oldBitmap = (HBITMAP)SelectObject(memdc, memBitmap);
	FillRect(memdc, &rect, (HBRUSH)GetStockObject(WHITE_BRUSH));

	/// ���콺 ��ǥ����� ��� �ݺ�
	instance->mousePosList->ForEach([&](List<Mouse*>* m) {
		/// �ؽ�Ʈ �� ������ ���� ���ݺ���
		/// ����Ʈ ���̽����� ->at���·� ����
		m->ForEachNode([&](ListNode<Mouse*>* node) {
			if (node->next == nullptr) return;

			Mouse* pos = node->value;
			Mouse* nextPos = node->next->value;
			MoveToEx(memdc, pos->x, pos->y, NULL);
			LineTo(memdc, nextPos->x, nextPos->y);
			});
		});

	BitBlt(hdc, 0, 0, rect.right, rect.bottom, memdc, 0, 0, SRCCOPY);
	SelectObject(memdc, oldBitmap);
	DeleteObject(memBitmap);
	DeleteDC(memdc);
	EndPaint(hWnd, &ps);
}


LRESULT CALLBACK WindowFrame::WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc = NULL;
	switch (iMessage) {
	case WM_LBUTTONDOWN:
	{
		/// ���콺 ����Ŭ�� ��ġ �Ҵ�
		Mouse::isDown = true;
		instance->mousePosList->Add(new List<Mouse*>(1,
			new Mouse(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam))));
		break;
	}
	case WM_LBUTTONUP:
		Mouse::isDown = false;
	case WM_MOUSEMOVE:
	{
		if (Mouse::isDown == true)
			instance->mousePosList->last->value
			->Add(new Mouse(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)));
		InvalidateRect(hWnd, NULL, FALSE);
		break;
	}
	case WM_PAINT:
		instance->Paint();
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
