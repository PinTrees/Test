#include "Global.h"
void Initialize()
{
	GetClientRect(hMainWnd, &crt);
	hBackGround = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
	GetObject(hBackGround, sizeof(BITMAP), &backgrd);
	hpoint = backgrd.bmHeight - crt.bottom;

	hObject = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP2));

	HDC hdc, hMemDC;
	HBITMAP hOldbit;
	hdc = GetDC(hMainWnd);
	hBackBit = CreateCompatibleBitmap(hdc, 1000, 2000);
	ReleaseDC(hMainWnd, hdc);

	SetTimer(hMainWnd, 1, 20, NULL);
	oX = 70;
	oY = 400;
}

void OnTimer()
{
	RECT crt;
	GetClientRect(hMainWnd, &crt);

	BITMAP bit;
	GetObject(hObject, sizeof(BITMAP), &bit);

	if (GetKeyState(VK_LEFT) & 0x5000)
	{
		oX = max(0, oX - 5);
	}
	if (GetKeyState(VK_RIGHT) & 0x5000)
	{
		oX = min(crt.right - bit.bmWidth, oX + 5);
	}
	if (GetKeyState(VK_UP) & 0x5000)
	{
		oY = max(0, oY - 5);
	}
	if (GetKeyState(VK_DOWN) & 0x5000)
	{
		oY = min(crt.bottom - bit.bmHeight, oY + 5);
	}

	MemoryPainting();
}

void MemoryPainting()
{
	HDC hdc, hMemDC, hMemDC_back;
	HBITMAP hOldbit1, hOldbit2;


	hdc = GetDC(hMainWnd);
	hMemDC = CreateCompatibleDC(hdc);
	hOldbit1 = (HBITMAP)SelectObject(hMemDC, hBackBit);

	hMemDC_back = CreateCompatibleDC(hdc);
	hOldbit2 = (HBITMAP)SelectObject(hMemDC_back, hBackGround);

	hpoint--;
	if (hpoint < 0)
	{
		hpoint = backgrd.bmHeight;
	}
	int height = min(crt.bottom, backgrd.bmHeight - hpoint);

	BitBlt(hMemDC, 0, 0, backgrd.bmWidth, height, hMemDC_back, 0, hpoint, SRCCOPY);

	if (height < crt.bottom)
	{
		int height_tmp = crt.bottom - height;
		BitBlt(hMemDC, 0, height, backgrd.bmWidth, height_tmp, hMemDC_back, 0, 0, SRCCOPY);
	}

	DrawBitmap(hMemDC, oX, oY, hObject);

	SelectObject(hMemDC, hOldbit1);
	SelectObject(hMemDC_back, hOldbit2);

	DeleteDC(hMemDC);
	DeleteDC(hMemDC_back);
	ReleaseDC(hMainWnd, hdc);

	InvalidateRect(hMainWnd, NULL, false);

}

void DrawBitmap(HDC hdc, int x, int y, HBITMAP hBit)
{
	HDC MemDC;
	HBITMAP OldBitmap;
	int bx, by;
	BITMAP bit;

	MemDC = CreateCompatibleDC(hdc);
	OldBitmap = (HBITMAP)SelectObject(MemDC, hBit);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	BitBlt(hdc, x, y, bx, by, MemDC, 0, 0, SRCCOPY);

	SelectObject(MemDC, OldBitmap);
	DeleteDC(MemDC);
}

