#pragma once
#include <windows.h>
#include "resource.h"

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void DrawBitmap(HDC hdc, int x, int y, HBITMAP hBit);
void Initialize();
void MemoryPainting();
void PlaneMoving(WPARAM wparam);
void OnTimer();



#ifdef MAIN
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("First");

HBITMAP hBackGround, hObject, hBackBit;
HWND hMainWnd;
int oX, oY, hpoint;
RECT crt;
BITMAP backgrd;
#else
extern HINSTANCE g_hInst;
extern LPCTSTR lpszClass;

extern HBITMAP hBackGround, hObject, hBackBit;
extern HWND hMainWnd;
extern int oX, oY, hpoint;
extern RECT crt;
extern BITMAP backgrd;
#endif