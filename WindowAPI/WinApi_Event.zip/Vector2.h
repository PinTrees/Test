#pragma once

class Vector2 {
public:
	Vector2(LPARAM lParam) {
		x = GET_X_LPARAM(lParam);
		y = GET_Y_LPARAM(lParam);
	}
	Vector2(float x, float y) {
		this->x = x;
		this->y = y;
	}
	Vector2() {}
	~Vector2() {}

	float x;
	float y;
};