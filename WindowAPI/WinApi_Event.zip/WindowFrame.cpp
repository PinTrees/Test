#include "WindowFrame.h"


WindowFrame* WindowFrame::instance = nullptr;
HANDLE* WindowFrame::ev = new HANDLE[4];
HANDLE* WindowFrame::hThread = new HANDLE[4];
int WindowFrame::height = 0;
int WindowFrame::width = 0;
int WindowFrame::widthHalf = 0;
int WindowFrame::heightHalf = 0;
int WindowFrame::count = 0;
RECT* WindowFrame::rectSize = new RECT[4];

WindowFrame* WindowFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new WindowFrame();
	
	instance->g_hInst = hInstance;
	instance->buttonList = new List<HWND>();
	instance->circlesList = new List<Circle*>();
	return instance;
}
WindowFrame* WindowFrame::Instance() {
	return instance;
}
void WindowFrame::Dispose() {
	if (instance != nullptr) { delete instance; instance = nullptr; }
}


void WindowFrame::Init() {
}

void WindowFrame::Build() { 
	LPCTSTR lpszClass = TEXT("First"); 
	WNDCLASS WndClass; 

	WndClass.cbClsExtra = 0; 
	WndClass.cbWndExtra = 0; 
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = g_hInst;
	WndClass.lpfnWndProc = WndProc; 
	WndClass.lpszClassName = lpszClass; 
	WndClass.lpszMenuName = lpszClass;
	//WndClass.lpszMenuName = NULL; 
	WndClass.style = CS_HREDRAW | CS_VREDRAW; 
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		NULL, (HMENU)NULL, g_hInst, NULL);
	ShowWindow(hWnd, SW_SHOW);

	buffur = new Buffur(hWnd);
}

void WindowFrame::Run(MSG* Message) {
	TranslateMessage(Message);
	DispatchMessage(Message);
}


#define ID_R1 100
#define ID_R2 101
#define ID_R3 102
#define ID_R4 103

HMENU hMenu, hSubMenu;
LRESULT CALLBACK WindowFrame::WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_CREATE:
	{
		ev[0] = CreateEvent(NULL, FALSE, FALSE, NULL); Sleep(1);
		ev[1] = CreateEvent(NULL, FALSE, FALSE, NULL); Sleep(1);
		ev[2] = CreateEvent(NULL, FALSE, FALSE, NULL); Sleep(1);
		ev[3] = CreateEvent(NULL, FALSE, FALSE, NULL); Sleep(1);

		Mouse::isDown = false;
		GetClientRect(hWnd, &instance->rect); 
		height = instance->rect.bottom; 
		width = instance->rect.right;
		heightHalf = height * 0.5f;
		widthHalf = width * 0.5f;

		rectSize[0] = RECT();
		rectSize[1] = RECT();
		rectSize[2] = RECT();
		rectSize[3] = RECT();
		rectSize[0].left = 0; rectSize[0].top = 0;	rectSize[0].right = widthHalf; rectSize[0].bottom = heightHalf;
		rectSize[1].left = widthHalf; rectSize[1].top = 0;	rectSize[1].right = width; rectSize[1].bottom = heightHalf;
		rectSize[2].left = 0; rectSize[2].top = heightHalf;	rectSize[2].right = widthHalf; rectSize[2].bottom = height;
		rectSize[3].left = widthHalf; rectSize[3].top = heightHalf;	rectSize[3].right = width; rectSize[3].bottom = height;

		instance->buttonList->Add(CreateWindow("button", "��ư 1", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			widthHalf - 120, heightHalf - 40, 100, 25, hWnd, (HMENU)ID_R1, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 2", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			widthHalf * 2 - 120, heightHalf - 40, 100, 25, hWnd, (HMENU)ID_R2, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 3", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			widthHalf - 120, heightHalf * 2 - 40, 100, 25, hWnd, (HMENU)ID_R3, instance->g_hInst, NULL));
		instance->buttonList->Add(CreateWindow("button", "��ư 4", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		 (widthHalf * 2 - 120), (heightHalf * 2 - 40), 100, 25, hWnd, (HMENU)ID_R4, instance->g_hInst, NULL));

		for(int i = 0; i < 4; i++) hThread[i] = CreateThread(NULL, 0, CirclePaintThread, (LPVOID)i, 0, NULL); Sleep(10);

		break;
	}
	case WM_COMMAND: 
		if (HIWORD(wParam) == BN_CLICKED) {
			SetEvent(ev[wParam - 100]);
			InvalidateRect(instance->hWnd, NULL, FALSE);
		}
		break;
	case WM_PAINT:
		instance->buffur->Paint([&] (HDC memDC) {
			for(int i = 0; i < 4; i++)
				Rectangle(memDC, rectSize[i].left, rectSize[i].top, rectSize[i].right, rectSize[i].bottom);

			instance->circlesList->ForEach([&] (Circle* data) {
				HPEN hNewPen = CreatePen(PS_SOLID, 3, RGB(255, 0, 0));
				HPEN hOldPen = (HPEN)SelectObject(memDC, hNewPen); 

				HBRUSH hNewBrush = CreateSolidBrush(RGB(255, 0, 0));
				HBRUSH hOldBrush = (HBRUSH)SelectObject(memDC, hNewBrush);
			
				Ellipse(memDC, data->x - data->h, data->y - data->h, data->x + data->h, data->y + data->h);

				SelectObject(memDC, hOldPen);
				DeleteObject(hNewPen);

				SelectObject(memDC, hOldBrush);
				DeleteObject(hNewBrush);
			});
		});
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
