#pragma once
#include <windows.h>
#include <windowsx.h>
#include "list.h"
#include "Mouse.h"
#include "Buffur.h"
#include "DrawObject.h"
#include "Circle.h"

class WindowFrame {
private:
	static WindowFrame* instance;
	static HANDLE* ev;
	static HANDLE* hThread;
	static int heightHalf;
	static int widthHalf;
	static int height;
	static int width;
	static int count;

	static RECT* rectSize;


	HWND hWnd;
	HINSTANCE g_hInst;

	RECT rect;

	

	List<HWND>* buttonList;
	List<Circle*>* circlesList;

	Buffur* buffur;

	WindowFrame() {}
	~WindowFrame() {}

public:
	static WindowFrame* Create(HINSTANCE hInstance);
	static WindowFrame* Instance();
	static void Dispose();

	void Init();
	void Build();
	void Run(MSG* Message);

	static LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);


	static RECT GetCurrentRect(int index) {
		return rectSize[index];
	}



	static DWORD WINAPI CirclePaintThread(LPVOID arg)
	{
		srand(GetTickCount64());

		int index = (int)arg;
		DWORD retval;
		while (1) {
			retval = WaitForSingleObject(ev[index], INFINITY);
			if (retval != WAIT_OBJECT_0) continue;

			count++;
			RECT rt = GetCurrentRect(index);
			for (int i = 0; i < 15; i++) {
				int x = (rand() % widthHalf) + rt.left + 10;
				int y = (rand() % heightHalf) + rt.top + 10;
				int size = rand() % 50 + 25;
				Circle* circle = new Circle(x, y, size);
				instance->circlesList->Add(circle);

				InvalidateRect(instance->hWnd, NULL, FALSE);
				Sleep(100);
			}

			if (count >= 4) {
				count = 0;
				continue;
			}

			if (index == 3) SetEvent(ev[0]);
			else SetEvent(ev[index + 1]);
		}
		return 0;
	}
};