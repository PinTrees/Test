#ifndef  _CMAIN_MANAGER_H
#define  _CMAIN_MANAGER_H
#include "Global.h"
#include "FoodManager.h"
#include "WearManager.h"
#include "ApplianceManager.h"

class CMainManager
{	
private:
	static CMainManager* mPthis;
	CMainManager(){}
	CMainManager(const CMainManager&){}
	~CMainManager(){}
public:

	void Initialize();
	void Run();	
	CManager* GetSelectManager();

	static void Create();
	static CMainManager* GetInstance();
	static void Destroy();
};
#endif
