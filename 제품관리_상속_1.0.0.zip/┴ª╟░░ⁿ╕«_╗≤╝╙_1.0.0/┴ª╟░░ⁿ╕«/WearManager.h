#ifndef _CWEARPRODUCTMANAGER_H
#define _CWEARPRODUCTMANAGER_H
#include "Global.h"

#include "Wear.h"
#include "Manager.h"


class CWearManager:public CManager
{
	DECLARE_SINGLETONE(CWearManager)

private:
	CWear*  mWearList[PRODUCT_MAX_COUNT];

public:	
	
	void Initialize();

	virtual void CreateProduct();
	virtual void SearchProduct();
	virtual void DeleteProduct();
	
};
#endif