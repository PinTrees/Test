#ifndef _CFoodManager_HCFoodManager
#define _CFoodManager_H
#include "Global.h"

#include "Appliance.h"
#include "Manager.h"

class CApplianceManager:public CManager
{
	DECLARE_SINGLETONE(CApplianceManager)
private:
	CAppliance*  mApplianceList[PRODUCT_MAX_COUNT];	

public:

	void Initialize();

	virtual void CreateProduct();
	virtual void SearchProduct();
	virtual void DeleteProduct();
};
#endif