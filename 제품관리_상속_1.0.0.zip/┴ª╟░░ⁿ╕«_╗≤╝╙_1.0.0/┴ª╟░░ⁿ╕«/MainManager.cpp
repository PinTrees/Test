#include "MainManager.h"
CMainManager* CMainManager::mPthis = nullptr;
void CMainManager::Create()
{
	if (mPthis != nullptr)
	{
		mPthis = new CMainManager();
	}

	CFoodManager::Create();
	CWearManager::Create();
	CApplianceManager::Create();
}

CMainManager* CMainManager::GetInstance()
{
	return mPthis;
}

void CMainManager::Destroy()
{
	CFoodManager::Destroy();
	CWearManager::Destroy();
	CApplianceManager::Destroy();

	if (mPthis != nullptr)
	{
		delete mPthis;
	}
}

void CMainManager::Initialize()
{
	CFoodManager::GetInstance()->Initialize();
	CWearManager::GetInstance()->Initialize();
	CApplianceManager::GetInstance()->Initialize();
}

CManager* CMainManager::GetSelectManager()
{
	CManager* mng = nullptr;

	int count = CProduct_ID_Info::GetProductArrayCount(COUNT_CLASS::PRODUCT_COUNT);

	for (int i = 0; i < count; i++)
	{
		printf("%d. %s :\n", i, CProduct_ID_Info::Product_Class[i]);
	}

	printf("����:");
	PRODUCT_CLASS productclass;
	scanf("%d", &productclass);

	switch (productclass)
	{
	case PRODUCT_CLASS::FOOD:
		mng = CFoodManager::GetInstance();
		break;
	case PRODUCT_CLASS::WEAR:
		mng = CWearManager::GetInstance();
		break;
	case PRODUCT_CLASS::APPLIANCE:
		mng = CApplianceManager::GetInstance();
		break;
	default:
		printf("�߸������߽��ϴ�.\n");		
	}
	
	return mng;
}

void CMainManager::Run()
{
	bool endflag=false;	

	while(1)
	{
		printf("<<      ��    ��        >>\n");
		printf("1. ��ǰ �߰�\n");
		printf("2. ��ǰ �˻�\n");
		printf("3. ��ǰ ����\n");	
		printf("4. ����\n");

		printf("����:");
		int sel;
		CManager* mng = nullptr;
		scanf("%d", &sel);

		if (sel< PROGRAM_EXIT)
		{
			mng = GetSelectManager();
			if (mng == nullptr)
			{
				continue;
			}
		}		
		
		switch(sel)
		{
		case PRODUCT_CREATE:
			mng->CreateProduct();
			break;
		case PRODUCT_SEARCH:
			mng->SearchProduct();			
			break;
		case PRODUCT_DELETE:
			mng->DeleteProduct();			
			break;
		case PROGRAM_EXIT:
			endflag = true;
			break;	
		default:
			printf("�߸������߽��ϴ�.\n");
			continue;
		}

		if(endflag)
		{
			break;
		}
	}
}
