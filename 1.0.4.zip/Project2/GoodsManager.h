#pragma once
#include "list.h"
#include "product.h"
#include "SubManager.h"


class GoodsManager : public SubManager {
private:
    GoodsManager(const GoodsManager& ref) {}
    GoodsManager& operator=(const GoodsManager& ref) {}
    GoodsManager() {}
    ~GoodsManager() {}

    List<Goods*>* products;

public:
    static GoodsManager& Instance() {
        static GoodsManager s;
        return s;
    }

    void Init() {
        products = new List<Goods*>();
    }

    void Input() override {
        system("cls");
        cout << "�߰��� ��ǰ �ۼ�" << endl << endl;

        cout << "�̸�: ";
        String name; 
        cin >> name;

        cout << "����: ";
        String weight;
        cin >> weight;

        cout << "����: ";
        String price;
        cin >> price;

        Goods* product = new Goods(name, ToInt(price), ToInt(weight));
        products->Add(product);
    }

    void Print() override {
        system("cls");
        cout << "��ǰ ���" << endl << endl;

        products->ForEach([&](Goods* p) {
            p->Print();
        });
    }

    List<Product*>* Search(String searchText) override {
        List<Product*>* searchList = new List<Product*>();

        products->ForEach([&](Goods* p) {
            if (p->GetName().Contain(&searchText)) {
                searchList->Add((Product*)p);
            }
        });

        return searchList;
    }
};