#pragma once
#include <fstream> // ifstream header
#include <iostream>
#include "product.h"
#include "list.h"
#include "stringMap.h"
#include <sstream>

using namespace std;

class FileManager
{
public:
	bool SaveStudentsAsFile(SMap<Product*>* studens);
	SMap<Product*>* GetStudentsFromFile();
	SMap<List<Product*>*>* GetStudentsSubManagerFromFile();
	SMap<Subject*>* GetSubjectListFromFile();
};

