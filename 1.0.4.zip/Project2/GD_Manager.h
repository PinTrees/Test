#pragma once
#include "list.h"
#include "product.h"
#include "SubManager.h"


class GameDesignManager : public SubManager {
public:
	GameDesignManager();
	GameDesignManager(const char* d, String de, List<Subject*>* sub, List<Product*>* _student);
	~GameDesignManager();
};