#include "SubManager.h"

#pragma once
#include "list.h"
#include "product.h"



void SubManager::Print()
{
	//cout << departName << " �а� �л� ���� ���" << endl << endl;
}



void SubManager::PrintProduct(Product* product)
{
}
