#include "manager.h"


// UI�� ��� - ����Ʈ �Լ�

MainManager::MainManager() {
}
MainManager::~MainManager() {
	delete menu;
}

// ����ó�����α׷� �Ŵ��� Ŭ���� �ʱ�ȭ
void MainManager::Init()
{
	GoodsManager::Instance().Init();

	menu = new Menu();
	menu->Init();

	fileManager = new FileManager();
}

// ����
void MainManager::Run() {
	while (true)
	{
		int selectInt = ToInt(menu->MainMenu());

		if (selectInt == (int)MAINMENU::Inupt) {
			InputProduct();
		}
		else if (selectInt == (int)MAINMENU::Print) {
			PrintProduct();
		}
		else if (selectInt == (int)MAINMENU::Search) {
			SearchProduct();
		}
		else if (selectInt == (int)MAINMENU::Save) {
			SearchProduct();
		}
		else if (selectInt == (int)MAINMENU::Exit){
			break;
		}
	}
	return;
}


void MainManager::SaveStudent() {
	system("cls");

	bool isSave = fileManager->SaveStudentsAsFile(studentList);

	if (isSave) cout << "���强��" << endl << endl;
	else cout << "�������" << endl << endl;

	system("PAUSE");
}


void MainManager::PrintProduct() { 
	GetProductManager(menu->PrintMenu())->Print();
	system("PAUSE");
}


void MainManager::InputProduct() {
	GetProductManager(menu->InputMenu())->Input();
}


void MainManager::SearchProduct()
{
	system("cls");
	cout << "��ǰ �˻�" << endl << endl;

	cout << "�˻���: ";
	String input;
	cin >> input; 

	List<Product*>* p = GoodsManager::Instance().Search(input);

	p->ForEach([&](Product* p) {
		p->Print();
	});

	system("PAUSE");
}


SubManager* MainManager::GetProductManager(String code)
{
	int c = ToInt(code);
	if (c == 1) return (SubManager*)&GoodsManager::Instance(); 
	return nullptr;
}