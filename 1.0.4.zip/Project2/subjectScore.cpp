#include "subjectScore.h"


SubjectScore::SubjectScore() { }
SubjectScore::SubjectScore(char* code, int _score) 
{
	id = code;
	score = _score;
}
int SubjectScore::getScore() {
	return score;
}