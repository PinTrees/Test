	#pragma once
#include "list.h"
#include "string.h"
#include "product.h"
#include "stringMap.h"
#include "menu.h"
#include "FIleManager.h"

#include "GoodsManager.h"
#include "GP_Manager.h"
#include "GD_Manager.h"


class MainManager 
{
	// �й��� Key�� ����ϴ� �л� ���� ���
	FileManager*			fileManager;
	Menu*					menu;

public:
	MainManager();
	~MainManager();

	void Init();
	void Run();

	void PrintProduct();
	void InputProduct();
	void SearchProduct();
	void SaveStudent();

	SubManager* GetProductManager(String code);
};