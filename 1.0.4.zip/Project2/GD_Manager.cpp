#pragma once
#include "GD_Manager.h"

GameDesignManager::GameDesignManager() {

}
GameDesignManager::GameDesignManager(const char* d, String de, List<Subject*>* sub, List<Product*>* _student) {
	departCode = (char*)d;
	departName = de;
	subjectList = sub;
	products = _student;
}
GameDesignManager::~GameDesignManager() {

}