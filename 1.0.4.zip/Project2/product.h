#pragma once
#include "global.h"
#include "string.h"
#include "list.h"
#include "menu.h"
#include "subject.h"
#include "subjectScore.h"


class Product {
private:
	String uid;
	String name;

	int price;

public:
	Product();
	Product(String name, String uid, char* type);
	Product(String _name, int _price) {
		name = _name;
		price = _price;
	}
	~Product();



	void	SetName(String n) { name = n; }
	String	GetName() { return name; }

	void	SetPrice(int p) { price = p; }
	int		GetPrice() { return price; }

	void	SetUid(String u) { uid = u; }
	String	GetUid() { return uid; }

	// ���� ���� �� ���ڿ� �ļ�
	void	FromText(String text);
	char*	ToSaveFormatString();

	virtual void Print() {}
};




class Goods : public Product {
private:
	int weight;

public:
	Goods(String _name, int _price, int _weight) : Product(_name, _price) {
		weight = _weight;
	}
	~Goods() {
	}

	void	SetWeight(int u)	{ weight = u; }
	int		GetWeight()			{ return weight; }

	void Print() override {
		cout << "�̸�: " << GetName() << endl;
		cout << "����: " << GetPrice() << "��" << endl; 
		cout << "����: " << GetWeight() << endl;
	}
};





class Clothes : public Product {
private:
	int size;

public:
	Clothes() {

	}
	~Clothes() {

	}
};






class Electron : public Product {
private:
	int modelUid;

public:
	Electron() {

	}
	~Electron() {

	}
};