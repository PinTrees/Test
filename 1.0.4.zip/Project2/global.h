#pragma once
#include <ostream>
#include "string.h"

using namespace std;

#define ARRAY_LEN(X) (sizeof(X)/sizeof(X[0]))
#define SAFE_DELETE(a) if(a != nullptr) { delete a; }
// �����ʿ�
#define SAFE_ARRAY_DELETE(a) if(a != nullptr) { delete[] a; }


// C# ������ ������Ƽ �ۼ� ��ũ�� - vs ������ ����
#define PROPERTY(_get,_set) _declspec(property(get = _get, put = _set))
#define PROPERTY_S(_set) _declspec(property(put = _set))
#define PROPERTY_G(_get) _declspec(property(get = _get))
//PROPERTY(GetTmp, SetTmp) int tmp;
//int GetTmp() { return aa; }
//void SetTmp(int _aa) { aa = _aa; }


// ��Ʈ ���ڿ��� ��ȯ�Լ�
static char* intToChar(int a)
{
	char buff[8];
	sprintf_s(buff, "%d", a);
	return buff;
}
static int ToInt(char* str)
{
	return atoi(str);
}
static int ToInt(String str)
{
	return atoi(str.characters);
}
static int ToInt(String* str)
{
	return atoi(str->characters);
}


// ��ȯ �Լ�
static char* ToChars(String* str)
{
	return str->characters;
}
static char* ToChars(String str)
{
	return str.characters;
}
static String ToString(int val)
{
	char buff[8];
	sprintf_s(buff, "%d", val);

	return String(buff);
}



static String ToKRW(int price) {
	/*String str = ToString(price);

	int size = 0;
	List<int> commaIndex;
	for (int i = str.length; i != 0; i--) {
		if (i % 3) {
			commaIndex.Add(i + size);
			size++;
		}
	}

	int length = str.length + size;
	char* characters = new char[length];

	for (int i = 0; i < length; i++) 
		if(commaIndex.)
		characters[i] = str.characters[i];

	characters[length - 1] = NULL;*/
}



enum class MAINMENU
{
	Inupt = 1,
	Print,
	Search,
	Save,
	Exit
};

enum class PRODUCT
{
	Goods = 1,
	Clothes,
	Electronic,
};

