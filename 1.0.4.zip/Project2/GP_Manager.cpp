#pragma once
#include "GP_Manager.h"

GameProgramingManager::GameProgramingManager() {

}
GameProgramingManager::GameProgramingManager(const char* d, String de, List<Subject*>* sub, List<Product*>* _student) {
	departCode = (char*)d;
	departName = de;
	subjectList = sub;
	products = _student;
}
GameProgramingManager::~GameProgramingManager() {

}
