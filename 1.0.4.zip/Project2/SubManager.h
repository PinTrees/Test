#pragma once
#include "list.h"
#include "product.h"

class SubManager {

public:
	char* departCode;
	String departName;
	List<Subject*>* subjectList;
	List<Product*>* products;

	virtual void Print();
	virtual void PrintProduct(Product* student);

	virtual void Input() {}
	virtual List<Product*>* Search(String searchText) {
		return nullptr;
	}
};
