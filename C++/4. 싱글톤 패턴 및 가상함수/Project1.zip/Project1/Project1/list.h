#pragma once
#include <iostream>
#include <functional>

using namespace std;

// ���� ����Ʈ
template<typename T> struct CNode
{
	CNode* next = nullptr;
	CNode* prev = nullptr;
	T value;

	CNode(T _value)
	{
		value = _value;
	}
	CNode(T _value, CNode* _next, CNode* _prev)
	{
		value = _value;
		next = _next;
		prev = _prev;
	}
};

template<typename T>
class List
{
public:
	CNode<T>* first;
	CNode<T>* last;
	int count;

public:
	List() : first(NULL), last(NULL), count(0)
	{
	}
	~List()
	{
		clear();
	}

public:
	int add(T item)
	{
		CNode<T>* newNode = new CNode<T>(item);
		if (count == 0)
		{
			first = newNode;
			last = newNode;
			newNode->next = NULL;
			newNode->prev = NULL;
		}
		else
		{
			newNode->next = NULL;
			newNode->prev = last;
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}

	int remove(T item)
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}


	// https://stackoverflow.com/questions/69941946/no-viable-conversion-from-lambda-to-void
	void ForEach(void (*fptr)(T))
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			(*fptr)(pThis->value);
			pThis = pThis->next;
		}
	}

	// https://stackoverflow.com/questions/7852101/c-lambda-with-captures-as-a-function-pointer
	void ForEachA(std::function<void(T)> fptr)
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			(fptr)(pThis->value);
			pThis = pThis->next;
		}
	}

	class Iterator
	{
	private:
		CNode<T>* node;
	public:
		Iterator(CNode<T>* node) : node(node) {}

		bool operator!=(const Iterator& other) const {
			return node != other.node;
		}

		T& operator*() {
			return node->value;
		}

		Iterator& operator++() {
			node = node->next;
			return *this;
		}
	};

	Iterator begin() const {
		return Iterator(first);
	}

	Iterator end() const {
		return Iterator(NULL);
	}




	// �ִ��� ������� ����
	T operator[] (int index)
	{
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	void clear()
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			CNode<T>* pDelete = pThis;
			pThis = pThis->next;

			delete pDelete;
			--count;
		}
		first = NULL;
		last = NULL;
	}
};



// Map �� entry ������ ���� ����Ʈ �����Լ� ���� ��
template<typename T> class Iterable
{
public:
	CNode<T>* first; // ù��° ���
	CNode<T>* last;  // ������ ���
	int count;

public:
	// ���� ������ ȣ��� �Բ� �ʱ�ȭ
	Iterable() : first(nullptr), last(nullptr), count(0)
	{
	}
	~Iterable()
	{
		clear();
	}

	// ����Ʈ Ŭ����
	void clear()
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			CNode<T>* pDelete = pThis;
			pThis = pThis->next;

			delete pDelete;
			--count;
		}
		first = nullptr;
		last = nullptr;
	}

	// ������ �ű� ��� �߰�
	int add(T item)
	{
		// �ű� ��� ����
		if (count == 0)
		{
			CNode<T>* newNode = new CNode<T>(item, nullptr, nullptr);
			first = newNode;
			last = newNode;
		}
		else
		{
			CNode<T>* newNode = new CNode<T>(item, nullptr, last);
			last->next = newNode;
			last = newNode;
		}
		++count;

		return count;
	}


	void ForEach(void (*fptr)(T))
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			(*fptr)(pThis->value);
			pThis = pThis->next;
		}
	}


	// ������� ����
	T operator[] (int index) {
		CNode<T>* node = nullptr;
		if (first == nullptr) return nullptr;

		if (index == 0) return first->value;

		node = first;
		for (int i = 0; i < index; i++)
		{
			if (node->next != nullptr) node = node->next;
			else return nullptr;
		}
		return node->value;
	}

	int remove(T item)
	{
		CNode<T>* pThis = first;
		while (pThis)
		{
			if (pThis->value == item)
			{
				if (pThis->prev)
				{
					pThis->prev->next = pThis->next;
				}
				else
				{
					first = pThis->next;
				}
				if (pThis->next)
				{
					pThis->next->prev = pThis->prev;
				}
				else
				{
					last = pThis->prev;
				}
				delete pThis;
				--count;
				break;
			}
			pThis = pThis->next;
		}
		return count;
	}
};