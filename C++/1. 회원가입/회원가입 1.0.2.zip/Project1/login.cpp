#pragma once
#include <iostream>
#include "string.cpp";
#include "list.cpp";
#include "map.cpp";
#include "stringMap.cpp"

using namespace std;

class User {

private:
	//String uid;
	String name;

public:
	String id;
	String password;

public:
	String getID()
	{
		return id;
	}
	String getPassword()
	{
		return password;
	}

public:
	User()
	{
	}
	User(String id, String password)
	{
		this->id = id;
		this->password = password;
	}
	~User()
	{
	}

	// NULL ����
	User(const int) {
		id = String(NULL);
		password = String(NULL);
	}

	bool SetId() {

	}

	void operator=(User user) {
		id = user.id;
		password = user.password;
	}
};


class UserList {

private:
	SMap<User> users; 

public:
	bool CompareID(String id) {
		return users.ContainKey(id.characters);
	}
	bool ComaprePassword(String id, String password) {
		return strcmp(users[id.characters].password.characters, password.characters) == 0;
	}
	User* CompareUser(String id, String password) {
		bool isIdCheck = CompareID(id);

		if (!isIdCheck) {
			cout << "���̵� ��ġ���� �ʽ��ϴ�." << endl;
			return nullptr;
		}

		bool isPasswordCheck = ComaprePassword(id.characters, password.characters);
		if (!isPasswordCheck) {
			cout << "��й�ȣ�� ��ġ���� �ʽ��ϴ�." << endl;
			return nullptr;
		}

		return &users[id.characters];
	}

    bool CreateUser(User user) {
		users[user.id.characters] = user;
		cout << user.id << "�� ȸ�������� �Ϸ�Ǿ����ϴ�" << endl;
		return true;
	} 
	bool DeleteUser(User* user) {
		users.remove(user->id.characters);
		return true;
	}

};

class LoginManager {

public:
	UserList userList;
	User* currentUser = nullptr;

private:


public:
	LoginManager()
	{

	}
	~LoginManager()
	{

	}

	bool Login() {
		String idInput;
		String passwordInput;

		cout << "���̵� �Է�: ";
		cin >> idInput;

		cout << "�н����� �Է�: ";
		cin >> passwordInput;

		currentUser = userList.CompareUser(idInput, passwordInput);
		if (currentUser == nullptr) {
			return false;
		}
	}
	User* Login(User* user) {
		currentUser = user;
		return user;
	}

	void SignUp() {
		String idInput;
		String passwordInput;
		User user;

		cout << "���̵� �Է�: ";
		cin >> idInput;
		bool idDuplicate = userList.CompareID(idInput);

		if (idDuplicate)
		{
			cout << "���̵� �ߺ���" << endl;
			SignUp();
		}

		cout << "�н����� �Է�: ";
		cin >> passwordInput;

		/// �н����� �˻� �ʿ�

		user = User(idInput, passwordInput);

		bool isCreate = userList.CreateUser(user);

		if (isCreate) 
		{
			Login(&user);
		}
	}
	bool LogOut() {
		String input;
		cout << "�α׾ƿ� �Ͻðڽ��ϱ�? y/n: ";
		cin >> input;

		if (input == "y" || input == "Y")
		{
			currentUser = nullptr;
			return true;
		}
		else {
			return false;
		}
	}
	bool DeleteUser() {
		String input;
		cout << "ȸ��Ż�� �Ͻðڽ��ϱ�? y/n: ";
		cin >> input;

		if (input == "y" || input == "Y")
		{
			userList.DeleteUser(currentUser);
			currentUser = nullptr;
			return true;
		}
		else {
			return false;
		}
	}
};