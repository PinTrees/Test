#pragma once
#include <iostream>
#include <stdlib.h>
#include "string.cpp";
#include "login.cpp";
#include "list.cpp"
#include "map.cpp"
#include "stringMap.cpp"



// String << ������ �������̵�
//  ���� �Լ��� �ִ� cpp ���Ͽ� �����ε� �ؾ����� Ȯ�� 
// 
// [����]
// https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=duehd88&logNo=20201487812
ostream& operator<<(ostream& cout, const String& ms) {
    if(ms.length > 0)
        cout << ms.characters; 
    return cout;
}

istream& operator>>(istream& cin, String& ms) {
    char* tmp = new char[10000];//�ް�
    cin >> tmp;
    ms = tmp;
    //cout << ms << endl;
    return cin;
}
  







int main()
{
    SMap<String> mainMenu;
    mainMenu["1"] = "ȸ������"; 
    mainMenu["2"] = "�α���"; 
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";
    mainMenu["3"] = "����";

    SMap<String> loginMenu;
    loginMenu["1"] = "�α׾ƿ�"; 
    loginMenu["2"] = "ȸ��Ż��";

    LoginManager loginManager;

    while (true)
    {
        String userInput;
    
        if (loginManager.currentUser != nullptr) {
            system("cls");
            cout << "[ �α��θ޴� ]\n" << endl;
            for (int i = 0; i < loginMenu.keys.count; i++) {
                cout << loginMenu.keys.elementAt(i) << ": " << loginMenu[loginMenu.keys.elementAt(i)] << endl;
            }

            cout << endl << "����: ";
            cin >> userInput;

            if (userInput == "1" || userInput == "�α׾ƿ�") {
                system("cls");
                cout << "[ " << mainMenu["1"] << " �޴� ]" << endl << endl;
                bool isLogout = loginManager.LogOut();
            }
            else if (userInput == "2" || userInput == "ȸ��Ż��") {
                system("cls");
                cout << "[ " << mainMenu["2"] << " �޴� ]" << endl << endl;
                loginManager.DeleteUser();    
            }
        } 
        else {
            system("cls"); 
            cout << "[ ���θ޴� ]\n" << endl;
            for (int i = 0; i < mainMenu.keys.count; i++) {
                cout << mainMenu.keys.elementAt(i) << ": " << mainMenu[mainMenu.keys.elementAt(i)] << endl;
            }

            cout << endl << "����: ";
            cin >> userInput;

            if (userInput == "1" || userInput == "ȸ������") {
                system("cls");
                cout << "[ " << mainMenu["1"] << " �޴� ]" << endl << endl;
                loginManager.SignUp();
            }
            else if (userInput == "2" || userInput == "�α���") {
                while (true)
                {
                    system("cls");
                    cout << "[ " << mainMenu["2"] << " �޴� ]" << endl << endl;
                    bool isLogined = loginManager.Login();

                    if (!isLogined) {
                        cout << endl << "�ٽ� �õ��Ͻðڽ��ϱ�? y/n: ";
                        cin >> userInput;

                        if (userInput == "y" || userInput == "Y") { }
                        else {
                            break;
                        }
                    }
                    else {
                        break;
                    }
                }
              
            }
        }
     
    }

    system("pause");
}
