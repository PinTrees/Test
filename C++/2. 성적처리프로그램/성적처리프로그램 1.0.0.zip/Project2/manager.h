#pragma once
#include <iostream>
#include "list.h"
#include "global.h"
#include "string.h"
#include "list.h"
#include "student.h"
#include "stringMap.h"
#include "menu.h"

class Manager {

public:
	SMap<Student*>* students;
	Menu* menu;


	void Init() {
		students = new SMap<Student*>();
		menu = new Menu();

	}


	void Run() {
		while (true)
		{
			String* select = menu->MainMenu();

			if (*select == "1") {
				CreateRank();
			}
			else if (*select == "2") {
				SearchRank();
			}
			else if (*select == "3") {

			}
			else if (*select == "4") {

			}
		}
	}




	void CreateRank() {
		while (true)
		{
			String* subjectSelect = menu->SubjectMenu();
			if (strcmp(subjectSelect->characters, "") == 0) continue;

			List<String>* subjects = menu->classSubMenu[subjectSelect->characters];


			system("cls");
			cout << "�л����� �Է�" << endl << endl;

			Student* student = new Student;
			student->subjectType = subjectSelect->characters;

			String input;

			cout << "�̸�";
			cin >> input;
			student->name = input;


			while (true)
			{
				cout << "�й�";
				cin >> input;

				bool isUsed = students->ContainKey(input.characters);
				if (isUsed) {
					cout << "�̹� ������� �й�. �ٽ� �Է�" << endl;
					input = "";
					continue;
				}
				else {
					student->uid = input;
					break;
				}
			}


			cout << endl << "�л����� �Է�" << endl << endl;

			for (int i = 0; i < subjects->count; i++) {
				cout << subjects->elementAt(i);
				cin >> input;

				student->rank[i] = atoi(input.characters);
				// ���� - �����˻� �߰� 
			}

			students->add(student->uid.characters, student);
			break;
		}
	}


	void SearchRank() {
		system("cls");
		cout << "�л����� �˻�" << endl << endl;

		String input;

		cout << "�й�";
		cin >> input;
		bool isExist = students->ContainKey(input.characters);
		if (!isExist) {

		}

		Student* student = students->ContainValue(input.characters);

		cout << student->uid << endl;
		cout << student->name << endl;

		for (int i = 0; i < ARRAY_LEN(student->rank); i++) {
			cout << menu->classSubMenu[] << endl;
			cout << student->rank[i] << endl;
		}


	}
};