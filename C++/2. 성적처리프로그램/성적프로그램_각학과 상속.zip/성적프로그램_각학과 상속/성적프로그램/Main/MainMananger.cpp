#include "MainManager.h"

CMainManager::CMainManager()
{
	mDesignMng = nullptr;
	mGraphicMng = nullptr;
	mProgramMng = nullptr;
}

void CMainManager::Initialize()
{
	mDesignMng = new CDesignManager();
	mGraphicMng = new CGraphicManager();
	mProgramMng = new CProgrammingManager();
}


CMainManager::~CMainManager()
{
	if (mDesignMng != nullptr)
	{
		delete mDesignMng;
	}

	if (mGraphicMng != nullptr)
	{
		delete mGraphicMng;
	}

	if (mProgramMng != nullptr)
	{
		delete mProgramMng;
	}

}

MENU CMainManager::ShowMenu()
{
	MENU select;
	
	cout << "<�������α׷�>" << endl;
	cout << "1.�����Է�" << endl;
	cout << "2.�������" << endl;
	cout << "3.������ȸ" << endl;
	cout << "4.����" << endl;
	cout << "����:";
	cin >> select;

	return select;

}

void CMainManager::Run()
{
	int select;	

	Initialize();

	while (1)
	{
		MENU select = ShowMenu();
		
		switch (select)
		{
		case MENU::INPUT:
			MajorInput();
			break;
		case MENU::SHOWDATA:
			MajorDisplay();
			break;
		case MENU::SEARCHDATA:
			MajorSearchData();
			break;
		case MENU::EXIT:
			return;
			break;
		default:
			cout << "�߸� �Է��߽��ϴ� �ٽ� �Է��ϼ��� " << endl;
		}
	}


}
void CMainManager::MajorInput()
{
	while (1)
	{
		cout << "(���α׷���:1, �׷���:2, ��ȹ:3)" << endl;
		cout << "����:";
		MAJOR sel;
		cin >> sel;


		switch (sel)
		{
		case MAJOR::PROGRAMMING:
			mProgramMng->Input();
			break;
		case MAJOR::GRAPHIC:
			mGraphicMng->Input();
			break;
		case MAJOR::DESIGN:
			mDesignMng->Input();
			break;
		default:
			cout << "�߸� �Է��߽��ϴ�." << endl;
			continue;
		}

		break;
	}

}
void CMainManager::MajorSearchData()
{
	while (1)
	{
		cout << "(���α׷���:1, �׷���:2, ��ȹ:3)" << endl;
		cout << "����:";
		MAJOR sel;
		cin >> sel;


		switch (sel)
		{
		case MAJOR::PROGRAMMING:
			mProgramMng->Search();
			break;
		case MAJOR::GRAPHIC:
			mGraphicMng->Search();
			break;
		case MAJOR::DESIGN:
			mDesignMng->Search();
			break;
		default:
			cout << "�߸� �Է��߽��ϴ�." << endl;
			continue;
		}

		break;
	}

}
void CMainManager::MajorDisplay()
{
	while (1)
	{
		cout << "(���α׷���:1, �׷���:2, ��ȹ:3)" << endl;
		cout << "����:";
		MAJOR sel;
		cin >> sel;


		switch (sel)
		{
		case MAJOR::PROGRAMMING:
			mProgramMng->Display();
			break;
		case MAJOR::GRAPHIC:
			mGraphicMng->Display();
			break;
		case MAJOR::DESIGN:
			mDesignMng->Display();
			break;
		default:
			cout << "�߸� �Է��߽��ϴ�." << endl;
			continue;
		}

		break;
	}

}

