#include "Global.h"
istream& operator>>(istream& i, MAJOR& input)
{
	scanf("%d", &input);
	return i;
}

istream& operator>>(istream& i, MENU& input)
{
	scanf("%d", &input);
	return i;
}
