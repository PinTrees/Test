#pragma once

#include <iostream>
#include <string.h>

using namespace std;

#define STUDENT_ID_SIZE 10
#define SUBJECT_ID_SIZE 3

enum class MAJOR
{ 
	PROGRAMMING = 1, 
	GRAPHIC, 
	DESIGN 
};

enum class MENU
{ 
	INPUT = 1, 
	SHOWDATA, 
	SEARCHDATA, 
	EXIT 
};

istream& operator>>(istream& i, MAJOR& input);

istream& operator>>(istream& i, MENU& input);

