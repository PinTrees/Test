#ifndef CGRAPHIC_MANAGER_H
#define CGRAPHIC_MANAGER_H
#include "../../Student/Student.h"
#include "../Manager.h"

class CGraphicManager : public CManager
{
private:
	static const char* SubjectId[];
	static const char* SubjectName[];
	static const char* MajorCode;
	static int			MaxCount;

public:
	CGraphicManager();
	~CGraphicManager();

	void Input();
	void Display();
	void Search();

	double CalculateGrade(int);
	double CalculateAvgGrade(CSubject**);

};
#endif