#pragma once

#include "../Main/Global.h"
#include "../Student/Student.h"

class CManager
{
protected:
	CStudent**					mStudentList;
	int							mStuCount;

public:
	CManager(int);
	~CManager();	
};
