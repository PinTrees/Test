#pragma once

#include "../../Student/Student.h"
#include "../Manager.h"

class CProgrammingManager :public CManager
{
private:
	static const char*	SubjectId[];
	static const char*	SubjectName[];	
	static const char*  MajorCode;
	static int			MaxCount;


public:
	CProgrammingManager();
	~CProgrammingManager();

	void Input();
	void Display();
	void Search();

	double CalculateGrade(int);
	double CalculateAvgGrade(CSubject**);
	
};
