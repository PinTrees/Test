 #include "ProgrammingManager.h"

const char* CProgrammingManager::SubjectName[] = { "C++2", "C#", "API2" };
const char* CProgrammingManager::SubjectId[] = { "001", "002", "003" };
const char* CProgrammingManager::MajorCode = "302";
int CProgrammingManager::MaxCount = 10;

CProgrammingManager::CProgrammingManager() :CManager(MaxCount)
{

}

CProgrammingManager::~CProgrammingManager()
{

}

void CProgrammingManager::Input()
{
	char name[256];
	char id[STUDENT_ID_SIZE+1];
	int  score;
	double grade;

	cout << "<<���α׷����а� �����Է�>>" << endl;

	cout << "�̸�:";
	cin >> name;

	sprintf(id, "2023%s%03d", MajorCode, mStuCount + 1);

	CStudent* ptr = new CStudent(id, name);
	ptr->InitSubject(sizeof(SubjectName) / sizeof(char*));

	for (int i = 0; i < sizeof(SubjectName) / sizeof(char*); i++)
	{
		cout << SubjectName[i] << ":";
		cin >> score;
		grade = CalculateGrade(score);
		CSubject* subject = new CSubject(SubjectId[i], SubjectName[i], score, grade);
		ptr->AddSubject(subject);
	}
	CSubject** subjectlist = ptr->GetSubject();
	ptr->SetAvgGrade(CalculateAvgGrade(subjectlist));

	mStudentList[mStuCount++] = ptr;
}

void CProgrammingManager::Display()
{
	cout << "<<���α׷����а� �л� ��������>>" << endl;

	if (mStuCount == 0)
	{
		cout << "�Էµ� �л������� �����ϴ�." << endl;
	}

	for (int i = 0; i < mStuCount; i++)
	{
		cout << "�̸�:" << mStudentList[i]->GetName() << endl;
		cout << "�й�:" << mStudentList[i]->GetId() << endl;
		
		CSubject** subjectlist = mStudentList[i]->GetSubject();

		for (int j = 0; j < sizeof(SubjectName) / sizeof(char*); j++)
		{
			cout << SubjectName[j] << ":";
			cout << subjectlist[j]->GetGrade() << endl;
		}		

		cout << "����:";
		cout << mStudentList[i]->GetAvgGrade() << endl;
		cout << "=========================================" << endl;
	}
}

void CProgrammingManager::Search()
{
	char id[STUDENT_ID_SIZE + 1];
	cout << "�й�:";
	cin >> id;
	cout << "<< " << id << " �л��� ��������" << endl;
	bool flag = false;

	for (int i = 0; i < mStuCount; i++)
	{
		if (!strcmp(mStudentList[i]->GetId(), id))
		{
			flag = true;
			cout << "�̸�:" << mStudentList[i]->GetName() << endl;
			cout << "�й�:" << mStudentList[i]->GetId() << endl;

			CSubject** subjectlist = mStudentList[i]->GetSubject();

			for (int j = 0; j < sizeof(SubjectName) / sizeof(char*); j++)
			{
				cout << SubjectName[j] << ":";
				cout << subjectlist[j]->GetGrade() << endl;
			}

			cout << "����:";
			cout << mStudentList[i]->GetAvgGrade() << endl;
			break;
		}
	}

	if (!flag)
	{
		cout << "�Է��� id�� �л��� �������� �ʽ��ϴ�." << endl;
	}
}

double CProgrammingManager::CalculateGrade(int  _score)
{
	double temp = 0.0;
	int subject_count = sizeof(SubjectName) / sizeof(char*);

	int score = _score / 10;
	int m = _score % 10;

	switch (score)
	{
	case 10:
	case 9:
		if (m > 4)
		{
			return 4.5;
		}
		else
		{
			return 4.0;
		}
		break;
	case 8:
		if (m > 4)
		{
			return 3.5;
		}
		else
		{
			return 3.0;
		}

		break;
	case 7:
		if (m > 4)
		{
			return 2.5;
		}
		else
		{
			return 2.0;
		}
		break;
	case 6:
		if (m > 4)
		{
			return 1.5;
		}
		else
		{
			return 1.0;
		}

		break;
	}

	return 0.0;

}


double CProgrammingManager::CalculateAvgGrade(CSubject** _stulist)
{
	double total_grade = 0.0;

	int subject_count = sizeof(SubjectName) / sizeof(char*);

	for (int i = 0; i < subject_count; i++)
	{
		total_grade = total_grade + _stulist[i]->GetGrade();
	}

	return total_grade / subject_count;
}