#ifndef CDESIGN_MANAGER_H
#define CDESIGN_MANAGER_H
#include "../../Student/Student.h"
#include "../Manager.h"

class CDesignManager: public CManager
{
private:
	static const char* SubjectId[];
	static const char* SubjectName[];
	static const char* MajorCode;
	static int			MaxCount;

public:
	CDesignManager();
	~CDesignManager();

	void Input();
	void Display();
	void Search();

	double CalculateGrade(int);
	double CalculateAvgGrade(CSubject**);
};
#endif