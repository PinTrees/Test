#include "Manager.h"

CManager::CManager(int _count)
{
	mStudentList = new CStudent*[_count];
	mStuCount = 0;
}

CManager::~CManager()
{
	if (mStudentList != nullptr)
	{
		for (int i = 0; i < mStuCount; i++)
		{
  			delete mStudentList[i];
		}

		delete [] mStudentList;
	}
}