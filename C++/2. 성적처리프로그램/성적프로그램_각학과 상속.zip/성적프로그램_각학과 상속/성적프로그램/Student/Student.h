#pragma once

#include "../Main/Global.h"
#include "CSubject.h"

class CStudent
{
private:
	char mId[STUDENT_ID_SIZE+1];
	char* mName;
	CSubject** mSubject;
	int mSubjectCount;
	double mAvgGrade;

public:
	CStudent();
	CStudent(const char*, const char*);
	~CStudent();

	void SetId(const char*);
	void SetName(const char*);
	void SetAvgGrade(double);
	
	void InitSubject(int);

	const char* GetId();
	const char* GetName();
	
	CSubject** GetSubject();	
	double GetAvgGrade();
	int GetSubjectCount();

	CSubject* AddSubject(CSubject*);
	bool RemvoeSubject(CSubject*);	

	//void CalculateAvgGrade();
};
