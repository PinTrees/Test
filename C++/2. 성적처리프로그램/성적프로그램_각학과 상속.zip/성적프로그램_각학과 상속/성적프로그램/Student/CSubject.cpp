#include "CSubject.h"

CSubject::CSubject()
{
	memset(mSubjectId, 0, sizeof(mSubjectId));
	mSubjectName = nullptr;
	mScore = 0;
	mGrade = 0.0;
}

CSubject::CSubject(const char* _id, const char* _name)
{
	strcpy(mSubjectName, _id);
	mSubjectName = new char[strlen(_name) + 1];
	strcpy(mSubjectId, _name);
	mScore = 0;
	mGrade = 0.0;
}

CSubject::~CSubject()
{
	if (mSubjectName != nullptr)
	{		
		delete [] mSubjectName;
	}
}

CSubject::CSubject(const char* _id, const char* _name, int _score)
{	
	strcpy(mSubjectId, _id);
	mSubjectName = new char[strlen(_name) + 1];
	strcpy(mSubjectId, _name);

	mScore = _score;
	mGrade = 0.0;

}

CSubject::CSubject(const char* _id, const char* _name, int _score, double _grade)
{	
	strcpy(mSubjectId, _id);
	mSubjectName = new char[strlen(_name) + 1];
	strcpy(mSubjectName, _name);

	mScore = _score;
	mGrade = _grade;
}

const char* CSubject::GetSubjectId()
{
	return mSubjectId;
}

const char* CSubject::GetSubjectName()
{
	return mSubjectName;
}

int CSubject::GetScore()
{
	return mScore;
}

double CSubject::GetGrade()
{
	return mGrade;
}

void CSubject::SetScore(int _score)
{
	mScore = _score;
}

void CSubject::SetGrade(double _grade)
{
	mGrade = _grade;
}
