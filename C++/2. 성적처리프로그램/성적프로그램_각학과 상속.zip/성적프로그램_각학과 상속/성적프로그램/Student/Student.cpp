#include "Student.h"
CStudent::CStudent()
{
	memset(mId, 0, sizeof(mId));
	mName = nullptr;
	mSubject = nullptr;
	mSubjectCount = 0;
	mAvgGrade = 0.0;
}
CStudent::CStudent(const char* _id, const char* _name)
{
	strcpy(mId, _id);
	
	mName= new char[strlen(_name) + 1];
	strcpy(mName, _name);

	mSubject = nullptr;
	mSubjectCount = 0;
	mAvgGrade = 0.0;
}

CStudent::~CStudent()
{
	if (mName != nullptr)
	{
		delete [] mName;
	}

	if (mSubject != nullptr)
	{
		for (int i = 0; i < mSubjectCount; i++)
		{
			delete mSubject[i];
		}

		delete[] mSubject;
	}
}

void CStudent::SetId(const char* _id)
{
	strcpy(mId, _id);
}

void CStudent::SetName(const char* _name)
{
	if (mName != nullptr)
	{
		delete [] mName;
	}

	mName = new char[strlen(_name) + 1];
	strcpy(mName, _name);
}

void CStudent::SetAvgGrade(double _average)
{
	mAvgGrade = _average;
}

void CStudent::InitSubject(int _count)
{
	if (mSubject != nullptr)
	{
		delete[] mSubject;
	}

	mSubject = new CSubject*[_count];
}

const char* CStudent::GetId()
{
	return mId;
}

const char* CStudent::GetName()
{
	return mName;

}

CSubject** CStudent::GetSubject()
{
	return mSubject;
}

double CStudent::GetAvgGrade()
{
	return mAvgGrade;
}


int CStudent::GetSubjectCount()
{
	return mSubjectCount;
}


CSubject* CStudent::AddSubject(CSubject* _stu)
{
	if (mSubject != nullptr)
	{
		mSubject[mSubjectCount++] = _stu;
		return _stu;
	}

	return nullptr;	
}

bool CStudent::RemvoeSubject(CSubject* _stu)
{
	if (mSubject == nullptr)
	{
		return false;
	}

	for (int i = 0; i < mSubjectCount; i++)
	{
		if (mSubject[i] == _stu)
		{
			for (int j = i; j < mSubjectCount - 1; j++)
			{
				mSubject[j] = mSubject[j+1];
			}
			mSubjectCount--;
			break;
		}
	}

	return true;
}

