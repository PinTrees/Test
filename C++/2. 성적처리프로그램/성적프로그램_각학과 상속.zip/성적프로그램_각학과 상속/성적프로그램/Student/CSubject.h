#pragma once
#include "../Main/Global.h"

class CSubject
{
	char mSubjectId[SUBJECT_ID_SIZE+1];
	char* mSubjectName;	
	int mScore;
	double mGrade;

public:
	CSubject();
	CSubject(const char*, const char*);
	CSubject(const char*, const char*, int);
	CSubject(const char*, const char*, int, double);

	~CSubject();

	const char* GetSubjectId();
	const char* GetSubjectName();
	int GetScore();
	double GetGrade();

	void SetScore(int);
	void SetGrade(double);
};

