#pragma once
#include <ostream>
#include "string.h"

using namespace std;

#define ARRAY_LEN(X) (sizeof(X)/sizeof(X[0]))

