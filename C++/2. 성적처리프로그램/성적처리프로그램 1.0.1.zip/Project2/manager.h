#pragma once
#include "global.h"
#include "list.h"
#include "string.h"
#include "student.h"
#include "stringMap.h"
#include "menu.h"

class Manager {

	SMap<Student*>* students;
	Menu* menu;

public:
	Manager();
	~Manager();

	void Init();
	void Run();

	void PrintRank();
	void CreateRank();
	void SearchRank();
};