#include "manager.h"

Manager::Manager() {

}
Manager::~Manager() {

}

void Manager::Init() {
	students = new SMap<Student*>();
	menu = new Menu();

}
void Manager::Run() {
	while (true)
	{
		String* select = menu->MainMenu();

		if (*select == "1") {
			CreateRank();
		}
		else if (*select == "2") {
			SearchRank();
		}
		else if (*select == "3") {
			PrintRank();
		}
		else if (*select == "4") {
			break;
		}
	}

	return;
}

 
void Manager::PrintRank() { 
	String input;
	if (students->count <= 0) {
		cout << "����� ������ �����ϴ�." << endl;
	}
	else {
		system("cls");
		cout << "�л� ���� ���" << endl << endl;

		for (int i = 0; i < students->count; i++) {
			Student* student = students->ContainValue(students->keys.elementAt(i));
			cout << "�й�: " << student->uid << endl;
			cout << "�̸�: " << student->name << endl;
			cout << "�а�: " << menu->classMenu[student->subjectType] << endl << endl;

			for (int i = 0; i < ARRAY_LEN(student->rank); i++) {
				cout << menu->classSubMenu[student->subjectType]->elementAt(i) << ": " << student->rank[i] << "\t\t";
			}
			cout << endl << endl;
		}
	}

	cout << "���: ";
	cin >> input;
}

void Manager::CreateRank() {
	while (true)
	{
		String subjectSelect = menu->SubjectMenu();

		if (strcmp(subjectSelect.characters, "") == 0)
		{
			cout << "�а��� �ٽ� ������ �ּ���." << endl;
			continue;
		}

		List<String>* subjects = menu->classSubMenu[subjectSelect.characters];


		system("cls");
		cout << "�л����� �Է�" << endl << endl;

		Student* student = new Student;
		student->subjectType = subjectSelect.characters;

		String input;

		while (true)
		{
			cout << "�й�";
			cin >> input;

			bool isUsed = students->ContainKey(input.characters);
			if (isUsed) {
				cout << "�̹� ������� �й�. �ٽ� �Է�" << endl;
				input = "";
				continue;
			}
			else {
				student->uid = input;
				break;
			}
		}

		cout << "�̸�";
		cin >> input;
		student->name = input;

		cout << endl << "�л����� �Է�" << endl << endl;

		for (int i = 0; i < subjects->count; i++) {
			cout << subjects->elementAt(i);
			cin >> input;

			student->rank[i] = atoi(input.characters);
			// ���� - �����˻� �߰� 
		}

		students->add(student->uid.characters, student);
		break;
	}
}

void Manager::SearchRank() {
	system("cls");
	cout << "�л����� �˻�" << endl << endl;

	String input;

	cout << "�й� �Է�: ";
	cin >> input;


	bool isExist = students->ContainKey(input.characters);
	if (!isExist) {

	}
	else {
		system("cls");
		cout << "�л� ���� ��ȸ ���" << endl << endl;

		Student* student = students->ContainValue(input.characters);
		cout << "�й�: " << student->uid << endl;
		cout << "�̸�: " << student->name << endl;
		cout << "�а�: " << menu->classMenu[student->subjectType] << endl << endl;

		for (int i = 0; i < ARRAY_LEN(student->rank); i++) {
			cout << menu->classSubMenu[student->subjectType]->elementAt(i) << ": " << student->rank[i] << endl;
		}
	}

	cout << endl << "���: ";
	cin >> input;
}


