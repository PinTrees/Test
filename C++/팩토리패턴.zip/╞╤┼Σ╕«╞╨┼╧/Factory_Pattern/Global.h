#ifndef _GLOBAL_H
#define _GLOBAL_H
#include <iostream>
using namespace std;

#endif