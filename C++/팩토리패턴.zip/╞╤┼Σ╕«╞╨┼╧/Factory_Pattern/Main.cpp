#include "Global.h"
#include "GimBabHeavenStore.h"
#include "GoBongMinGimBabStore.h"

int main(void)
{
	CGimBabStore* store = new CGimBabHeavenStore();
	CGimBab* gimbab=store->OrderGimBab();
	delete store;
	delete gimbab;
	return 0;
}