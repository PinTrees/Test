#ifndef _CVEGGIEGIMBAB_STORE_H
#define _CVEGGIEGIMBAB_STORE_H

#include "GimBabStore.h"
#include "CheeseGimBab.h"
#include "VegetableGimBab.h"

class CGoBongMinGimBabStore:public CGimBabStore
{
private:
	CGimBabStore::Menu*  mGoBongMinGimBabMenu[10];
	int mCount;
	CGoBongMinGimBabFactory* mFactory;

	virtual CGimBab* CreateGimBab(const char*, int);;
	virtual Menu* MenuSelect();;
	virtual CGimBab* WrapGimBab(CGimBab*);

public:
	CGoBongMinGimBabStore();
	~CGoBongMinGimBabStore();
};
#endif