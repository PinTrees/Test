#ifndef _CCHEESEGIMBAB_STORE_H
#define _CCHEESEGIMBAB_STORE_H
#include "GimBabStore.h"
#include "CheeseGimBab.h"
#include "VegetableGimBab.h"

class CGimBabHeavenStore :public CGimBabStore
{
private:
	CGimBabStore::Menu* mGimBabHeavenMenu[10];
	int   mCount;
	CGimBabHeavenFactory* mFactory;

	virtual CGimBab* CreateGimBab(const char*, int);
	virtual CGimBabStore::Menu* MenuSelect();
	virtual CGimBab* WrapGimBab(CGimBab*);

public:

	CGimBabHeavenStore();
	~CGimBabHeavenStore();
	
};
#endif