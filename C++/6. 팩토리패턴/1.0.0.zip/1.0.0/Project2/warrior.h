#pragma once
#include "Charactor.h"

class WarriorOak : public Oak
{
public:
	WarriorOak() {}
	WarriorOak(const WarriorOak& _rhs) {}
	~WarriorOak() {}
};

class WarriorHuman : public Human
{
public:
	WarriorHuman() {}
	WarriorHuman(const WarriorHuman& _rhs) {}
	~WarriorHuman() {}
};