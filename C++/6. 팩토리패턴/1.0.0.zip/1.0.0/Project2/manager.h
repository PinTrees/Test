	#pragma once
#include "list.h"
#include "string.h"
#include "stringMap.h"
#include "fileManager.h"
#include "console.h"

#include "Charactor.h"
#include "factory.h"

// �ּ� cpp �ۼ���

class MainManager 
{
public:
	MainManager();
	~MainManager();

	void Init();
	void Run();
	void Dispose();

	void CreateCharactor(int index) {
		CFactory* pFactory = nullptr;
		switch (index)
		{
		case 1:
			pFactory = new WarriorFactory();
			break;
		case 2:
			pFactory = new HealerFactory();
			break;
		}
			
		if (pFactory == nullptr)
			throw invalid_argument("(CFactory)pFactory class is null reference");

		pFactory->CreateCharactor(1);
		pFactory->CreateCharactor(2);
	}


	void CreateMethodCharactor(int index) {
		MethodFactory* pFactory = new MethodFactory();

		if (pFactory == nullptr)
			throw invalid_argument("(MethodFactory)pFactory is null reference");

		pFactory->CreateCharactor(1);
		pFactory->CreateCharactor(2);
	}
};