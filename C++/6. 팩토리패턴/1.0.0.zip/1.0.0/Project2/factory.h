#pragma once
#include "Charactor.h"
#include "warrior.h"
#include "healer.h"

class CFactory
{
public:
	CFactory() {}
	CFactory(const CFactory& _rhs) {}
	~CFactory() {}
	virtual Charactor* CreateCharactor(int _iType) = 0;
};


class WarriorFactory : public CFactory
{
public:
	WarriorFactory() {}
	WarriorFactory(const WarriorFactory& _rhs) {}
	~WarriorFactory() {}

    Charactor* CreateCharactor(int _iType) override  {
		switch (_iType)
		{
		case 1:
			return new WarriorOak();
		case 2:
			return new WarriorHuman();
		default: 
			return nullptr;
		}
	}
};


class HealerFactory : public CFactory
{
public:
	HealerFactory() {}
	HealerFactory(const HealerFactory& _rhs) {}
	~HealerFactory() {}

	Charactor* CreateCharactor(int _iType) override {
		switch (_iType)
		{
		case 1:
			return new HealerElf();
		case 2:
			return new HealerHuman();
		default:
			return nullptr;
		}
	}
};


class MethodFactory {
public:
	
	Charactor* CreateCharactor(int index)
	{
		switch (index)
		{
		case 1:
			return new HealerElf();
		case 2:
			return new HealerHuman();
		case 3:
			return new WarriorOak();
		case 4:
			return new WarriorHuman();
		}
	}
};