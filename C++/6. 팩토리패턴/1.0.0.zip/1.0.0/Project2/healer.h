#pragma once
#include "Charactor.h"

class HealerElf : public Elf
{
public:
	HealerElf() {}
	HealerElf(const HealerElf& _rhs) {}
	~HealerElf() {}
};

class HealerHuman : public Human
{
public:	
	HealerHuman() {}
	HealerHuman(const HealerHuman& _rhs) {}
	~HealerHuman() {}
};