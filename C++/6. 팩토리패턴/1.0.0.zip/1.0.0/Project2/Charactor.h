#pragma once

class Charactor
{
public:
	Charactor() {}
	Charactor(const Charactor& _rhs) {}
	~Charactor() {}
};


// CFood_Fried Ŭ���� : Ƣ��
class Oak : public Charactor
{
public: 
	Oak() {}
	Oak(const Oak& _rhs) {}
	~Oak() {}
};


// CFood_Noodles Ŭ���� : ��
class Human : public Charactor
{
public:
	Human() {}
	Human(const Human& _rhs) {}
	~Human() {}
};


// CFood_Noodles Ŭ���� : ��
class Elf : public Charactor
{
public:
	Elf() {}
	Elf(const Elf& _rhs) {}
	~Elf() {}
};
