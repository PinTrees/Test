#include "subject.h"

Subject::Subject() {}
void Subject::fromText(String text)
{
	text.Trim();
	List<String*>* splits = text.Split(',');

	type	    =	(*splits)[0]->characters;
	id			=	(*splits)[1]->characters;
	subjectName =	(*splits)[2];
} 