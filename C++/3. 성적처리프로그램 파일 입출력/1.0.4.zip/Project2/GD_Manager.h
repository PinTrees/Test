#pragma once
#include "list.h"
#include "student.h"
#include "SubManager.h"


class GameDesignManager : public SubManager {
public:
	GameDesignManager();
	GameDesignManager(const char* d, String de, List<Subject*>* sub, List<Student*>* _student);
	~GameDesignManager();
};