#pragma once
#include "GP_Manager.h"

GameProgramingManager::GameProgramingManager() {

}
GameProgramingManager::GameProgramingManager(const char* d, String de, List<Subject*>* sub, List<Student*>* _student) {
	departCode = (char*)d;
	departName = de;
	subjectList = sub;
	students = _student;
}
GameProgramingManager::~GameProgramingManager() {

}
