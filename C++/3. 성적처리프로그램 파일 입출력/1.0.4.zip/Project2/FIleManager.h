#pragma once
#include <fstream> // ifstream header
#include <iostream>
#include "student.h"
#include "list.h"
#include "stringMap.h"
#include <sstream>

using namespace std;

class FileManager
{
public:
	bool SaveStudentsAsFile(SMap<Student*>* studens);
	SMap<Student*>* GetStudentsFromFile();
	SMap<List<Student*>*>* GetStudentsSubManagerFromFile();
	SMap<Subject*>* GetSubjectListFromFile();
};

