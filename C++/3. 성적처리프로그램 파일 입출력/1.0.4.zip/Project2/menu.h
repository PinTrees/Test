#pragma once
#include "string.h"
#include "stringMap.h"

class Menu 
{

public:
	SMap<String*> mainMenu;
	SMap<String> printMenu;

	SMap<String> departmentMenu;

public:
	Menu();
	~Menu();
	void Init();

	String* MainMenu();
	String DepartmentMenu();
	String PrintMenu();
};