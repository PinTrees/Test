#pragma once
#include "CG_Manager.h"

GameGraphicManager::GameGraphicManager() {

}
GameGraphicManager::GameGraphicManager(const char* d, String de, List<Subject*>* sub, List<Student*>* _student) {
	departCode = (char*)d;
	departName = de;
	subjectList = sub;
	students = _student;
}
GameGraphicManager::~GameGraphicManager() {

}