#include "SubManager.h"

#pragma once
#include "list.h"
#include "student.h"



void SubManager::Print()
{
	cout << departName << " �а� �л� ���� ���" << endl << endl;
	for (int i = 0; i < students->count; i++)
	{
		PrintStudent((*students)[i]);
	}
}


void SubManager::PrintStudent(Student* student)
{
	cout << "�й�: " << student->GetUid() << endl;
	cout << "�̸�: " << student->GetName() << endl;
	cout << "�а�: " << departName << endl;

	subjectList->ForEach([&](Subject* sb) {
		SubjectScore* score = student->GetScore(sb->id);
		cout << sb->subjectName << ": " << score->getScore() << ",\t";
	});

	cout << endl << endl;
}


Student* SubManager::CreateStudent(String uid)
{
	String inputName, inputScore;

	cout << "�̸�: ";
	cin >> inputName;

	Student* student = new Student(inputName, uid, departCode);

	cout << endl << "�л����� �Է�" << endl << endl;

	subjectList->ForEach([&](Subject* sb) {
		cout << sb->subjectName << ": ";
		cin >> inputScore;
		// ���� �����˻� �߰� ���� �ʿ�
		student->AddScore(sb->id, atoi(inputScore.characters));
	});

	students->add(student);
	return student;
}