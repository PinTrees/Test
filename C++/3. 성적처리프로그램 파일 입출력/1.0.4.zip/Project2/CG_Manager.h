#pragma once
#include "list.h"
#include "student.h"
#include "SubManager.h"


class GameGraphicManager : public SubManager {
public:
	GameGraphicManager();
	GameGraphicManager(const char* d, String de, List<Subject*>* sub, List<Student*>* _student);
	~GameGraphicManager();
};