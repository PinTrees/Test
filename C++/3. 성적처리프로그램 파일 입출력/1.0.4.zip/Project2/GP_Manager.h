#pragma once
#include "list.h"
#include "student.h"
#include "SubManager.h"


class GameProgramingManager : public SubManager {
public:
	GameProgramingManager();
	GameProgramingManager(const char* d, String de, List<Subject*>* sub, List<Student*>* _student);
	~GameProgramingManager();
};