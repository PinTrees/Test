#pragma once
#include "list.h"
#include "student.h"

class SubManager {

public:
	char* departCode;
	String departName;
	List<Subject*>* subjectList;
	List<Student*>* students;

	virtual void Print();
	virtual void PrintStudent(Student* student);
	virtual Student* CreateStudent(String uid);
};
