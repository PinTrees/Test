#pragma once
#include "global.h"
#include "string.h"
#include "list.h"
#include "menu.h"
#include "subject.h"
#include "subjectScore.h"


class Student {
public:
	Student();
	Student(String name, String uid, char* type);
	~Student();

	// ���� ���� �� ���ڿ� �ļ�
	void	FromText(String text);
	char*	ToSaveFormatString();


	// ���� �Է� �� ���� �Լ�
	void			AddScore(char* code, int score) { scores->add(new SubjectScore(code, score)); }
	int			    GetScoreCount();
	SubjectScore*	GetScore(int index);
	SubjectScore*	GetScore(char* id);


	
	void	SetName(String n)				{ name = n; }
	String	GetName()						{ return name; }

	void	SetUid(String u)				{ uid = u; }
	String	GetUid()						{ return uid; }

	void	SetDepartmentType(char* t)		{ departmentType = t; }
	char*	GetDepartmentType()				{ return departmentType; }

private:
	String uid;
	String name;
	char* departmentType;

	List<SubjectScore*>* scores;
};
