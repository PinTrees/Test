#pragma once
#include <fstream> // ifstream header
#include <iostream>
#include "student.h"
#include "list.h"
#include "stringMap.h"
#include <sstream>

using namespace std;

class FileManager
{
public:

	bool SetStudentsWithFle(SMap<StudentScore*>* studens) {
		ofstream file; 
		file.open("students.txt");

		String saveText = "";
		for (int i = 0; i < studens->values.count; i++) {
			saveText += String(studens->values.elementAt(i)->toSaveText());
			saveText += "/";
		}

		if (file.is_open()) {
			file << saveText.characters;
			file.close();
		}
		else {
			cout << "error" << endl;
			return 1;
		}

		cout << saveText;
		return true;
	}

	SMap<StudentScore*>* GetStudentAsFile() {
		SMap<StudentScore*>* students = new SMap<StudentScore*>();

		std::ifstream readFile;             
		readFile.open("students.txt");   
		if (!readFile.is_open()) return students;
		
		String saveText = "";

		stringstream fileStringStream;
		fileStringStream << readFile.rdbuf();

		String* str = new String(&*fileStringStream.str().begin());
		cout << fileStringStream.str();

		char textSplits[100][128];
		char** last = NULL;
		int i = 0;

		List<String*>* aa = str->Split(';');
		cout << aa->count;

		String sadasvasfd;
		cin >> sadasvasfd;


		for (int i = 0; i < aa->count; i++) {
			StudentScore* student = new StudentScore();
			student->InitText(String(textSplits[i++]));
			students->add(student->getUid().characters, student);
		}
		

		return students;
	}
};

