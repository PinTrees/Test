#pragma once
#include "global.h"
#include "string.h"
#include "list.h"
#include "menu.h"

// �л��� �⺻ ���� ���� Ŭ����
// �й�, �̸�, �а�
class Student
{
public:
	Student();
	Student(String _name, String _uid, char* _type);
	~Student();


	void Init(String _name, String _uid, char* _type) {
		uid = _uid;
		name = _name;
		departmentType = _type;
	}

	String getUid();
	void setUid(String _uid);

	char* getDepartmentType();
	void setDepartmentType(char* _type);

	String getName();
	void setName(String _name);
private:
	String uid;
	String name;
	char* departmentType;
};


// ���� ���� Ŭ����
class Score {
public:
	Score();
	Score(int score);
	int getScore();

private:
    int score;
};


// �л��� ���� �� ���� ���� ��� Ŭ����
class StudentScore : public  Student {
public:
	StudentScore();
	StudentScore(String name, String uid, char* type);
	~StudentScore();

	int getScoreCount();
	int getScore(int index);
	void setScore(int index, int rank);
	void PrintScore(Menu* menu);


	void InitText(String text) {
		const char* separator = ",";

		// ���� ����Ʈ�� ����
		char textSplits[100][128];
		char** last = NULL;
		 
		int i = 0; 
		char* token = strtok_s(text.characters, separator, last);

		while ((i < 100) && ((token = strtok_s(NULL, separator, last)) != NULL))
		{
			strcpy_s(textSplits[i++], 128, token);
		}
		__super::Init(String(textSplits[1]), String(textSplits[0]), textSplits[2]);
	}

	char* toSaveText() {
		String saveText = String(getUid()) + ", ";
		saveText += String(getName()) + ", ";
		saveText += String(getDepartmentType()) + ", ";
		saveText += String(getDepartmentType()) + ", "; 

		for (int i = 0; i < ARRAY_LEN(scores); i++) {
			char buff[10];
			sprintf_s(buff, "%d", scores[i]->getScore());
			saveText += String(buff) + ", ";
		}

		return saveText.characters;
	}

private:
	Score* scores[3];
};
