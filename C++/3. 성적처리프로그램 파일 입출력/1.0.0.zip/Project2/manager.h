#pragma once
#include "list.h"
#include "string.h"
#include "student.h"
#include "stringMap.h"
#include "menu.h"
#include "FIleManager.h"

class MainManager 
{
	// �й��� Key�� ����ϴ� �л� ���� ���
	
	FileManager* fileManager;
	SMap<StudentScore*>* studentScores;
	Menu* menu;

public:
	MainManager();
	~MainManager();

	void Init();
	void Run();

	void PrintScore();
	void CreateScore();
	void SearchScore();
};