#pragma once
#include <fstream> // ifstream header
#include <iostream>
#include "student.h"
#include "list.h"
#include "stringMap.h"
#include <sstream>

using namespace std;

class FileManager
{
public:
	bool UpdateStudentsAsFile(SMap<StudentScore*>* studens);
	SMap<StudentScore*>* GetStudentsFromFile();
};

