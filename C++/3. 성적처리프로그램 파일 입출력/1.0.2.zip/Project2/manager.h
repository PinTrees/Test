	#pragma once
#include "list.h"
#include "string.h"
#include "student.h"
#include "stringMap.h"
#include "menu.h"
#include "FIleManager.h"
#include "GP_Manager.h"
#include "CG_Manager.h"
#include "GD_Manager.h"

class MainManager 
{
	// �й��� Key�� ����ϴ� �л� ���� ���
	FileManager* fileManager;
	
	SMap<SubManager*>* subManager;
	SMap<StudentScore*>* studentScores;
	Menu* menu;

public:
	MainManager();
	~MainManager();

	void Init();
	void Run();

	void PrintScore();
	void CreateScore();
	void SearchScore();
};