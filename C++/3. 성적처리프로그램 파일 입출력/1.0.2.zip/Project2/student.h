#pragma once
#include "global.h"
#include "string.h"
#include "list.h"
#include "menu.h"
#include "subject.h"

// �л��� �⺻ ���� ���� Ŭ����
// �й�, �̸�, �а�
class Student
{
public:
	Student();
	Student(String _name, String _uid, char* _type);
	~Student();


	void Init(String _name, String _uid, char* _type) {
		uid = _uid;
		name = _name;
		departmentType = _type;
	}

	String getUid();
	void setUid(String _uid);

	char* getDepartmentType();
	void setDepartmentType(char* _type);

	String getName();
	void setName(String _name);
private:
	String uid;
	String name;
	char* departmentType;
};



// �л��� ���� �� ���� ���� ��� Ŭ����
class StudentScore : public  Student {
public:
	StudentScore();
	StudentScore(String name, String uid, char* type);
	~StudentScore();

	int getScoreCount();
	int getScore(int index);
	void setScore(int index, int rank);
	void PrintScore(Menu* menu);
	void PrintScore(String d, List<String>* sj);

	void fromText(String text);
	char* toSaveText();

private:
	Subject* scores[3];
};
