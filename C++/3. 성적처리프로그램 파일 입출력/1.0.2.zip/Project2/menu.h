#pragma once
#include "string.h"
#include "stringMap.h"

class Menu 
{

public:
	SMap<String> mainMenu;
	SMap<String> printMenu;

	SMap<String> departmentMenu;
	//SMap<List<String>*> classMenu;

public:
	Menu();
	~Menu();
	void Init();

	String* MainMenu();
	String DepartmentMenu();
	String PrintMenu();
	//String* ClassMenu(String* subjectId);
};