#pragma once
#include <ostream>
#include "string.h"

using namespace std;

#define ARRAY_LEN(X) (sizeof(X)/sizeof(X[0]))
#define SAFE_DELETE(a) if(a != nullptr) { delete a; }
#define SAFE_ARRAY_DELETE(a) if(a != nullptr) { delete[] a; }

static char* intToChar(int a) {
	char buff[1];
	sprintf_s(buff, "%d", a);
	return buff;
}