#pragma once
#include "list.h"
#include "student.h"
#include "CG_Manager.h"

class GameProgramingManager : public SubManager {
public:
	char* departCode;
	String departName;
	List<String>* subjectList;

	GameProgramingManager() {
	}
	GameProgramingManager(const char* d, String de, List<String>* sub) {
		departCode = (char*)d;
		departName = de;
		subjectList = new List<String>();

		subjectList->add("");
	}
	~GameProgramingManager() { 

	}

	List<StudentScore*>* GetStudent(SMap<StudentScore*>* user) override {
		List<StudentScore*>* students = new List<StudentScore*>();
		for (int i = 0; i < user->count; i++)
		{
			StudentScore* student = user->values[i];
			if (student->getDepartmentType() == departCode) students->add(student);
		}
		return students;
	}

	void Print(SMap<StudentScore*>* user) override
	{
		cout << departName << " �а� �л� ���� ���" << endl << endl;
		for (int i = 0; i < user->count; i++)
		{
			StudentScore* student = user->values.elementAt(i);
			if (student->getDepartmentType()[0] == departCode[0]) student->PrintScore(departName, subjectList);
		}
	}
};