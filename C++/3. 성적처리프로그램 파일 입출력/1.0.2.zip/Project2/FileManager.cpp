#include "FIleManager.h"

bool FileManager::UpdateStudentsAsFile(SMap<StudentScore*>* studens) { 
	ofstream file;
	file.open("students.txt");

	String saveText = "";
	for (int i = 0; i < studens->values.count; i++)
	{
		saveText += studens->values[i]->toSaveText();
		saveText += ";\n"; 
	}

	if (file.is_open())
	{
		file << saveText.characters;
		file.close(); 
	}
	else {
		cout << "error" << endl;
		return false;
	}

	return true;
}

SMap<StudentScore*>* FileManager::GetStudentsFromFile()
{
	SMap<StudentScore*>* students = new SMap<StudentScore*>();

	ifstream readFile;
	readFile.open("students.txt");

	if (!readFile.is_open()) return students;

	stringstream fileStringStream;
	fileStringStream << readFile.rdbuf();

	String* studentDataString = new String(&*fileStringStream.str().begin());
	List<String*>* studentDatas = studentDataString->Split(';');

	for (int i = 0; i < studentDatas->count; i++)
	{
		StudentScore* student = new StudentScore();
		student->fromText(*(studentDatas->elementAt(i)));

		char* key = student->getUid().characters;
		students->add(key, student);
	}

	return students;
}