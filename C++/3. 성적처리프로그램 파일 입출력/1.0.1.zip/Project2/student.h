#pragma once
#include "global.h"
#include "string.h"
#include "list.h"
#include "menu.h"

// �л��� �⺻ ���� ���� Ŭ����
// �й�, �̸�, �а�
class Student
{
public:
	Student();
	Student(String _name, String _uid, char* _type);
	~Student();


	void Init(String _name, String _uid, char* _type) {
		uid = _uid;
		name = _name;
		departmentType = _type;
	}

	String getUid();
	void setUid(String _uid);

	char* getDepartmentType();
	void setDepartmentType(char* _type);

	String getName();
	void setName(String _name);
private:
	String uid;
	String name;
	char* departmentType;
};


// ���� ���� Ŭ����
class Score {
public:
	Score();
	Score(int score);
	int getScore();

private:
    int score;
};


// �л��� ���� �� ���� ���� ��� Ŭ����
class StudentScore : public  Student {
public:
	StudentScore();
	StudentScore(String name, String uid, char* type);
	~StudentScore();

	int getScoreCount();
	int getScore(int index);
	void setScore(int index, int rank);
	void PrintScore(Menu* menu);


	void InitFromText(String text) {
		const char* separator = ",";

		cout << text << endl << endl;

		List<String*>* splits = text.Split(',');
		__super::Init(*(splits->elementAt(1)), *(splits->elementAt(0)), splits->elementAt(2)->characters);

		for (int i = 0; i < ARRAY_LEN(scores); i++) {
			setScore(i, atoi(splits->elementAt(3 + i)->characters));
		}
	}

	// toJsonString()
	char* toSaveText() {
		String saveText = String(getUid()) + ",";
		saveText += String(getName()) + ",";
		saveText += String(getDepartmentType()) + ",";

		for (int i = 0; i < ARRAY_LEN(scores); i++) {
			char buff[10];
			sprintf_s(buff, "%d", scores[i]->getScore());
			saveText += String(buff) + ",";
		}

		return saveText.characters;
	}

private:
	Score* scores[3];
};
