#pragma once
#include <fstream> // ifstream header
#include <iostream>
#include "student.h"
#include "list.h"
#include "stringMap.h"
#include <sstream>

using namespace std;

class FileManager
{
public:

	bool SetStudentsWithFle(SMap<StudentScore*>* studens) {
		ofstream file; 
		file.open("students.txt");

		String saveText = "";
		for (int i = 0; i < studens->values.count; i++) {
			saveText += String(studens->values.elementAt(i)->toSaveText());
			saveText += "/";
		}

		if (file.is_open()) {
			file << saveText.characters;
			file.close();
		}
		else {
			cout << "error" << endl;
			return 1;
		}

		cout << saveText;
		return true;
	}

	SMap<StudentScore*>* GetStudentAsFile() {
		SMap<StudentScore*>* students = new SMap<StudentScore*>();

		std::ifstream readFile;             
		readFile.open("students.txt");   
		if (!readFile.is_open()) return students;
		
		String saveText = "";

		stringstream fileStringStream;
		fileStringStream << readFile.rdbuf();

		String* str = new String(&*fileStringStream.str().begin());
		cout << fileStringStream.str();


		List<String*>* splitStudentText = str->Split(';');
		cout << endl << splitStudentText->count;

		for(int i = 0; i < splitStudentText->count; i++)
			cout << splitStudentText->elementAt(i)->characters << endl;

		for (int i = 0; i < splitStudentText->count; i++) {
			StudentScore* student = new StudentScore();
			student->InitFromText(*(splitStudentText->elementAt(i)));
			students->add(student->getUid().characters, student);
		}
		
		
		return students;
	}
};

