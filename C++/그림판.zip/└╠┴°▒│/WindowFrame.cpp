#include "WindowFrame.h"


WindowFrame* WindowFrame::instance = nullptr;

WindowFrame* WindowFrame::Create(HINSTANCE hInstance) {
	if (instance == nullptr) instance = new WindowFrame();
	
	instance->g_hInst = hInstance;
	instance->currentDraw = nullptr;
	instance->mousePosList = new List<List<Mouse*>*>(); 
	instance->drawObjList = new List<DrawObject*>();

	return instance;
}
WindowFrame* WindowFrame::Instance() {
	return instance;
}
void WindowFrame::Dispose() {
	if (instance != nullptr) { delete instance; instance = nullptr; }
}



void WindowFrame::Init() {
}

void WindowFrame::Build() { 
	LPCTSTR lpszClass = TEXT("First"); 
	WNDCLASS WndClass; 

	WndClass.cbClsExtra = 0; 
	WndClass.cbWndExtra = 0; 
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = g_hInst;
	WndClass.lpfnWndProc = WndProc; 
	WndClass.lpszClassName = lpszClass; 
	WndClass.lpszMenuName = lpszClass;
	//WndClass.lpszMenuName = NULL; 
	WndClass.style = CS_HREDRAW | CS_VREDRAW; 
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, 
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 
		NULL, (HMENU)NULL, g_hInst, NULL);
	ShowWindow(hWnd, SW_SHOW);

	buffur = new Buffur(hWnd);
}

void WindowFrame::Run(MSG* Message) {
	TranslateMessage(Message);
	DispatchMessage(Message);
}

HMENU hMenu, hSubMenu;
LRESULT CALLBACK WindowFrame::WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc = NULL;
	switch (iMessage) {
	case WM_CREATE:
	{
		hMenu = CreateMenu();

		hSubMenu = CreatePopupMenu();
		AppendMenu(hSubMenu, MF_STRING, 001, "&����");
		AppendMenu(hSubMenu, MF_STRING, 002, "&���");
		AppendMenu(hSubMenu, MF_STRING, 003, "&���β�");
		AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu, "&�簢��");

		hSubMenu = CreatePopupMenu(); 
		AppendMenu(hSubMenu, MF_STRING, 101, "&����");
		AppendMenu(hSubMenu, MF_STRING, 102, "&���");
		AppendMenu(hSubMenu, MF_STRING, 103, "&���β�");
		AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu, "&��");

		SetMenu(hWnd, hMenu);
		Mouse::isDown = false;
		break;
	}
	case WM_LBUTTONDOWN:
	{
		Mouse::isDown = true;

		/// �̺κ� ������������ ����
		if (instance->curState == 0) {
			instance->mousePosList->Add(new List<Mouse*>(1, new Mouse(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam))));
		}
		else {
			instance->currentDraw = new Box();
			instance->currentDraw->startPos = new Vector2(lParam);
			instance->currentDraw->endPos = new Vector2(lParam);
			instance->drawObjList->Add(instance->currentDraw);
		}
		/// ���콺 ����Ŭ�� ��ġ �Ҵ�

		break;
	}
	case WM_LBUTTONUP:
	{
		instance->currentDraw = nullptr;
		Mouse::isDown = false;
	}
	case WM_MOUSEMOVE:
	{
		if (Mouse::isDown == true) {
			/// �̺κ� ������������ ����
			if (instance->curState == 0) {
				instance->mousePosList->last->value->Add(new Mouse(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)));
			}
			else {
				if (instance->currentDraw != nullptr) {
					instance->currentDraw->endPos = new Vector2(lParam);
				}
			}
		}

		InvalidateRect(hWnd, NULL, FALSE);
		break;
	}
	case WM_KEYDOWN:
	{
		if (instance->curState == 0) instance->curState = 1;
		else instance->curState = 0;
		break;
	}
	case WM_PAINT:
		instance->buffur->Paint([&](HDC memDC) {
			instance->drawObjList->ForEach([&](DrawObject* obj) {
				obj->Render(memDC);
				});
			instance->mousePosList->ForEach([&](List<Mouse*>* m) {
				m->ForEachNode([&](ListNode<Mouse*>* node) {
					if (node->next == nullptr) return;
					Mouse* pos = node->value;
					Mouse* nextPos = node->next->value;
					MoveToEx(memDC, pos->x, pos->y, NULL);
					LineTo(memDC, nextPos->x, nextPos->y);
					});
				});
			});
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case 001:
			PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;
		case ID_ABOUT:
			MessageBox(NULL, "Win32 ���ҽ� �׽�Ʈ ���α׷��Դϴ�.", "About", MB_OK);
			break;
		}

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
