#pragma once
#include <windows.h>
#include "WindowFrame.h"

class MainFrame {
private:
	static MainFrame* instance;
	MainFrame() {}
	~MainFrame() {}

public:
	static MainFrame* Create(HINSTANCE hInstance);
	static MainFrame* Instance();
	static void Dispose();

	void Init();
	int Run();
};