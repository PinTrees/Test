#pragma once
#include <windows.h>
#include "Vector2.h"


class DrawObject {
public:
	DrawObject() {}
	~DrawObject() {}

	Vector2* startPos = nullptr;
	Vector2* endPos = nullptr;

	virtual void Render(HDC) = 0;
};


class Box : public DrawObject {
public: 
	Box() {}
	void Render(HDC hdc) {
		Rectangle(hdc, startPos->x, startPos->y, endPos->x, endPos->y);
	}
};