#pragma once
#include "Payment.h"

class PaymentProcessor {
private:
    PaymentStrategy* strategy;

public:
    void setPaymentStrategy(PaymentStrategy* strategy) {
        this->strategy = strategy;
    }

    void executePayment(int amount) {
        strategy->pay(amount);
    }
};