﻿#include <iostream>
#include "Payment.h"
#include "PaymentProcessor.h"

int main() {
    PaymentProcessor processor;

    PaymentStrategy* creditCardPayment = new CreditCardPayment();
    processor.setPaymentStrategy(creditCardPayment);
    processor.executePayment(10000);

    PaymentStrategy* kakaoPay = new KakaoPay();
    processor.setPaymentStrategy(kakaoPay);
    processor.executePayment(20000);

    PaymentStrategy* naverPay = new NaverPay();
    processor.setPaymentStrategy(naverPay);
    processor.executePayment(30000);

    delete creditCardPayment;
    delete kakaoPay;
    delete naverPay;

    return 0;
}