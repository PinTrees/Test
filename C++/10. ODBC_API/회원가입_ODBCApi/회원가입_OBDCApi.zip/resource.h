//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// ODBCApi2.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_BUTTON1                    1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                    1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
